# Observed Umíme UI map — 2026-11-03

These are read-only observations of actual rendered mathematics exercises, not guessed website source APIs. No private account details, homework IDs or session links are included here.

| Format | Observed question area | Answers | Progression controls | Handling |
| --- | --- | --- | --- | --- |
| Step-by-step (`chat.js`) | `#questionParent > #question`, growing conversation | `#cards .card`, IDs `option0`, `option1`, formulas in `data-expr` | Steps update the question/card DOM | Keep one run; identify each new step by question/choices |
| Written answer | `#playground`, `#question-frame`, `#question`, `#question-content` | `#answer0 input[type=text]` | `#evaluate` visible; `#next` initially hidden | Fill once, evaluate once, wait for result, advance |
| Modern multiple choice (`novaDoplnovacka.js`) | `#playground`, `#question-wrapper`, `[data-data=question]` | `.card[data-data=option][data-index]` with no option ID | `#next` initially hidden | Resolve the actual card, not a nested KaTeX glyph |
| Completion markup in written-answer template | Completion board elsewhere inside `#exercise` | No current question answer required | `[data-data=close-finalboard]` buttons | Treat visible completion board as done; don't restart automatically |

All three pages include navigation/help/reference markup around the exercise. The old broad root and text fingerprint included unrelated parts of that markup. KaTeX includes both MathML and visual HTML; literal text extraction repeats and rearranges fractions. The update normalizes each whole formula to its source annotation once.

Reference pages inspected:
- https://www.umimematiku.cz/odvozovani-prevod-desetinne-zlomek-2-uroven/92
- https://www.umimematiku.cz/pocitani-smisena-cisla-2-uroven/3977
- https://www.umimematiku.cz/rozhodovacka-zlomky-desetinna-2-uroven/7585

Limits: post-answer transitions were simulated in tests rather than submitted to the signed-in site. Other subjects share some components but were not exhaustively inspected. Drag/drop, audio-only and custom games still require dedicated adapters. Existing local puzzle solvers were not redesigned.


## Additional Czech layouts inspected in 1.11.0

| Sample | Observed structure | Adapter implication |
| --- | --- | --- |
| https://www.umimecesky.cz/diktat-ruzne-vyskyty-i-y-2-uroven/210 | `#dictate`, `.gap-dropdown`, `.gap-cursor.current`, `.variant`, span `.tlacitko.next` | Choose one visible letter for the active blank; watch active-gap/answered-state changes; do not expose hidden correctness metadata. |
| https://www.umimecesky.cz/pexeso-synonymum-2-uroven/617 | `#pexeso .card[data-index]` with nested `.card-content` | One target per card, one pair per plan; recognize removed/hidden pairs. |
| https://www.umimecesky.cz/oznacovani-korektury-fantasy-3/1511 | `#question-content .selectable-area[data-index]`, `#evaluate`, `#next` | Click whole word area, not nested content/anchor; selection styling is not a new question. |
| https://www.umimecesky.cz/rozrazovacka-tvoreni-slov-2 | `.word.ui-draggable`, `.wordBox.ui-droppable`, span `#evaluate` | Requires a dedicated drag adapter, currently unsupported. |

These pages were read-only inspections. No post-answer outcome was observed or claimed from them; transitions are represented by regression fixtures. No account identifiers or recommendation/session URLs are included.
