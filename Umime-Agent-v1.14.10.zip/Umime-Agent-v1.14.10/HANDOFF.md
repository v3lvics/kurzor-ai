# Developer handoff — 1.12.0

Latest audit: see COVERAGE.md. 67 tests pass. New `tests/dom-layouts.test.js` uses development dependency linkedom via `tests/helpers/dom-harness.js`. Run `npm ci && npm test`. Extension runtime has no package dependencies.


README.md is the current install, change and coverage record. SITE-MAP.md records read-only live layout observations.

New: `exercise-state.js` owns stable question identity, pending transitions and idempotent counting. The generic loop is single-flight. `continuous-run.test.js` runs the real loop with deterministic DOM/provider adapters across two questions and duplicate activation; `exercise-state.test.js` covers 12 lifecycle/identity cases. Total: 54 passing tests.

## Files

- `extension/site-config.js`: host allowlist used in content and worker contexts. When changing domains, also update manifest matches; tests enforce alignment.
- `extension/action-validator.js`: structured-response validation and complete-plan target compatibility. Background validates all AI solutions; the executor revalidates against snapshot targets.
- `extension/ai-agent.js`: generic planner, snapshots, visual context, field/cursor execution, local ratio and Šipkovaná orchestration, bounded retries, question revalidation.
- `extension/background.js`: Gemini-only provider, streaming parser, up to four images, tab/frame-scoped cancellation, 25-second network deadline.
- `extension/answer-target-resolver.js`: NFC and math whitespace normalization without removing spelling distinctions or mathematical punctuation.
- `extension/exercise-inspector.js`: path/script/structure classification.
- `extension/content.js`: existing animated overlay; version updated. Dedicated Ploty and Sokoban scripts remain scoped to Informatics.
- `extension/tests/reliability.test.js`: host coverage, malformed plans, worker streams, image payloads and per-tab cancellation.
- `extension/tests/interaction.test.js`: executes real generic-agent helpers in a VM with minimal DOM mocks. Covers labels, mid-move/mid-type stop, numeric fields, incompatible controls and selects.

Run `node --test extension/tests/*.test.js` from project root. Run `node --check` on each extension JavaScript file.

## Remaining work

No live integrated Chrome/Gemini verification in this update. Three live mathematics layouts were inspected through the cloud browser without submitting answers. See README acceptance checklist. Do not claim universal exercise compatibility. Audio-only questions, generic drag/drop, arbitrary programming exercises and unmodelled games need dedicated adapters and live fixtures. Existing local solvers were retained rather than rewritten. The ZIP name of the input said Ollama, but the supplied implementation had no Ollama provider.

Question fingerprints intentionally ignore input values, option selected states and mutable styling. They include image source URLs but cannot detect pixels changing inside the same canvas/image URL. Revalidate live state for such formats before extending automation.
Latest: drag-drop.js implements the mapped jQuery card layout only; see 1.12.0 README notes. 71 tests pass. No live drag or Gemini vision acceptance test.
