# Current 1.14.0 note

The prior table below describes 1.12.0 behavior. Version 1.14.0 additionally loads the supplied neumimeto local adapter registry before Gemini. Those imported families are implemented but have not been individually certified in a live installed session. Read the latest README for pacing and cancellation limits. 84 tests pass.

# Compatibility and test report — 1.12.0


## 1.12.0: drag adapter and visual detail

Added an experimental adapter for the mapped Umíme jQuery card sorting layout: `.word.ui-draggable[currentbox]` to empty `.wordBox.ui-droppable[currentword]` slots. AI returns one `drag` with source and destination IDs. The executor sends held-mouse movement and checks placement attributes or DOM containment before proceeding. Failed drops stop before grading; cancellation releases the mouse. Cards are placed sequentially and grading is deferred until none remain in the pool. Both endpoints must be visible in the viewport. Arbitrary HTML5 drag/drop, offscreen dragging and other game engines remain unsupported.

Visual input now uses up to eight attachments, a 1400px maximum side, higher JPEG quality and white compositing for transparent pictures. The prompt includes image dimensions, screen positions and answer-target mapping, and asks for uncertainty when details cannot be read. Cross-origin pictures can still be unavailable. This improves the supplied visual context; it does not guarantee recognition accuracy.

71 tests pass, including drag receipt/rejection/cancellation fixtures. Geometry, mouse handlers and placement state in those tests are simulated. No live Umíme drop or real Gemini vision request was validated in this release. Test a short sorting exercise before relying on this adapter.

## Answer to “almost everything?”

Not established. Domain injection coverage is broad, but the site has different interaction engines. Passing unit/DOM tests is not a measurement of the percentage of live exercises solved. This build has not been run end-to-end with a real Gemini key in Chrome.

| Format | Current implementation | Evidence / remaining limit |
| --- | --- | --- |
| Standard multiple choice | Implemented | Live mathematics layout inspected; complete card extraction and formula tests pass. AI accuracy and live click acceptance unverified. |
| Written answer / native select | Implemented | Live written-answer layout inspected; input/select checks and continuous two-question loop simulation pass. |
| Step-by-step maths / grammar | Implemented through current-question planner | Live maths chat layout inspected; question/choice identity checks pass. Every topic is not individually tested. |
| Custom letter gap-fill | Newly adapted, partial validation | Live Czech `#dictate .gap-dropdown` menus mapped; active-gap and variant extraction tests pass. Real auto-advance timing needs installed-extension testing. |
| Matching pairs | Improved, partial validation | Live `#pexeso .card` layout mapped; single-card targeting and pair-removal progression fixtures pass. One visible pair is requested per AI call. Other memory-game variants are untested. |
| Text marking / correction | Improved, partial validation | Live `.selectable-area` layout mapped; one target per word, stable selection identity and guarded empty-selection behavior tested. Model accuracy unverified. |
| Reading comprehension | Generic text planner | No new live exercise sample this audit. Long passages may be truncated. |
| Image / canvas questions | Partial | Up to four readable visuals supported; payload tests pass. Cross-origin images and unchanged canvas URLs can still limit context. |
| Ratio division | Local rules + fallback | Existing calculation fixtures pass. Rules cover a limited family. |
| Šipkovaná | Existing local parser/search | Existing fixtures pass. This audit did not test every special mechanic live. |
| Ploty / Sokoban | Existing dedicated solvers retained | Syntax checks only in this audit; no new real-game verification. |
| Drag-based sorting / arranging | Unsupported by generic executor | Live jQuery draggable/droppable layout identified. Stops before spending AI calls on an unusable click plan. |
| Audio-only dictation / listening | Unsupported | No transcription pipeline. Recognized listening routes stop clearly. |
| Arbitrary code exercises, timed multiplayer and other custom games | Unverified / missing dedicated adapters | Do not treat generic detection as support. |

## Reproduced failures fixed

New synthetic DOM fixtures reflect the observed element structures and use neutral example content. Before the fix, 6 of the first 8 new layout tests failed: duplicated matching children, duplicated marking children, missing gap classification, missing span Next controls, answer text “next” incorrectly excluded, and drag layouts misclassified. All now pass.

Further tests verify stable marking state, advancing between identical letter menus, recognizing removed pairs, not including hidden correctness attributes in prompts, and tightly guarding empty submissions.

Total: 67 automated tests. They run locally without a Gemini key and do not change website scores. Geometry is mocked; no performance or correctness percentage is claimed.

## Next meaningful validation

Install this version in the same extension folder and refresh the tabs. Run one short exercise from each implemented row with your Gemini configuration. Record the exact public exercise URL, the last visible status and the format when something stalls. Start with gap-fill and matching because their asynchronous page behavior is only fixture-tested here. Do not extrapolate one passing exercise to every topic or game.
