(() => {
  'use strict';
  if (window.top !== window || window.__umimeOverlayLoaded) return;
  window.__umimeOverlayLoaded = true;

  const VERSION = '1.14.10';
  const CONTROL_CHANNEL = 'umime-ai-control';
  const EVENT_CHANNEL = 'umime-ai-overlay';
  const HOST_ID = 'umime-ai-agent-overlay-host';
  const AUTO_NEXT_STORAGE_KEY = 'autoSolveNextExercises';
  const ALLOW_SUB_AGENTS_STORAGE_KEY = 'allowSubAgents';

  let shadow = null, scene = null, cursor = null, targetBox = null, dock = null, pill = null;
  let statusEl = null, countEl = null, stopBtn = null, offerBtn = null, gearBtn = null, sheet = null, exerciseHost = null;
  let cursorTag = null, cursorThought = null, cursorThoughtLabel = null, thoughtTimer = null, thoughtRevealTimer = null, thoughtExitTimer = null, thoughtToken = 0;
  let activeGeminiRequestId = null;
  const subCursors = new Map();
  const subCursorTokens = new Map();
  const subCursorTimers = new Map();
  let geminiDotTimer = null, geminiDotTransitionTimer = null, geminiDotIndex = 0;
  let autoSolveNextExercises = true;
  let allowSubAgents = false;
  let sheetOpen = false;
  let offeringGemini = false;
  let exerciseSettings = null;
  let mode = 'idle';            // idle | peek | active | done
  let altDown = false;
  let curX = Math.round(window.innerWidth / 2);
  let curY = Math.round(window.innerHeight / 2);
  let cursorPlaced = false;
  let moveToken = 0;
  let hideTimer = null, activationTimer = null, idleTimer = null, targetTimer = null;
  let lastStatusAt = 0;
  let swallowClicksUntil = 0;
  let sparkCanvas = null, sparkCtx = null, sparkRaf = 0;
  const sparks = [];
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isMathHost = ['umimematiku.cz', 'umimematematiku.cz'].some(domain =>
    location.hostname === domain || location.hostname === `www.${domain}` || location.hostname.endsWith(`.${domain}`));

  const send = (type, extra = {}) => window.postMessage({ channel: EVENT_CHANNEL, type, ...extra }, '*');
  const setMode = next => {
    mode = next;
    if (scene) scene.dataset.mode = next;
    if (scene && sheetOpen) scene.classList.add('settings-open');
    if (sheet && sheetOpen) sheet.classList.add('open');
    if (next === 'active' || next === 'peek') startSparks();
    else if (next === 'idle') { sparks.length = 0; if (sparkCtx) sparkCtx.clearRect(0, 0, window.innerWidth, window.innerHeight); }
  };

  function activityFromStatus(text, tone) {
    const t = String(text || '').toLowerCase();
    if (tone === 'ok' || tone === 'error') return 'idle';
    if (tone === 'stopped' || /\bpaus|\bstopped\b/.test(t)) return 'paused';
    if (/\bwait|\blooking|\bchecking the page|isn.t recognized/.test(t)) return 'wait';
    return 'work';
  }

  function conciseActivityStatus(text) {
    const status = String(text || '').toLowerCase();
    if (/^(?:starting|reading the page|initializ|loading)/.test(status)) {
      return 'Thinking…';
    }
    if (/wait|retry|rate limit|busy|not responding|hard time|looking for|did not advance|could not safely|answer checked/.test(status)) {
      return 'Waiting…';
    }
    if (/paused/i.test(status)) return 'Paused';
    return 'Working…';
  }

  function setStatus(text, tone) {
    if (!pill) return;
    let next = String(text || 'Working').slice(0, 200);

    // Remove progress counts like "Playing... 116/150"
    next = next.replace(/\s*\d+\/\d+.*$/, '').trim();

    if (statusEl.textContent !== next) {
      statusEl.textContent = next;
      try { statusEl.animate([{ opacity: 0, transform: 'translateY(4px)' }, { opacity: 1, transform: 'none' }], { duration: 240, easing: 'cubic-bezier(.2,.8,.2,1)' }); } catch {}
    }
    if (tone) pill.dataset.tone = tone;
    const orb = pill.querySelector('.orb');
    if (orb) orb.dataset.activity = activityFromStatus(next, pill.dataset.tone);
    lastStatusAt = Date.now();
  }

  function setGeminiDotCycle(active) {
    // The same continuous indicator covers both local and Gemini work.
    if (geminiDotTimer) clearInterval(geminiDotTimer);
    if (geminiDotTransitionTimer) clearTimeout(geminiDotTransitionTimer);
    geminiDotTimer = geminiDotTransitionTimer = null;
  }

  function setCount(n) {
    if (!countEl) return;
    countEl.hidden = true;
  }

  function mount() {
    if (shadow || !document.documentElement) return;
    const host = document.createElement('div');
    host.id = HOST_ID;
    host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
    shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        *, *::before, *::after { box-sizing: border-box; }
        .scene {
          position: fixed; inset: 0; pointer-events: none; --w: 4.5px;
          --c1: #8ec5ff; --c2: #6a8bff; --c3: #b69cff; --c4: #5ee7df;
          opacity: 0; visibility: hidden; transition: opacity .3s ease, visibility .3s;
          font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif;
          -webkit-font-smoothing: antialiased; color: #1d1d22;
        }
        .scene:not([data-mode="idle"]) { opacity: 1; visibility: visible; }
        .scene[data-reminder="show"] { opacity: 1; visibility: visible; }

        /* ---------- Edge glow (ring only, the page in the middle is never covered) ---------- */
        .ring, .arc {
          position: fixed; inset: 0; padding: 0; pointer-events: none; opacity: 0; transition: opacity .45s ease;
          -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
          -webkit-mask-composite: xor; mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); mask-composite: exclude;
        }
        .ring {
          padding: 0;
          background: linear-gradient(100deg, var(--c1), var(--c2), var(--c3), var(--c4), var(--c1), var(--c2), var(--c3), var(--c4), var(--c1));
          background-size: 400% 100%; animation: flow 12s linear infinite;
          mask-image: radial-gradient(circle, transparent 40%, black 100%);
          -webkit-mask-image: radial-gradient(circle, transparent 40%, black 100%);
        }
        .arc { overflow: hidden; padding: 0; }
        .arc::before {
          content: ''; position: absolute; left: 50%; top: 50%; width: 300vmax; height: 300vmax; margin: -150vmax 0 0 -150vmax;
          background: conic-gradient(from 0deg, transparent 0 58%, rgba(255,255,255,0) 58%, rgba(255,255,255,1) 76%, rgba(160,220,255,.2) 88%, transparent 94% 100%);
          animation: spin 6s linear infinite; will-change: transform;
        }
        .vignette {
          position: fixed; inset: 0; pointer-events: none; opacity: 0; transition: opacity .6s ease;
          box-shadow: inset 0 0 90px 10px rgba(106,139,255,.28), inset 0 0 180px rgba(94,231,223,.1);
        }
        .sparks { position: fixed; inset: 0; width: 100%; height: 100%; pointer-events: none; }
        .scene[data-mode="peek"] { --w: 3.5px; }
        .scene[data-mode="peek"] .ring { animation: flow 12s linear infinite, breathe 2.1s cubic-bezier(.37,0,.63,1) infinite; }
        .scene[data-mode="active"] .ring { opacity: 0.5; }
        .scene[data-mode="active"] .arc { opacity: 1; }
        .scene[data-mode="active"] .vignette { opacity: 1; }
        .scene[data-mode="done"] .ring { opacity: .4; }

        /* ---------- Alt hint ---------- */
        .hint {
          position: fixed; left: 50%; bottom: max(22px, env(safe-area-inset-bottom)); transform: translate(-50%, 8px); opacity: 0;
          white-space: nowrap; padding: 9px 16px; border-radius: 999px; font-size: 12.5px; font-weight: 500; letter-spacing: -.005em;
          background: rgba(255,255,255,.85); border: 1px solid rgba(255,255,255,.4);
          backdrop-filter: blur(24px) saturate(180%); -webkit-backdrop-filter: blur(24px) saturate(180%);
          box-shadow: 0 12px 34px rgba(0,0,0,.15);
          transition: opacity .25s ease, transform .3s cubic-bezier(.2,.8,.2,1);
          color: #1d1d22;
        }
        .hint b { font-weight: 600; } .hint i { font-style: normal; color: #6b6b75; margin: 0 7px; }
        .scene[data-mode="peek"] .hint { opacity: 1; transform: translate(-50%, 0); }
        .gemini-reminder {
          position: fixed; left: 50%; bottom: max(22px, env(safe-area-inset-bottom)); z-index: 5;
          transform: translate(-50%, 8px); opacity: 0; white-space: nowrap; padding: 9px 16px;
          border: 1px solid rgba(255,255,255,.55); border-radius: 999px;
          background: linear-gradient(135deg, rgba(255,255,255,.92), rgba(235,242,255,.86));
          box-shadow: 0 12px 34px rgba(0,0,0,.15); backdrop-filter: blur(24px) saturate(180%);
          color: #34384a; font-size: 12.5px; font-weight: 550; pointer-events: none;
        }
        .scene[data-reminder="show"] .gemini-reminder { animation: reminder-in 3.6s ease both; }
        .reminder-trace {
          position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible;
          pointer-events: none; opacity: 0;
          filter: drop-shadow(0 0 3px rgba(94,231,223,.9)) drop-shadow(0 0 7px rgba(106,139,255,.8)) drop-shadow(0 0 12px rgba(182,156,255,.55));
        }
        .scene[data-reminder="show"] .reminder-trace { animation: reminder-fade 3.6s ease both; }
        .reminder-trace path {
          fill: none; stroke: url(#reminder-gradient); stroke-width: 2; stroke-linecap: round;
          vector-effect: non-scaling-stroke;
        }

        /* ---------- Status dock ---------- */
        .dock {
          position: fixed; left: 50%; bottom: max(22px, env(safe-area-inset-bottom)); transform: translate(-50%, 12px); opacity: 0;
          pointer-events: none; width: 380px; max-width: calc(100vw - 24px);
          transition: opacity .3s ease, transform .35s cubic-bezier(.2,.8,.2,1);
        }
        .scene[data-mode="active"] .dock, .scene[data-mode="done"] .dock { opacity: 1; transform: translate(-50%, 0); }
        .scene.settings-open .dock { opacity: 1; transform: translate(-50%, 0); pointer-events: auto; }
        .pill {
          position: relative; pointer-events: auto; display: flex; align-items: center; gap: 12px; isolation: isolate;
          width: 380px; max-width: calc(100vw - 24px); padding: 10px 10px 10px 14px; border-radius: 22px;
          background: linear-gradient(180deg, rgba(255,255,255,.86), rgba(245,248,255,.68));
          backdrop-filter: blur(28px) saturate(190%); -webkit-backdrop-filter: blur(28px) saturate(190%);
          box-shadow: 0 18px 50px rgba(20,30,70,.22), 0 0 0 .5px rgba(255,255,255,.9), 0 0 36px rgba(140,185,255,.42), 0 0 90px rgba(110,160,255,.2), inset 0 1px 0 rgba(255,255,255,.95);
          cursor: grab; user-select: none; -webkit-user-select: none; color: #1d1d22;
        }
        .scene[data-mode="active"] .pill { animation: pill-in .55s cubic-bezier(.16,1,.3,1); }
        .pill-orbit, .pill-burst { position: absolute; pointer-events: none; border-radius: inherit; }
        /* No orbit, letting the main orb do the visual job */
        .pill-orbit { display: none; }
        .pill[data-tone="busy"] .pill-orbit { opacity: 1; }
        .pill-burst {
          inset: -10px; border: 1.5px solid rgba(190,220,255,.95);
          box-shadow: 0 0 24px rgba(140,185,255,.55); opacity: 0;
        }
        .scene[data-mode="active"] .pill-burst { animation: burst .75s cubic-bezier(.16,.8,.24,1) 1; }
        .pill::before { /* hairline gradient edge */
          content: ''; position: absolute; inset: 0; border-radius: inherit; padding: 1px; pointer-events: none; opacity: .9;
          background: linear-gradient(135deg, rgba(255,255,255,.95), rgba(142,197,255,.55) 40%, rgba(182,156,255,.45));
          -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); -webkit-mask-composite: xor;
          mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); mask-composite: exclude;
        }
        .pill.dragging { cursor: grabbing; }
        .orb {
          position: relative; flex: 0 0 30px; width: 30px; height: 30px; border-radius: 50%; display: grid; place-items: center;
          --claude: #da7756; --claude-glow: rgba(218,119,86,.55);
        }
        .orb-core, .dots-fluid {
          opacity: 0; pointer-events: none;
          transition: opacity .55s ease;
        }
        .orb-core {
          position: relative; z-index: 1; width: 8px; height: 8px; border-radius: 50%;
          background: var(--claude); box-shadow: 0 0 9px 2px var(--claude-glow);
          transition: opacity .55s ease, background .45s ease, box-shadow .45s ease;
        }
        .orb-core i {
          display: block; width: 100%; height: 100%; border-radius: 50%;
          background: inherit; box-shadow: inherit;
        }
        .dots { position: absolute; inset: 0; }
        .dots b {
          position: absolute; top: 50%; left: 50%; width: 5px; height: 5px; margin: -2.5px 0 0 -2.5px;
          border-radius: 50%; background: var(--claude); box-shadow: 0 0 7px 1px var(--claude-glow);
        }

        .dots-fluid { filter: drop-shadow(0 0 4px var(--claude-glow)); transition: opacity .26s ease-in-out, filter .26s ease-in-out; }
        .dots-fluid b { width: 6px; height: 6px; margin: -3px 0 0 -3px; }
        .dots-fluid.changing-animation { opacity: 0 !important; filter: blur(3px) drop-shadow(0 0 4px var(--claude-glow)); }
        .dots-fluid.changing-animation, .dots-fluid.changing-animation b { animation-play-state: paused !important; }
        .orb .dots-fluid b:nth-child(1) { animation: fluid-dot-left 1.45s cubic-bezier(.45,0,.55,1) infinite; }
        .orb .dots-fluid b:nth-child(2) { animation: fluid-dot-center 1.45s cubic-bezier(.45,0,.55,1) infinite; }
        .orb .dots-fluid b:nth-child(3) { animation: fluid-dot-right 1.45s cubic-bezier(.45,0,.55,1) infinite; }
        .orb .dots-fluid b:nth-child(4) { display: none; }
        @media (prefers-reduced-motion: reduce) {
          .orb .dots-fluid b { animation: none !important; }
          .orb .dots-fluid b:nth-child(1) { transform: translateX(-9px); }
          .orb .dots-fluid b:nth-child(3) { transform: translateX(9px); }
        }
        .orb[data-activity="work"] .dots-fluid,
        .orb[data-activity="wait"] .dots-fluid { opacity: 1; }
        .orb[data-activity="paused"] .orb-core,
        .orb[data-activity="idle"] .orb-core { opacity: 1; }
        .orb[data-activity="paused"] .orb-core i { animation: pulse-dot 2.2s ease-in-out infinite; }

        .pill[data-tone="ok"] .orb-core { background: #30d158; box-shadow: 0 0 9px 2px rgba(48,209,88,.6); }
        .pill[data-tone="error"] .orb-core { background: #ff453a; box-shadow: 0 0 9px 2px rgba(255,69,58,.6); }
        .pill[data-tone="stopped"] .orb-core { background: #8e8e93; box-shadow: none; }
        .txt { flex: 1; min-width: 0; display: flex; align-items: center; gap: 8px; }
        .count { font-size: 10.5px; font-weight: 600; letter-spacing: 0; text-transform: none; padding: 1px 8px; border-radius: 999px; color: #2f5db8; background: rgba(90,140,255,.16); font-variant-numeric: tabular-nums; white-space: nowrap; }
        .count[hidden], .stop[hidden], .offer[hidden] { display: none; }
        .status { font-size: 13.5px; line-height: 1.3; font-weight: 550; letter-spacing: -.008em; color: #16161a; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; word-break: break-word; }
        .icon {
          flex: 0 0 30px; width: 30px; height: 30px; border: 0; border-radius: 50%; padding: 0; display: grid; place-items: center;
          background: transparent; color: #5c5c66; cursor: pointer; transition: background .15s ease, color .15s ease;
        }
        .icon:hover { background: rgba(20,30,50,.08); color: #111; }
        .stop {
          flex: 0 0 auto; height: 32px; padding: 0 8px 0 14px; border: 0; border-radius: 999px; display: flex; align-items: center; gap: 8px;
          background: rgba(255,69,58,.14); color: #d12b22; font: inherit; font-size: 12.5px; font-weight: 600; cursor: pointer; transition: background .15s ease, transform .15s ease;
        }
        .stop:hover { background: rgba(255,69,58,.24); } .stop:active { transform: scale(.96); }
        .stop kbd { font: inherit; font-size: 10px; font-weight: 600; padding: 2px 6px; border-radius: 6px; background: rgba(20,20,30,.08); color: #444; }
        .offer {
          flex: 0 0 auto; height: 32px; padding: 0 12px; border: 0; border-radius: 999px;
          background: rgba(218,119,86,.18); color: #c45c38; font: inherit; font-size: 12.5px; font-weight: 600;
          cursor: pointer; transition: background .15s ease, transform .15s ease;
        }
        .offer:hover { background: rgba(218,119,86,.28); } .offer:active { transform: scale(.96); }
        .fail-trace {
          position: absolute; inset: 0; z-index: 2; width: 100%; height: 100%;
          overflow: visible; pointer-events: none; opacity: 0;
        }
        .pill.fail .fail-trace { animation: fail-fade 1.2s ease-out 1; }
        .fail-trace path {
          fill: none; stroke: rgba(255,69,58,.98); stroke-width: 1.5; stroke-linecap: round;
          vector-effect: non-scaling-stroke; stroke-dasharray: 30 970; stroke-dashoffset: 0;
        }
        .pill.fail .fail-trace path { animation: trace-around 1.2s linear 1; }
        @keyframes fail-fade {
          0%, 100% { opacity: 0; }
          15%, 82% { opacity: 1; }
        }
        @keyframes trace-around { to { stroke-dashoffset: -1000; } }
        .extra-ai { margin: 8px 0; padding: 8px; border-radius: 10px; background: rgba(20,30,50,.05); }
        .extra-ai .extra-head { display: flex; justify-content: space-between; align-items: center; gap: 8px; margin-bottom: 4px; }
        .extra-ai .extra-head span { font-size: 11px; font-weight: 650; color: #3a3a44; }

        /* ---------- Settings popup ---------- */
        .sheet {
          position: absolute; left: 0; right: 0; bottom: calc(100% + 10px); pointer-events: auto; display: none;
          padding: 14px; border-radius: 20px; max-height: min(70vh, 560px); overflow: auto;
          background: linear-gradient(180deg, rgba(255,255,255,.9), rgba(246,248,255,.78));
          backdrop-filter: blur(28px) saturate(190%); -webkit-backdrop-filter: blur(28px) saturate(190%);
          box-shadow: 0 18px 48px rgba(20,30,70,.22), 0 0 0 .5px rgba(255,255,255,.9), 0 0 40px rgba(140,185,255,.28), inset 0 1px 0 rgba(255,255,255,.95);
          color: #1d1d22;
        }
        .sheet.open { display: block; animation: sheet-in .22s cubic-bezier(.2,.8,.2,1); }
        .sheet-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
        .sheet-head h2 { margin: 0; font-size: 13px; font-weight: 650; letter-spacing: -.01em; }
        .sheet-close {
          width: 28px; height: 28px; border: 0; border-radius: 50%; background: rgba(20,30,50,.08); color: #444;
          cursor: pointer; display: grid; place-items: center; font-size: 16px; line-height: 1;
        }
        .sheet-close:hover { background: rgba(20,30,50,.14); color: #111; }
        .sheet-sec { margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(20,30,50,.08); }
        .sheet-sec:first-of-type { margin-top: 0; padding-top: 0; border-top: 0; }
        .sheet-sec h3 { margin: 0 0 4px; font-size: 12px; font-weight: 650; }
        .sheet-sec p, .hint-line { margin: 0 0 8px; font-size: 11px; color: #6b6b75; }
        .sheet label { display: block; margin: 10px 0 5px; font-size: 11px; font-weight: 600; color: #3a3a44; }
        .sheet input[type="text"], .sheet input[type="password"] {
          width: 100%; height: 36px; border: 1px solid rgba(20,30,50,.12); border-radius: 10px;
          background: rgba(255,255,255,.7); color: #16161a; padding: 0 10px; font: inherit; outline: none;
        }
        .sheet input:focus { border-color: rgba(90,140,255,.7); box-shadow: 0 0 0 3px rgba(91,141,255,.18); }
        .key-row { display: flex; gap: 6px; }
        .key-row input { flex: 1; min-width: 0; }
        .seg { display: flex; gap: 4px; }
        .seg button, .ghost, .mini {
          border: 0; border-radius: 8px; padding: 7px 0; flex: 1; cursor: pointer; font: inherit; font-size: 11.5px; font-weight: 600;
          background: rgba(20,30,50,.08); color: #3a3a44;
        }
        .seg button { transition: background .18s ease, box-shadow .18s ease, transform .18s ease; }
        .seg button:hover { background: rgba(70,100,180,.13); }
        .seg button.on { background: linear-gradient(145deg,#4b80ef,#6864dc); color: #fff; box-shadow: 0 3px 9px rgba(70,90,180,.22), inset 0 1px 0 rgba(255,255,255,.25); }
        button:focus-visible { outline: 2px solid #6489e8; outline-offset: 3px; }
        .ghost, .mini { padding: 7px 10px; flex: 0 0 auto; }
        .ghost:hover, .mini:hover { background: rgba(20,30,50,.12); color: #111; }
        .primary { background: linear-gradient(135deg,#5b8dff,#8b6bff); color: #fff; border: 0; border-radius: 10px; padding: 8px 12px; font: inherit; font-size: 12px; font-weight: 600; cursor: pointer; }
        .actions { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 10px; }
        .switch { display: flex; align-items: center; gap: 8px; margin: 8px 0; font-size: 12px; color: #333; cursor: pointer; }
        .switch input { accent-color: #5b8dff; }
        .range-row { display: flex; justify-content: space-between; font-size: 12px; color: #333; }
        .sheet input[type="range"] { width: 100%; margin: 4px 0 0; }
        .sheet-note { font-size: 11px; color: #6b6b75; min-height: 16px; margin-top: 8px; white-space: pre-wrap; }
        .sheet-note.good { color: #8adcb4; } .sheet-note.bad { color: #ffabb4; }

        /* ---------- Virtual cursor ---------- */
        .cursor {
          position: fixed; left: 0; top: 0; z-index: 30; pointer-events: none; opacity: 0; transition: opacity .3s ease;
          transform: translate3d(-80px,-80px,0); will-change: transform;
        }
        .cursor.on { opacity: 1; }
        .cursor-glow {
          position: absolute; left: -17px; top: -15px; width: 54px; height: 54px; border-radius: 50%;
          background: radial-gradient(circle, rgba(150,190,255,.72) 0%, rgba(95,150,255,.52) 35%, rgba(80,130,255,.16) 56%, rgba(90,140,255,0) 72%);
          filter: blur(6px); animation: glow-breathe 1.8s ease-in-out infinite;
        }
        .arrow { display: block; width: 55px; height: 55px; margin: -3px 0 0 -7px; transform-origin: 8px 3px;
          filter: drop-shadow(0 1px 2px rgba(35,65,120,.55)) drop-shadow(0 2px 4px rgba(85,145,255,.65)) drop-shadow(0 4px 9px rgba(95,155,255,.42)) drop-shadow(0 5px 9px rgba(30,55,100,.28));
          transition: transform 0.1s linear; }
        .cursor.press .arrow { animation: cursor-tap .34s cubic-bezier(.22,.7,.3,1); }
        @keyframes cursor-tap { 0%,100% { transform: translateY(0) scale(1); } 38% { transform: translateY(5px) scale(.88); } 72% { transform: translateY(-2px) scale(1.02); } }
        .sub-cursor {
          position: fixed; left: 0; top: 0; z-index: 20; width: 34px; height: 34px;
          opacity: 0; transform: translate3d(-100px,-100px,0); pointer-events: none;
          transition: opacity .28s ease;
        }
        .sub-cursor.on { opacity: 1; }
        .sub-cursor .sub-visual {
          position: absolute; inset: 0; transform: scale(.2); opacity: 0;
          transition: transform .42s cubic-bezier(.16,1,.3,1), opacity .24s ease;
        }
        .sub-cursor.on .sub-visual { transform: scale(1); opacity: 1; }
        .sub-cursor.fading { opacity: 0; transition-duration: .34s; }
        .sub-cursor.fading .sub-visual { transform: scale(.45); }
        .sub-cursor.press .sub-arrow { transform: scale(.7); }
        .sub-cursor .sub-glow {
          position: absolute; left: -8px; top: -8px; width: 28px; height: 28px; border-radius: 50%;
          background: radial-gradient(circle, var(--sub-glow), transparent 72%);
          filter: blur(2px); animation: glow-breathe 1.8s ease-in-out infinite;
        }
        .sub-cursor .sub-arrow {
          position: absolute; left: 0; top: 0; display: block; width: 36px; height: 36px;
          margin: -1px 0 0 -1px; object-fit: contain; transform-origin: 2px 2px;
          filter: drop-shadow(0 0 4px rgba(255,255,255,.9)) drop-shadow(0 0 14px rgba(140,195,255,.8)) drop-shadow(0 4px 11px rgba(20,30,60,.3));
          transition: transform 0.1s linear;
        }
        .sub-cursor .sub-pill {
          position: absolute; left: 13px; top: 16px; max-width: 180px; padding: 5px 9px;
          border: 1px solid hsl(var(--sub-hue) 92% 72%);
          border-radius: 999px; background: rgba(255,255,255,.92); color: #24242b;
          box-shadow: 0 3px 14px var(--sub-glow), 0 0 0 1px var(--sub-glow);
          font: 600 10px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          white-space: nowrap; backdrop-filter: blur(12px);
        }
        .tag {
          position: absolute; left: 22px; top: 42px; white-space: nowrap; padding: 3px 10px; border-radius: 999px;
          box-sizing: border-box; max-width: min(320px, calc(100vw - 56px)); overflow: hidden;
          font-size: 12px; font-weight: 650; letter-spacing: -.01em; color: #fff;
          background: linear-gradient(135deg, #5b8dff, #8b6bff); box-shadow: 0 6px 20px rgba(70,90,255,.5), 0 0 16px rgba(120,170,255,.45), inset 0 1px 0 rgba(255,255,255,.3);
          transition: left .35s ease-out, width .35s ease-out, color .45s ease, background .45s ease, box-shadow .45s ease, backdrop-filter .45s ease, opacity .65s ease, transform .65s ease;
        }
        .tag span { display: inline-block; margin: 0; padding: 0; }
        .tag-thought {
          position: absolute; left: 10px; right: 10px; top: 3px; display: block; white-space: normal;
          margin: 0; padding: 0; font-size: 12px; line-height: 14px; overflow-wrap: anywhere;
          opacity: 0; transition: opacity .4s ease;
        }
        .thought-label { opacity: 1; transition: opacity .12s ease; }
        .cursor.thinking .tag {
          height: auto !important; min-height: 0 !important; white-space: normal; line-height: 14px;
          max-width: min(320px, calc(100vw - 56px)); padding: 3px 9px;
          color: #475569; font-style: normal; font-weight: 550;
          border: 1px solid rgba(255,255,255,.85); background: rgba(248,249,252,.94); box-shadow: 0 5px 16px rgba(25,35,60,.2), inset 0 1px 0 rgba(255,255,255,.85);
          backdrop-filter: blur(12px);
        }
        .cursor.thinking .tag-agent { display: none; }
        .cursor.thinking .tag-thought {
          position: static; left: auto; right: auto; top: auto; display: block;
          width: auto; max-width: 100%; white-space: nowrap; overflow-wrap: normal;
          opacity: 1;
        }
        .cursor.thinking .tag-thought.resizing {
          opacity: 1; transition: none;
        }
        .cursor.thinking .tag-thought.resizing .thought-label { opacity: 0; transition: none; }
        .cursor.thought-exiting .tag-thought { opacity: 0; }
        .cursor.thought-exiting .tag {
          opacity: 0; transform: scale(.96);
        }
        .target {
          position: fixed; left: 0; top: 0; width: 0; height: 0; border-radius: 9px; pointer-events: none; opacity: 0;
          border: 1.5px solid rgba(160,205,255,.95);
          box-shadow: 0 0 0 4px rgba(106,139,255,.2), 0 0 26px rgba(106,139,255,.6), inset 0 0 14px rgba(106,139,255,.18);
        }
        .target.on { animation: target-in .5s cubic-bezier(.2,.8,.2,1) forwards; }
        .target.off { opacity: 0; transition: opacity .35s ease; }
        .ripple {
          position: fixed; width: 22px; height: 22px; margin: -11px 0 0 -11px; border-radius: 50%; pointer-events: none;
          border: 2px solid rgba(150,200,255,.95); box-shadow: 0 0 14px rgba(106,139,255,.7); animation: ripple .65s cubic-bezier(.12,.72,.24,1) forwards;
        }

        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fluid-dot-left {
          0%, 100% { transform: translateX(-8px) scale(.78); opacity: .82; }
          38% { transform: translateX(-2px) scale(1.05); opacity: .95; }
          52% { transform: translateX(0) scale(1.15); opacity: 1; }
          68% { transform: translateX(-2px) scale(1.02); opacity: .95; }
        }
        @keyframes fluid-dot-center {
          0%, 100% { transform: translateX(0) scale(.88); opacity: .88; }
          38%, 68% { transform: translateX(0) scale(1.02); opacity: .95; }
          52% { transform: translateX(0) scale(1.18); opacity: 1; }
        }
        @keyframes fluid-dot-right {
          0%, 100% { transform: translateX(8px) scale(.78); opacity: .82; }
          38% { transform: translateX(2px) scale(1.05); opacity: .95; }
          52% { transform: translateX(0) scale(1.15); opacity: 1; }
          68% { transform: translateX(2px) scale(1.02); opacity: .95; }
        }
        @keyframes pulse-dot {
          0%, 100% { transform: scale(.92); opacity: .28; }
          50% { transform: scale(1.18); opacity: 1; }
        }
        @keyframes thought-bounce { 0%, 100% { transform: translate(var(--dot-x), 1px) scale(.9); opacity: .62; } 50% { transform: translate(var(--dot-x), -2px) scale(1.08); opacity: 1; } }
        @keyframes thought-spin { to { transform: rotate(360deg); } }
        @keyframes thought-blink { 0%, 100% { transform: scale(.65); opacity: .35; } 50% { transform: scale(1.25); opacity: 1; } }
        @keyframes flow { to { background-position: -300% 0; } }
        @keyframes breathe { 0%, 100% { opacity: .15; } 50% { opacity: 1; } }
        @keyframes breathe-soft { 0%, 100% { opacity: 0; } 50% { opacity: .5; } }
        @keyframes pulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(.7); opacity: .7; } }
        @keyframes target-in { from { opacity: 0; transform: scale(1.12); } to { opacity: 1; transform: scale(1); } }
        @keyframes ripple { from { transform: scale(.4); opacity: 1; } to { transform: scale(3.8); opacity: 0; } }
        @keyframes sheet-in { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
        @keyframes reminder-in {
          0% { opacity: 0; transform: translate(-50%, 8px); }
          10%, 78% { opacity: 1; transform: translate(-50%, 0); }
          100% { opacity: 0; transform: translate(-50%, -3px); }
        }
        @keyframes reminder-fade {
          0%, 100% { opacity: 0; }
          12%, 78% { opacity: 1; }
        }
        @keyframes pill-in {
          0% { transform: translateY(12px) scale(.94); opacity: 0; }
          58% { transform: translateY(-3px) scale(1.03); opacity: 1; }
          100% { transform: none; opacity: 1; }
        }
        @keyframes burst { 0% { opacity: .85; transform: scale(.9); } 100% { opacity: 0; transform: scale(1.22); } }
        @keyframes glow-breathe { 0%, 100% { opacity: .7; transform: scale(1); } 50% { opacity: 1; transform: scale(1.18); } }
        @media (max-width: 480px) { .pill { width: calc(100vw - 24px); } }
        @media (prefers-reduced-motion: reduce) {
          .ring, .halo, .halo2, .arc::before, .orb::before, .pill-orbit, .cursor-glow, .sub-glow, .dots, .orb-core { animation: none !important; }
          .dots-fluid { transition: none !important; }
          .scene[data-mode="peek"] .ring { opacity: .6; }
          .sparks { display: none; }
        }
      </style>
      <div class="scene" data-mode="idle">
        <div class="vignette"></div>
        <div class="halo2"></div>
        <div class="halo"></div>
        <div class="ring"></div>
        <div class="arc"></div>
        <canvas class="sparks"></canvas>
        <div class="hint"><b>Click anywhere</b> to start<i>·</i>Esc to cancel</div>
        <div class="gemini-reminder" role="status" aria-live="polite">
          This exercise can be solved with Gemini
          <svg class="reminder-trace" viewBox="0 0 300 44" preserveAspectRatio="none" aria-hidden="true">
            <defs><linearGradient id="reminder-gradient" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="300" y2="44">
              <stop offset="0%" stop-color="#5ee7df"/><stop offset="38%" stop-color="#8ec5ff"/>
              <stop offset="68%" stop-color="#6a8bff"/><stop offset="100%" stop-color="#b69cff"/>
              <animateTransform attributeName="gradientTransform" type="rotate" from="0 150 22" to="360 150 22" dur="3.6s" begin="indefinite" repeatCount="1"/>
            </linearGradient></defs>
            <path pathLength="1000"></path>
          </svg>
        </div>
        <div class="target"></div>
        <div class="cursor">
          <i class="cursor-glow"></i>
          <img class="arrow" alt="" width="32" height="32">
          <div class="tag"><span class="tag-agent">Agent</span><span class="tag-thought" aria-hidden="true"><span class="thought-label">Gemini is thinking…</span></span></div>
        </div>
        <div class="dock">
          <aside class="sheet" role="dialog" aria-label="Settings">
            <div class="sheet-head"><h2>Settings</h2><button class="sheet-close" type="button" aria-label="Close settings">×</button></div>
            <div class="sheet-sec">
              <h3>Automation</h3>
              <label>Local solving speed</label><div class="seg" data-local-pace role="group" aria-label="Local solving speed"><button type="button" data-pace="instant">Instant</button><button type="button" data-pace="smart">Smart</button><button type="button" data-pace="human">Human-like slow</button></div>
              <label class="switch"><input type="checkbox" data-global-auto-next> Auto-click next and solve next</label>
              <p class="hint-line" data-global-auto-next-status></p>
              <label class="switch"><input type="checkbox" data-allow-sub-agents> Allow sub-agents</label>
              <p class="hint-line" data-allow-sub-agents-status>Parallel cursors help with independent answer choices.</p>
            </div>
            <div class="sheet-sec" data-ex-wrap hidden>
              <h3 class="ex-title">Exercise</h3>
              <p class="hint-line ex-hint"></p>
              <div class="ex-fields"></div>
            </div>
            <div class="sheet-sec">
              <h3>Gemini connection</h3>
              <p>Stored in this Chrome profile. Used only when solving exercises.</p>
              <label for="umime-api-key">API key</label>
              <div class="key-row">
                <input id="umime-api-key" type="password" autocomplete="off" spellcheck="false" placeholder="Paste your Gemini key">
                <button class="ghost" type="button" data-toggle-key>Show</button>
              </div>
              <label for="umime-model">Model ID</label>
              <input id="umime-model" type="text" spellcheck="false" value="gemini-3.1-flash-lite">
              <div class="actions">
                <button class="primary" type="button" data-save-key>Save</button>
                <button class="ghost" type="button" data-test-key>Test</button>
                <button class="ghost" type="button" data-test-search>Test Google Search</button>
              </div>
              <div class="sheet-note" data-key-status></div>
            </div>
          </aside>
          <section class="pill" role="status" aria-live="polite" data-tone="busy" title="Drag to move">
            <i class="pill-burst"></i>
            <i class="pill-orbit"></i>
            <svg class="fail-trace" viewBox="0 0 380 64" preserveAspectRatio="none" aria-hidden="true"><path pathLength="1000"></path></svg>
        <span class="orb" data-activity="work">
          <i class="orb-core"><i></i></i>
          <span class="dots dots-fluid" aria-hidden="true"><b></b><b></b><b></b><b></b></span>
        </span>
            <div class="txt">
              <div class="status">Thinking…</div>
              <span class="count" hidden></span>
            </div>
            <button class="icon" type="button" title="Settings" aria-label="Settings">
              <svg viewBox="0 0 20 20" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 6h8M15 6h2M3 14h2M9 14h8"/><circle cx="13" cy="6" r="2"/><circle cx="7" cy="14" r="2"/></svg>
            </button>
            <button class="offer" type="button" hidden>Solve with Gemini</button>
            <button class="stop" type="button" aria-label="Stop agent">Stop <kbd>esc</kbd></button>
          </section>
        </div>
      </div>`;

    scene = shadow.querySelector('.scene');
    cursor = shadow.querySelector('.cursor');
    cursorTag = cursor.querySelector('.tag');
    cursorThought = cursor.querySelector('.tag-thought');
    cursorThoughtLabel = cursor.querySelector('.thought-label');
    const arrowImg = shadow.querySelector('.arrow');
    if (arrowImg) {
      try { arrowImg.src = chrome.runtime.getURL('cursor.svg'); }
      catch { arrowImg.src = 'cursor.svg'; }
    }
    sparkCanvas = shadow.querySelector('.sparks');
    sparkCtx = sparkCanvas ? sparkCanvas.getContext('2d') : null;
    sizeSparkCanvas();
    targetBox = shadow.querySelector('.target');
    dock = shadow.querySelector('.dock');
    pill = shadow.querySelector('.pill');
    sheet = shadow.querySelector('.sheet');
    exerciseHost = shadow.querySelector('.ex-fields');
    statusEl = shadow.querySelector('.status');
    countEl = shadow.querySelector('.count');
    gearBtn = shadow.querySelector('.icon');
    stopBtn = shadow.querySelector('.stop');
    offerBtn = shadow.querySelector('.offer');

    stopBtn.addEventListener('click', requestStop);
    offerBtn.addEventListener('click', acceptGeminiOffer);
    gearBtn.addEventListener('click', () => toggleSheet());
    sheet.querySelector('.sheet-close').addEventListener('click', () => toggleSheet(false));
    bindGeminiSheet();
    bindGlobalAutoNext();
    bindAllowSubAgents();
    send('settings-request');

    let drag = null;
    pill.addEventListener('pointerdown', e => {
      if (e.target.closest('button') || e.button !== 0) return;
      const r = dock.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      dock.style.transition = 'none'; dock.style.transform = 'none';
      dock.style.left = r.left + 'px'; dock.style.top = r.top + 'px'; dock.style.bottom = 'auto';
      pill.classList.add('dragging');
      try { pill.setPointerCapture(e.pointerId); } catch {}
    });
    pill.addEventListener('pointermove', e => {
      if (!drag) return;
      const r = dock.getBoundingClientRect();
      dock.style.left = Math.max(0, Math.min(window.innerWidth - r.width, e.clientX - drag.dx)) + 'px';
      dock.style.top = Math.max(0, Math.min(window.innerHeight - r.height, e.clientY - drag.dy)) + 'px';
    });
    const endDrag = () => { drag = null; pill.classList.remove('dragging'); };
    pill.addEventListener('pointerup', endDrag);
    pill.addEventListener('pointercancel', endDrag);

    document.documentElement.appendChild(host);
    console.info(`[Umíme Agent] overlay v${VERSION} ready`);
    send('ready');
  }

  function clearTimers() {
    for (const t of [hideTimer, activationTimer]) if (t) clearTimeout(t);
    hideTimer = activationTimer = null;
  }

  /* ---------------- cursor ---------------- */

  function placeCursor(x, y) {
    curX = x; curY = y;
    if (cursor) cursor.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  }
  function showCursor() {
    if (!cursor) return;
    if (!cursorPlaced) { placeCursor(curX, curY); cursorPlaced = true; }
    if (!cursor.classList.contains('on')) {
      const icon = cursor.querySelector('.arrow');
      if (icon && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) icon.animate([
        { opacity: 0, transform: 'translateY(7px) scale(.82)', filter: 'blur(3px)' },
        { opacity: 1, transform: 'translateY(-1px) scale(1.025)', offset: .72 },
        { opacity: 1, transform: 'translateY(0) scale(1)' }
      ], { duration: 320, easing: 'cubic-bezier(.2,.8,.2,1)' });
    }
    cursor.classList.add('on');
  }
  function hideCursor() {
    if (!cursor) return;
    cursor.classList.remove('on', 'idle', 'press');
    setCursorThinking(false);
    cursorPlaced = false;
    subCursors.forEach(helper => helper.remove());
    subCursors.clear();
    subCursorTokens.clear();
    subCursorTimers.forEach(timer => clearTimeout(timer));
    subCursorTimers.clear();
    hideTarget(true);
  }

  function getSubCursor(cursorId) {
    if (!shadow || !scene || !cursorId || cursorId > 3) return null;
    if (subCursors.has(cursorId)) return subCursors.get(cursorId);
    const hue = Math.floor(Math.random() * 360);
    const helper = document.createElement('div');
    helper.className = 'sub-cursor';
    helper.dataset.cursorId = String(cursorId);
    helper.style.setProperty('--sub-hue', String(hue));
    helper.style.setProperty('--sub-color', `hsl(${hue} 92% 58%)`);
    helper.style.setProperty('--sub-glow', `hsla(${hue}, 92%, 58%, .5)`);
    helper.innerHTML = `<span class="sub-visual"><i class="sub-glow"></i><img class="sub-arrow" alt="" width="24" height="24"><span class="sub-pill">Agent ${cursorId} · Working…</span></span>`;
    const subArrow = helper.querySelector('.sub-arrow');
    const mainArrow = cursor && cursor.querySelector('.arrow');
    if (subArrow) subArrow.src = mainArrow?.src || chrome.runtime.getURL('cursor.svg');
    const spawn = { x: curX + cursorId * 8, y: curY + cursorId * 6 };
    helper._position = spawn;
    helper.style.transform = `translate3d(${spawn.x}px, ${spawn.y}px, 0)`;
    scene.appendChild(helper);
    subCursors.set(cursorId, helper);
    return helper;
  }

  function moveSubCursor(x, y, requestId, cursorId) {
    const helper = getSubCursor(cursorId);
    if (!helper) {
      send('arrived', { requestId, cursorId });
      return;
    }
    helper.classList.add('on');
    const token = (subCursorTokens.get(cursorId) || 0) + 1;
    subCursorTokens.set(cursorId, token);
    const tx = Math.max(6, Math.min(window.innerWidth - 6, Number(x) || 0));
    const ty = Math.max(6, Math.min(window.innerHeight - 6, Number(y) || 0));
    const from = helper._position || { x: curX + cursorId * 8, y: curY + cursorId * 6 };
    const dx = tx - from.x, dy = ty - from.y;
    const dist = Math.hypot(dx, dy);
    const bend = Math.min(90, dist * 0.16) * (dx >= 0 ? -1 : 1);
    const cx = from.x + dx / 2 + (-dy / (dist || 1)) * bend;
    const cy = from.y + dy / 2 + (dx / (dist || 1)) * bend;
    const duration = Math.round(Math.max(420, Math.min(1250, 360 + Math.hypot(dx, dy) * 0.8)) * 0.88);
    let startedAt = 0;
    const frame = now => {
      if (subCursorTokens.get(cursorId) !== token) return;
      if (!startedAt) startedAt = now;
      const progress = Math.min(1, (now - startedAt) / duration);
      const eased = progress < .5 ? 4 * progress ** 3 : 1 - ((-2 * progress + 2) ** 3) / 2;
      const inverse = 1 - eased;
      const px = inverse * inverse * from.x + 2 * inverse * eased * cx + eased * eased * tx;
      const py = inverse * inverse * from.y + 2 * inverse * eased * cy + eased * eased * ty;
      helper._position = { x: px, y: py };
      helper.style.transform = `translate3d(${px}px, ${py}px, 0)`;
      if (progress < 1) requestAnimationFrame(frame);
      else send('arrived', { requestId, cursorId });
    };
    requestAnimationFrame(frame);
  }

  function pressSubCursor(cursorId, pressing) {
    const helper = subCursors.get(cursorId);
    if (helper) helper.classList.toggle('press', pressing);
  }

  function setCursorThinking(thinking, text = '') {
    if (!cursor || !cursorTag || !cursorThought || !cursorThoughtLabel) return;
    if (thoughtTimer) { cancelAnimationFrame(thoughtTimer); thoughtTimer = null; }
    const token = ++thoughtToken;
    if (!thinking) {
      activeGeminiRequestId = null;
      if (thoughtRevealTimer) { clearTimeout(thoughtRevealTimer); thoughtRevealTimer = null; }
      cursorThought.classList.remove('resizing');
      if (thoughtExitTimer) clearTimeout(thoughtExitTimer);
      if (!cursor.classList.contains('thinking')) return;
      cursor.classList.add('thought-exiting');
      thoughtExitTimer = setTimeout(() => {
        thoughtExitTimer = null;
        if (token !== thoughtToken) return;
        cursor.classList.remove('thinking', 'thought-exiting');
        cursorTag.style.left = '';
        cursorTag.style.width = '';
        cursorTag.style.maxWidth = '';
      }, 700);
      return;
    }

    if (thoughtExitTimer) { clearTimeout(thoughtExitTimer); thoughtExitTimer = null; }
    cursor.classList.remove('thought-exiting');
    const wasThinking = cursor.classList.contains('thinking');
    const nextText = String(text || (wasThinking ? cursorThoughtLabel.textContent : 'Thinking…')).slice(0, 40);
    const textChanged = cursorThoughtLabel.textContent !== nextText;
    const shouldRevealAfterResize = textChanged || !wasThinking || cursorThought.classList.contains('resizing');
    cursor.classList.add('thinking');
    const availableWidth = Math.max(60, Math.min(320, window.innerWidth - curX - 38));
    cursorTag.style.maxWidth = `${availableWidth}px`;
    const measureCanvas = document.createElement('canvas');
    const context = measureCanvas.getContext('2d');
    const style = getComputedStyle(cursorThoughtLabel);
    if (context) context.font = style.font;
    const textWidth = context ? context.measureText(nextText).width : 100;
    const width = Math.min(availableWidth, textWidth + 22);
    cursorTag.style.width = `${width}px`;
    cursorTag.style.left = `${Math.max(0, Math.min(22, window.innerWidth - curX - width - 8))}px`;

    if (shouldRevealAfterResize) {
      if (thoughtRevealTimer) { clearTimeout(thoughtRevealTimer); thoughtRevealTimer = null; }
      cursorThought.classList.add('resizing');
    }
    if (textChanged) cursorThoughtLabel.textContent = nextText;
    if (shouldRevealAfterResize) {
      if (thoughtTimer) { cancelAnimationFrame(thoughtTimer); thoughtTimer = null; }
      thoughtTimer = requestAnimationFrame(() => {
        thoughtTimer = null;
        if (token !== thoughtToken || !cursor.classList.contains('thinking')) return;
        thoughtRevealTimer = setTimeout(() => {
          thoughtRevealTimer = null;
          if (token !== thoughtToken || !cursor.classList.contains('thinking')) return;
          cursorThought.classList.remove('resizing');
        }, 90);
      });
    }
  }

  function moveCursor(x, y, requestId, fast = false) {
    if (!scene) mount();
    if (!scene) return;
    if (mode === 'idle') start('Working…');
    showCursor();
    cursor.classList.remove('idle');
    if (idleTimer) clearTimeout(idleTimer);
    const token = ++moveToken;
    const tx = Math.max(6, Math.min(window.innerWidth - 6, Number(x) || 0));
    const ty = Math.max(6, Math.min(window.innerHeight - 6, Number(y) || 0));
    const fx = curX, fy = curY;
    const dx = tx - fx, dy = ty - fy;
    const dist = Math.hypot(dx, dy);
    if (dist < 2) { done(); return; }
    // Slightly curved, human-like path: a quadratic bezier bent sideways.
    const bend = Math.min(90, dist * 0.16) * (dx >= 0 ? -1 : 1);
    const cx = fx + dx / 2 + (-dy / dist) * bend;
    const cy = fy + dy / 2 + (dx / dist) * bend;
    const duration = fast ? Math.max(180, Math.min(400, 140 + dist * .25)) : Math.max(450, Math.min(1000, 350 + dist * 0.65));
    let t0 = 0;
    const ease = p => p < .5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
    function done() {
      placeCursor(tx, ty);
      idleTimer = setTimeout(() => cursor && cursor.classList.add('idle'), 700);
      send('arrived', { requestId });
    }
    const frame = now => {
      if (token !== moveToken) return;
      if (!t0) t0 = now;
      const p = Math.min(1, (now - t0) / duration);
      const e = ease(p), u = 1 - e;
      placeCursor(u * u * fx + 2 * u * e * cx + e * e * tx, u * u * fy + 2 * u * e * cy + e * e * ty);
      if (p < 1) requestAnimationFrame(frame); else done();
    };
    requestAnimationFrame(frame);
  }

  function showTarget(x, y, w, h) {
    if (!targetBox) return;
    if (targetTimer) clearTimeout(targetTimer);
    const pad = 4;
    Object.assign(targetBox.style, {
      left: `${x - pad}px`, top: `${y - pad}px`, width: `${Math.max(8, w + pad * 2)}px`, height: `${Math.max(8, h + pad * 2)}px`
    });
    targetBox.classList.remove('off', 'on');
    void targetBox.offsetWidth;
    targetBox.classList.add('on');
    targetTimer = setTimeout(() => hideTarget(false), 1400);
  }
  function hideTarget(now) {
    if (!targetBox) return;
    targetBox.classList.remove('on');
    if (now) targetBox.classList.remove('off'); else targetBox.classList.add('off');
  }

  function press() {
    if (!cursor) return;
    cursor.classList.remove('press');
    void cursor.offsetWidth;
    cursor.classList.add('press');
    setTimeout(() => cursor && cursor.classList.remove('press'), 360);
  }

  function rippleAt(x, y) {
    if (!scene) return;
    const r = document.createElement('i');
    r.className = 'ripple';
    r.style.left = `${x}px`; r.style.top = `${y}px`;
    scene.appendChild(r);
    setTimeout(() => r.remove(), 750);
  }

  /* ---------------- modes ---------------- */

  function beginPeek() {
    if (mode === 'active' || mode === 'peek') return;
    if (!scene) mount();
    if (!scene) return;
    clearTimers();
    setMode('peek');
  }
  function cancelPeek() { if (mode === 'peek') setMode('idle'); }

  function activateFromGesture() {
    if (mode === 'active') return;
    if (!scene) mount();
    altDown = false;
    clearTimers();
    setMode('active');
    stopBtn.hidden = false;
    setStatus('Thinking…', 'busy');
    setCount(0);
    swallowClicksUntil = Date.now() + 600;
    cursorPlaced = false;
    showCursor();
    activationTimer = setTimeout(() => {
      if (mode === 'active' && Date.now() - lastStatusAt > 1500) {
        offerUnrecognized('Failed to solve');
      }
    }, 1900);
    send('activate', { x: curX, y: curY });
  }

  function start(label) {
    if (!scene) mount();
    if (!scene) return;
    if (activationTimer) { clearTimeout(activationTimer); activationTimer = null; }
    if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
    setOffering(false);
    setMode('active');
    stopBtn.hidden = false;
    setStatus(label || 'Working…', 'busy');
    showCursor();
  }

  function setOffering(on) {
    offeringGemini = !!on;
    if (offerBtn) offerBtn.hidden = !on;
    if (stopBtn) stopBtn.hidden = !!on;
  }

  function offerUnrecognized(text = 'This exercise isn’t recognized. Solve with Gemini?') {
    if (!scene) mount();
    if (!pill) return;
    clearTimers();
    setMode('active');
    if (activationTimer) { clearTimeout(activationTimer); activationTimer = null; }
    setOffering(true);
    hideCursor();
    setCursorThinking(false);
    setStatus(text, 'busy');
    const orb = pill.querySelector('.orb');
    if (orb) orb.dataset.activity = 'wait';
  }

  async function acceptGeminiOffer() {
    if (!offeringGemini) return;
    setOffering(false);
    if (activationTimer) { clearTimeout(activationTimer); activationTimer = null; }
    stopBtn.hidden = false;
    setStatus('Thinking…', 'busy');
    showCursor();
    send('gemini-solve', { x: curX, y: curY });
  }

  function playFail(text) {
    if (!pill) return;
    if (text) setStatus(text, 'error');
    const trace = pill.querySelector('.fail-trace');
    const path = trace && trace.querySelector('path');
    if (trace && path) {
      const width = pill.clientWidth;
      const height = pill.clientHeight;
      const inset = 1;
      const radius = Math.min(22, (height - inset * 2) / 2);
      trace.setAttribute('viewBox', `0 0 ${width} ${height}`);
      path.setAttribute('d', [
        `M ${inset + radius} ${inset}`,
        `H ${width - inset - radius}`,
        `Q ${width - inset} ${inset} ${width - inset} ${inset + radius}`,
        `V ${height - inset - radius}`,
        `Q ${width - inset} ${height - inset} ${width - inset - radius} ${height - inset}`,
        `H ${inset + radius}`,
        `Q ${inset} ${height - inset} ${inset} ${height - inset - radius}`,
        `V ${inset + radius}`,
        `Q ${inset} ${inset} ${inset + radius} ${inset}`,
        'Z'
      ].join(' '));
    }
    pill.classList.remove('fail');
    void pill.offsetWidth;
    pill.classList.add('fail');
    const orb = pill.querySelector('.orb');
    if (orb) orb.dataset.activity = 'idle';
    setTimeout(() => {
      if (!pill) return;
      pill.classList.remove('fail');
      if (mode === 'active' && !offeringGemini) {
        const current = statusEl?.textContent || '';
        if (/trying /i.test(current)) setStatus(current, 'busy');
      }
    }, 1300);
  }

  function finish(text, tone = 'ok', holdMs = 2600) {
    if (!scene) return;
    clearTimers();
    setGeminiDotCycle(false);
    setOffering(false);
    setMode('done');
    if (sheetOpen) {
      sheet.classList.add('open');
      scene.classList.add('settings-open');
    }
    stopBtn.hidden = true;
    setStatus(text || 'Finished', tone);
    if (tone === 'error') playFail();
    hideCursor();
    if (holdMs > 0) hideTimer = setTimeout(() => { if (mode === 'done') setMode('idle'); }, holdMs);
  }

  function requestStop() {
    if (mode === 'done') { clearTimers(); setMode('idle'); return; }
    if (mode !== 'active') return;
    send('stop-requested');
    finish('Stopped', 'stopped', 1800);
  }

  /* ---------------- input ---------------- */

  function onKeyDown(e) {
    if (e.key === 'Alt' && !e.repeat) {
      altDown = true;
      beginPeek();
      if (e.cancelable) e.preventDefault();
    } else if (e.key === 'Escape') {
      if (sheetOpen) toggleSheet(false);
      else if (mode === 'peek') cancelPeek();
      else if (mode === 'active') requestStop();
    }
  }
  function onKeyUp(e) {
    if (e.key !== 'Alt') return;
    const wasPeek = mode === 'peek';
    altDown = false;
    if (wasPeek) { cancelPeek(); if (e.cancelable) e.preventDefault(); }
  }
  function onPointerDown(e) {
    if (!(mode === 'peek' && altDown) || e.button !== 0) return;
    curX = e.clientX; curY = e.clientY;
    if (e.cancelable) e.preventDefault();
    e.stopImmediatePropagation();
    activateFromGesture();
  }
  function swallowClick(e) {
    if (Date.now() < swallowClicksUntil) { if (e.cancelable) e.preventDefault(); e.stopImmediatePropagation(); }
  }
  // While idle, remember where the real mouse is so the agent cursor starts from there.
  function trackMouse(e) { if (mode !== 'active' && !cursorPlaced) { curX = e.clientX; curY = e.clientY; } }

  function onMessage(e) {
    if (e.source !== window || !e.data || e.data.channel !== CONTROL_CHANNEL) return;
    const d = e.data;
    if (d.type === 'hello') send('ready');
    else if (d.type === 'gemini-reminder') {
      if (mode !== 'idle' || !scene || isMathHost) return;
      const reminder = shadow.querySelector('.gemini-reminder');
      const trace = reminder && reminder.querySelector('.reminder-trace');
      const path = trace && trace.querySelector('path');
      const gradient = trace && trace.querySelector('#reminder-gradient');
      const spin = gradient && gradient.querySelector('animateTransform');
      if (reminder && trace && path && gradient && spin) {
        const width = reminder.clientWidth;
        const height = reminder.clientHeight;
        const inset = 1;
        const radius = Math.min(height / 2, width / 2);
        trace.setAttribute('viewBox', `0 0 ${width} ${height}`);
        gradient.setAttribute('x2', String(width));
        gradient.setAttribute('y2', String(height));
        spin.setAttribute('from', `0 ${width / 2} ${height / 2}`);
        spin.setAttribute('to', `360 ${width / 2} ${height / 2}`);
        spin.beginElement();
        path.setAttribute('d', [
          `M ${inset + radius} ${inset}`,
          `H ${width - inset - radius}`,
          `Q ${width - inset} ${inset} ${width - inset} ${inset + radius}`,
          `V ${height - inset - radius}`,
          `Q ${width - inset} ${height - inset} ${width - inset - radius} ${height - inset}`,
          `H ${inset + radius}`,
          `Q ${inset} ${height - inset} ${inset} ${height - inset - radius}`,
          `V ${inset + radius}`,
          `Q ${inset} ${inset} ${inset + radius} ${inset}`,
          'Z'
        ].join(' '));
      }
      scene.dataset.reminder = 'show';
      setTimeout(() => { if (scene) delete scene.dataset.reminder; }, 3700);
    }
    else if (d.type === 'offer-gemini') offerUnrecognized(d.text);
    else if (d.type === 'start') { setGeminiDotCycle(false); setCursorThinking(false); start(conciseActivityStatus(d.label)); }
    else if (d.type === 'status') {
      if (d.localActive && mode === 'active') showCursor();
      const requestId = String(d.geminiRequestId || '');
      const newRequest = Boolean(requestId && requestId !== activeGeminiRequestId);
      activeGeminiRequestId = requestId || null;
      const statusText = String(d.text || '');
      const isWaiting = /retry|wait|rate limit|busy|not responding|hard time/i.test(statusText);
      const isStarting = newRequest || /^(?:Thinking about question\b|.*\bis thinking\b)/i.test(statusText);
      const thoughtText = isWaiting
        ? /hard time/i.test(statusText) ? 'Having a hard time…' : 'Waiting…'
        : isStarting ? 'Gemini is thinking…' : statusText;
      setCursorThinking(Boolean(requestId), thoughtText);
      setGeminiDotCycle(Boolean(requestId));
      const mainText = requestId
        ? isWaiting ? 'Waiting for AI…' : 'Thinking…'
        : conciseActivityStatus(statusText);
      if (mode === 'idle') start(mainText);
      else if (mode !== 'done') {
        setStatus(mainText, 'busy');
      }
    }
    else if (d.type === 'notice') { setGeminiDotCycle(false); setCursorThinking(false); setStatus(d.text || 'Paused. Check the exercise to continue.', 'stopped'); }
    else if (d.type === 'progress') setCount(Number(d.solved) || 0);
    else if (d.type === 'target') showTarget(Number(d.x) || 0, Number(d.y) || 0, Number(d.w) || 0, Number(d.h) || 0);
    else if (d.type === 'move') {
      const cursorId = Number(d.cursorId) || 0;
      if (cursorId > 0) moveSubCursor(d.x, d.y, d.requestId, cursorId);
      else moveCursor(d.x, d.y, d.requestId, d.fast === true);
    }
    else if (d.type === 'press') {
      const cursorId = Number(d.cursorId) || 0;
      if (cursorId > 0) pressSubCursor(cursorId, true);
      else press();
    }
    else if (d.type === 'release') pressSubCursor(Number(d.cursorId) || 0, false);
    else if (d.type === 'click') {
      const cursorId = Number(d.cursorId) || 0;
      if (cursorId > 0) pressSubCursor(cursorId, false);
      else { press(); rippleAt(curX, curY); }
    }
    else if (d.type === 'sub-agent-status') {
      const cursorId = Number(d.cursorId) || 0;
      const helper = getSubCursor(cursorId);
      const label = helper && helper.querySelector('.sub-pill');
      const text = String(d.text || 'Working…').slice(0, 24);
      if (helper && label) {
        label.textContent = `Agent ${cursorId} · ${text}`;
        if (text === 'Working…') {
          helper.classList.remove('fading');
          helper.classList.add('on');
          const timer = subCursorTimers.get(cursorId);
          if (timer) clearTimeout(timer);
          subCursorTimers.delete(cursorId);
        } else {
          const timer = setTimeout(() => {
            helper.classList.add('fading');
            const removeTimer = setTimeout(() => {
              helper.remove();
              subCursors.delete(cursorId);
              subCursorTokens.delete(cursorId);
              subCursorTimers.delete(cursorId);
            }, 360);
            subCursorTimers.set(cursorId, removeTimer);
          }, 450);
          subCursorTimers.set(cursorId, timer);
        }
      }
    }
    else if (d.type === 'complete') finish(d.text || 'Finished', 'ok');
    else if (d.type === 'stop') { if (mode === 'active') finish(d.text || 'Stopped', 'stopped', 1800); }
    else if (d.type === 'fail') { if (mode === 'active') playFail(d.text || 'The AI failed.'); }
    else if (d.type === 'error') { offerUnrecognized('Failed to solve'); }
    else if (d.type === 'exercise-settings') applyExerciseSettings(d);
  }

  function toggleSheet(force) {
    if (!sheet) return;
    sheetOpen = typeof force === 'boolean' ? force : !sheetOpen;
    sheet.classList.toggle('open', sheetOpen);
    if (scene) scene.classList.toggle('settings-open', sheetOpen);
    if (sheetOpen) {
      send('settings-request');
      loadGeminiSheet();
      renderExerciseSettings();
    }
  }

  function applyExerciseSettings(data) {
    if (!data || !data.id) return;
    exerciseSettings = data;
    const active = shadow && shadow.activeElement;
    if (active && active.matches && active.matches('[data-range]')) {
      const label = active.previousElementSibling && active.previousElementSibling.lastElementChild;
      if (label) label.textContent = '×' + Number(active.value).toFixed(1);
      return;
    }
    renderExerciseSettings();
  }

  function renderExerciseSettings() {
    if (!sheet || !exerciseHost) return;
    const wrap = sheet.querySelector('[data-ex-wrap]');
    if (!exerciseSettings) { wrap.hidden = true; exerciseHost.innerHTML = ''; return; }
    wrap.hidden = false;
    sheet.querySelector('.ex-title').textContent = exerciseSettings.title || 'Exercise';
    const values = exerciseSettings.values || {};
    const fields = exerciseSettings.fields || [];
    const activeChoice = fields.find(f => f.type === 'choice' && values[f.key]);
    const activeOpt = activeChoice && (activeChoice.options || []).find(o => o.id === values[activeChoice.key]);
    sheet.querySelector('.ex-hint').textContent = (activeOpt && activeOpt.hint) || '';
    exerciseHost.innerHTML = fields.map(field => {
      const showWhen = field.showWhen || {};
      const visible = Object.keys(showWhen).every(k => values[k] === showWhen[k]);
      if (!visible) return '';
      if (field.type === 'choice') {
        const opts = (field.options || []).map(o => `<button type="button" class="${values[field.key] === o.id ? 'on' : ''}" data-set="${field.key}" data-val="${o.id}">${o.label}</button>`).join('');
        return `<label>${field.label || ''}</label><div class="seg">${opts}</div>`;
      }
      if (field.type === 'range') {
        const n = Number(values[field.key]);
        return `<div class="range-row"><span>${field.label || ''}</span><span>×${n.toFixed(1)}</span></div><input type="range" min="${field.min}" max="${field.max}" step="${field.step}" value="${n}" data-range="${field.key}">`;
      }
      if (field.type === 'toggle') {
        return `<label class="switch"><input type="checkbox" data-toggle="${field.key}" ${values[field.key] ? 'checked' : ''}>${field.label || ''}</label>`;
      }
      if (field.type === 'action') {
        return `<div class="actions"><button class="mini" type="button" data-action="${field.key}">${field.label || 'Run'}</button></div>`;
      }
      return '';
    }).join('');
    exerciseHost.querySelectorAll('[data-set]').forEach(btn => btn.addEventListener('click', () => {
      send('settings-set', { id: exerciseSettings.id, values: { [btn.dataset.set]: btn.dataset.val } });
    }));
    exerciseHost.querySelectorAll('[data-range]').forEach(el => el.addEventListener('input', () => {
      send('settings-set', { id: exerciseSettings.id, values: { [el.dataset.range]: parseFloat(el.value) } });
    }));
    exerciseHost.querySelectorAll('[data-toggle]').forEach(el => el.addEventListener('change', () => {
      send('settings-set', { id: exerciseSettings.id, values: { [el.dataset.toggle]: el.checked } });
    }));
    exerciseHost.querySelectorAll('[data-action]').forEach(btn => btn.addEventListener('click', () => {
      send('settings-action', { id: exerciseSettings.id, action: btn.dataset.action });
    }));
  }

  function legacyAutoNextPreference() {
    try {
      const onPloty = !!document.querySelector('#plan table.grid, table.grid');
      const onSokoban = !!document.querySelector('#plan table.plan, table.plan');
      const ploty = localStorage.getItem('ploty-autosolve-next');
      const sokoban = localStorage.getItem('sokoban-autosolve-next');
      if (onPloty && ploty !== null) return ploty === '1';
      if (onSokoban && sokoban !== null) return sokoban === '1';
      if (sokoban !== null) return sokoban === '1';
      if (ploty !== null) return ploty === '1';
      const autoRun = localStorage.getItem('sokoban-autorun');
      const autoNext = localStorage.getItem('sokoban-autonext');
      if (autoRun !== null || autoNext !== null) return autoRun !== '0' && autoNext !== '0';
    } catch (error) {
      console.warn('[Umíme Agent] Could not read legacy auto-next preference:', error);
    }
    return true;
  }

  function bindGlobalAutoNext() {
    const pace = sheet.querySelector('[data-local-pace]');
    if(pace){
      const render=value=>pace.querySelectorAll('[data-pace]').forEach(button=>{const on=button.dataset.pace===value;button.classList.toggle('on',on);button.setAttribute('aria-pressed',String(on));});
      chrome.storage.local.get('localSolverPace').then(p=>render(p.localSolverPace||'smart'));
      pace.addEventListener('click',async event=>{const button=event.target.closest('[data-pace]');if(!button)return;await chrome.storage.local.set({localSolverPace:button.dataset.pace});render(button.dataset.pace);});
    }
    const input = sheet.querySelector('[data-global-auto-next]');
    const note = sheet.querySelector('[data-global-auto-next-status]');
    const showError = error => {
      note.textContent = `Could not save global automation setting: ${error?.message || error}`;
      console.error('[Umíme Agent] Could not save global automation setting:', error);
    };
    chrome.storage.local.get(AUTO_NEXT_STORAGE_KEY).then(async data => {
      if (typeof data[AUTO_NEXT_STORAGE_KEY] === 'boolean') {
        autoSolveNextExercises = data[AUTO_NEXT_STORAGE_KEY];
      } else {
        autoSolveNextExercises = legacyAutoNextPreference();
        await chrome.storage.local.set({ [AUTO_NEXT_STORAGE_KEY]: autoSolveNextExercises });
      }
      input.checked = autoSolveNextExercises;
      note.textContent = autoSolveNextExercises
        ? 'Enabled for all supported exercises.'
        : 'Disabled for all supported exercises.';
    }).catch(showError);

    input.addEventListener('change', async () => {
      const previous = autoSolveNextExercises;
      autoSolveNextExercises = input.checked;
      input.disabled = true;
      try {
        await chrome.storage.local.set({ [AUTO_NEXT_STORAGE_KEY]: autoSolveNextExercises });
        note.textContent = autoSolveNextExercises
          ? 'Enabled for all supported exercises.'
          : 'Disabled for all supported exercises.';
      } catch (error) {
        autoSolveNextExercises = previous;
        input.checked = previous;
        showError(error);
      } finally {
        input.disabled = false;
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || typeof changes[AUTO_NEXT_STORAGE_KEY]?.newValue !== 'boolean') return;
      autoSolveNextExercises = changes[AUTO_NEXT_STORAGE_KEY].newValue;
      input.checked = autoSolveNextExercises;
      note.textContent = autoSolveNextExercises
        ? 'Enabled for all supported exercises.'
        : 'Disabled for all supported exercises.';
    });
  }

  function bindAllowSubAgents() {
    const input = sheet.querySelector('[data-allow-sub-agents]');
    const note = sheet.querySelector('[data-allow-sub-agents-status]');
    const showError = error => {
      note.textContent = `Could not save sub-agent setting: ${error?.message || error}`;
      console.error('[Umíme Agent] Could not save sub-agent setting:', error);
    };

    chrome.storage.local.get(ALLOW_SUB_AGENTS_STORAGE_KEY).then(data => {
      allowSubAgents = data[ALLOW_SUB_AGENTS_STORAGE_KEY] === true;
      input.checked = allowSubAgents;
      note.textContent = allowSubAgents
        ? 'Enabled for independent answer choices and Ploty in Smart/Instant pace.'
        : 'Disabled: eligible actions use one cursor at a time.';
    }).catch(showError);

    input.addEventListener('change', async () => {
      const previous = allowSubAgents;
      allowSubAgents = input.checked;
      input.disabled = true;
      try {
        await chrome.storage.local.set({ [ALLOW_SUB_AGENTS_STORAGE_KEY]: allowSubAgents });
        note.textContent = allowSubAgents
          ? 'Enabled for independent answer choices and Ploty in Smart/Instant pace.'
          : 'Disabled: eligible actions use one cursor at a time.';
      } catch (error) {
        allowSubAgents = previous;
        input.checked = previous;
        showError(error);
      } finally {
        input.disabled = false;
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || typeof changes[ALLOW_SUB_AGENTS_STORAGE_KEY]?.newValue !== 'boolean') return;
      allowSubAgents = changes[ALLOW_SUB_AGENTS_STORAGE_KEY].newValue;
      input.checked = allowSubAgents;
      note.textContent = allowSubAgents
        ? 'Enabled for independent answer choices and Ploty in Smart/Instant pace.'
        : 'Disabled: eligible actions use one cursor at a time.';
    });
  }

  function bindGeminiSheet() {
    if (!sheet) return;
    const keyEl = sheet.querySelector('#umime-api-key');
    const modelEl = sheet.querySelector('#umime-model');
    const note = sheet.querySelector('[data-key-status]');
    const setNote = (text, kind = '') => { note.textContent = text || ''; note.className = 'sheet-note' + (kind ? ' ' + kind : ''); };
    sheet.querySelector('[data-toggle-key]').addEventListener('click', ev => {
      const showing = keyEl.type === 'text';
      keyEl.type = showing ? 'password' : 'text';
      ev.currentTarget.textContent = showing ? 'Show' : 'Hide';
    });
    sheet.querySelector('[data-save-key]').addEventListener('click', async () => {
      try {
        const apiKey = keyEl.value.trim();
        const model = modelEl.value.trim() || 'gemini-3.1-flash-lite';
        if (!/^[a-zA-Z0-9._-]+$/.test(model)) throw new Error('Model ID contains unsupported characters.');
        if (!apiKey) throw new Error('Paste a Gemini API key first.');
        await chrome.storage.local.set({ geminiApiKey: apiKey, geminiModel: model });
        setNote('Settings saved in this Chrome profile.', 'good');
      } catch (error) { setNote(error?.message || String(error), 'bad'); }
    });
    sheet.querySelector('[data-test-key]').addEventListener('click', async ev => {
      const btn = ev.currentTarget;
      try {
        const apiKey = keyEl.value.trim();
        const model = modelEl.value.trim() || 'gemini-3.1-flash-lite';
        if (!apiKey) throw new Error('Paste a Gemini API key first.');
        btn.disabled = true; btn.textContent = 'Testing…';
        await chrome.storage.local.set({ geminiApiKey: apiKey, geminiModel: model });
        const result = await chrome.runtime.sendMessage({ type: 'UMIME_GEMINI_TEST', apiKey, model });
        if (!result?.ok) throw new Error(result?.error || 'Gemini rejected the test request.');
        setNote(result.message || 'Gemini connection successful.', 'good');
      } catch (error) { setNote(error?.message || String(error), 'bad'); }
      finally { btn.disabled = false; btn.textContent = 'Test'; }
    });
    sheet.querySelector('[data-test-search]').addEventListener('click', async ev => {
      const btn = ev.currentTarget;
      try {
        const apiKey = keyEl.value.trim();
        const model = modelEl.value.trim() || 'gemini-3.1-flash-lite';
        if (!apiKey) throw new Error('Paste a Gemini API key first.');
        if (!/^[a-zA-Z0-9._-]+$/.test(model)) throw new Error('Model ID contains unsupported characters.');
        btn.disabled = true; btn.textContent = 'Searching…';
        await chrome.storage.local.set({ geminiApiKey: apiKey, geminiModel: model });
        const result = await chrome.runtime.sendMessage({ type: 'UMIME_GEMINI_SEARCH_TEST', apiKey, model });
        if (!result?.ok) throw new Error(result?.error || 'Google Search grounding test failed.');
        setNote(result.message || 'Google Search grounding works.', 'good');
      } catch (error) { setNote(error?.message || String(error), 'bad'); }
      finally { btn.disabled = false; btn.textContent = 'Test Google Search'; }
    });
  }

  async function loadGeminiSheet() {
    if (!sheet) return;
    try {
      const data = await chrome.storage.local.get(['geminiApiKey', 'geminiModel']);
      await chrome.storage.local.remove(['aiProviders']);
      const keyEl = sheet.querySelector('#umime-api-key');
      const modelEl = sheet.querySelector('#umime-model');
      if (keyEl && !keyEl.value) keyEl.value = data.geminiApiKey || '';
      if (modelEl) modelEl.value = data.geminiModel || 'gemini-3.1-flash-lite';
      const note = sheet.querySelector('[data-key-status]');
      if (note && !note.textContent) note.textContent = data.geminiApiKey
        ? 'Gemini settings loaded from this Chrome profile.'
        : 'Add a Gemini key to connect.';
    } catch (error) {
      const note = sheet.querySelector('[data-key-status]');
      if (note) note.textContent = `Could not load AI settings: ${error?.message || error}`;
    }
  }

  function sizeSparkCanvas() {
    if (!sparkCanvas || !sparkCtx) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    sparkCanvas.width = Math.floor(window.innerWidth * dpr);
    sparkCanvas.height = Math.floor(window.innerHeight * dpr);
    sparkCanvas.style.width = window.innerWidth + 'px';
    sparkCanvas.style.height = window.innerHeight + 'px';
    sparkCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function spawnSpark() {
    const w = window.innerWidth, h = window.innerHeight;
    let t = Math.random() * (2 * (w + h));
    const inset = 1 + Math.random() * 3;
    let x, y, vx, vy;
    const drift = 0.18 + Math.random() * 0.55;
    if (t < w) { x = t; y = inset; vx = (Math.random() - 0.5) * 0.25; vy = drift; }
    else if ((t -= w) < h) { x = w - inset; y = t; vx = -drift; vy = (Math.random() - 0.5) * 0.25; }
    else if ((t -= h) < w) { x = t; y = h - inset; vx = (Math.random() - 0.5) * 0.25; vy = -drift; }
    else { x = inset; y = t - w; vx = drift; vy = (Math.random() - 0.5) * 0.25; }
    sparks.push({ x, y, vx, vy, life: 0.55 + Math.random() * 0.45, size: 0.55 + Math.random() * 1.35 });
  }

  function tickSparks() {
    sparkRaf = 0;
    if (!sparkCtx) return;
    const live = mode === 'active' || mode === 'peek';
    if (!live && !sparks.length) { sparkCtx.clearRect(0, 0, window.innerWidth, window.innerHeight); return; }
    sparkRaf = requestAnimationFrame(tickSparks);
    if (!reduceMotion) {
      const n = mode === 'active' ? 8 : mode === 'peek' ? 3 : 0;
      for (let i = 0; i < n; i++) spawnSpark();
    }
    if (sparks.length > 260) sparks.splice(0, sparks.length - 260);
    sparkCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    for (let i = sparks.length - 1; i >= 0; i--) {
      const s = sparks[i];
      s.x += s.vx; s.y += s.vy; s.life -= 0.014;
      if (s.life <= 0) { sparks.splice(i, 1); continue; }
      sparkCtx.beginPath();
      sparkCtx.fillStyle = `rgba(220,240,255,${Math.max(0, s.life) * 0.9})`;
      sparkCtx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
      sparkCtx.fill();
    }
  }

  function startSparks() {
    if (reduceMotion) return;
    sizeSparkCanvas();
    if (!sparkRaf) sparkRaf = requestAnimationFrame(tickSparks);
  }

  window.addEventListener('resize', sizeSparkCanvas, { passive: true });
  window.addEventListener('keydown', onKeyDown, true);
  window.addEventListener('keyup', onKeyUp, true);
  window.addEventListener('pointerdown', onPointerDown, true);
  window.addEventListener('pointermove', trackMouse, { capture: true, passive: true });
  for (const type of ['mousedown', 'mouseup', 'click']) window.addEventListener(type, swallowClick, true);
  window.addEventListener('message', onMessage, false);
  window.addEventListener('blur', () => { altDown = false; cancelPeek(); });

  if (document.documentElement) mount();
  else {
    const observer = new MutationObserver(() => {
      if (!document.documentElement) return;
      mount();
      observer.disconnect();
    });
    observer.observe(document, { childList: true, subtree: true });
  }
})();
