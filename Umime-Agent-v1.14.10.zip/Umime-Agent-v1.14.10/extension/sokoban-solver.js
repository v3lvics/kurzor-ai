(function () {
  'use strict';
  const VERSION = '4.7-extension';
  const FAST_DELAY_MS = 12;
  const MEDIUM_DELAY_MS = 150;
  const MAX_NODES = 2000000;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rand = (a, b) => a + Math.random() * (b - a);
  const bell = (a, b) => a + (b - a) * (Math.random() + Math.random()) / 2;   // bell-shaped, less robotic than uniform
  const debug = { version: VERSION };
  /* -------------------------- AI visual overlay bridge -------------------------- */
  const AGENT_CONTROL_CHANNEL = 'umime-ai-control';
  const AGENT_EVENT_CHANNEL = 'umime-ai-overlay';
  let agentOverlayReady = false;
  let agentRequestSeq = 0;
  const agentMoveWaiters = new Map();

  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.channel !== AGENT_EVENT_CHANNEL) return;
    if (e.data.type === 'ready') agentOverlayReady = true;
    if (e.data.type === 'arrived' && agentMoveWaiters.has(e.data.requestId)) {
      agentMoveWaiters.get(e.data.requestId)();
    }
  });

  // The extension overlay loads at document_start; ask it for readiness.
  // Ask for readiness explicitly instead of relying on an event we may have missed.
  window.postMessage({ channel: AGENT_CONTROL_CHANNEL, type: 'hello' }, '*');

  function agentCommand(type, extra) {
    if (!agentOverlayReady) return;
    window.postMessage(Object.assign({ channel: AGENT_CONTROL_CHANNEL, type }, extra || {}), '*');
  }

  function agentStart(label) { agentCommand('start', { label }); }
  function agentStatus(text) { agentCommand('status', { text }); }
  function agentClick() { agentCommand('click'); }
  function agentFinish(type, text) { agentCommand(type || 'complete', { text }); }

  async function agentMoveTo(el) {
    if (!agentOverlayReady || !el || !el.getBoundingClientRect) return false;
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) return false;
    const requestId = 'umime-agent-' + (++agentRequestSeq);
    return new Promise(resolve => {
      const timeout = setTimeout(() => {
        agentMoveWaiters.delete(requestId);
        resolve(false);
      }, 2200);
      agentMoveWaiters.set(requestId, () => {
        clearTimeout(timeout);
        agentMoveWaiters.delete(requestId);
        resolve(true);
      });
      window.postMessage({
        channel: AGENT_CONTROL_CHANNEL,
        type: 'move',
        requestId,
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      }, '*');
    });
  }

  let busy = false;
  let stopFlag = false;
  let chosen = -1;                 // index of the input strategy that worked

  const L = 'udlr';
  const OFF = [[0, -1], [0, 1], [-1, 0], [1, 0]];
  const OPP = [1, 0, 3, 2];
  const ARROW_ID = { u: 'up', d: 'down', l: 'left', r: 'right' };
  const KEY = { u: ['ArrowUp', 38], d: ['ArrowDown', 40], l: ['ArrowLeft', 37], r: ['ArrowRight', 39] };

  /* ---------------------------------------------------------------- modes */
  const MODES = {
    human: {
      label: 'Human', hint: 'Thinks first, uneven rhythm, small hesitations.',
      think: [700, 2000], click: [130, 300], turnExtra: [60, 180],
      hesitateP: 0.08, hesitate: [400, 1100], hover: [20, 70]
    },
    medium: { label: 'Medium', hint: 'Steady 150 ms per move.' },
    instant: { label: 'Instant', hint: 'No delays, no hovering.' }
  };
  let mode = 'medium';
  let humanScale = 1.3;            // Human mode pace: 1 = original speed, higher = slower
  try { const h = parseFloat(localStorage.getItem('sokoban-humanscale')); if (h >= 0.5 && h <= 3) humanScale = h; } catch (e) { /* ignore */ }
  const AUTO_NEXT_STORAGE_KEY = 'autoSolveNextExercises';
  let autoSolveNext = true;
  const autoNextReady = chrome.storage.local.get(AUTO_NEXT_STORAGE_KEY).then(data => {
    if (typeof data[AUTO_NEXT_STORAGE_KEY] === 'boolean') autoSolveNext = data[AUTO_NEXT_STORAGE_KEY];
  }).catch(error => console.error('[Sokoban] Could not load global auto-next setting:', error));
  try { const m = localStorage.getItem('sokoban-mode'); if (MODES[m]) mode = m; } catch (e) { /* ignore */ }

  /* ---------------------------------------------------------- read page */
  /* td classes: f floor | fg free goal | b box | bg box on goal
   *             w* wall | s[udlr][g][p] player (g = on goal, p = push anim) */
  function parseTile(c) {
    if (c[0] === 'w') return { wall: true };
    if (c[0] === 's') return { player: true, goal: c.includes('g') };
    if (c[0] === 'b') return { box: true, goal: c.includes('g') };
    if (c === 'fg') return { goal: true };
    if (c === 'f' || c === '') return {};
    console.warn('[Sokoban] unknown tile class:', c);
    return null;
  }

  function findSokobanTable() {
    const table = document.querySelector('#plan table.plan') || document.querySelector('table.plan');
    if (!table) return null;
    const tiles = [...table.querySelectorAll('td')].map(td => (td.className || '').trim().split(/\s+/)[0] || 'f');
    const hasPlayer = tiles.some(tile => /^s[udlr](?:g)?(?:p)?$/.test(tile));
    const hasBox = tiles.some(tile => /^b(?:g)?$/.test(tile));
    const hasGoal = tiles.some(tile => tile === 'fg' || ((/^s[udlr]/.test(tile) || tile[0] === 'b') && tile.includes('g')));
    return hasPlayer && hasBox && hasGoal ? table : null;
  }

  function readBoard() {
    const table = findSokobanTable();
    if (!table) throw new Error('No Sokoban board found on this page.');
    const rows = [...table.querySelectorAll('tr')].map(tr => [...tr.children]);
    const H = rows.length, W = Math.max(...rows.map(r => r.length));
    const wall = new Uint8Array(W * H), goals = [], boxes = [];
    let player = -1;
    rows.forEach((row, y) => row.forEach((td, x) => {
      const i = y * W + x;
      const c = (td.className || '').trim().split(/\s+/)[0] || 'f';
      const t = parseTile(c);
      if (!t) return;
      if (t.wall) wall[i] = 1;
      if (t.player) player = i;
      if (t.box) boxes.push(i);
      if (t.goal) goals.push(i);
    }));
    if (player < 0) throw new Error('Player not found on the board.');
    if (!boxes.length) throw new Error('No boxes found on the board.');
    if (boxes.length !== goals.length)
      throw new Error('Boxes (' + boxes.length + ') and goals (' + goals.length + ') differ; see console for unknown tiles.');
    return { table, W, H, wall, goals, boxes, player };
  }

  /* ---------------------------------------------------- solver (A* on pushes) */
  class Heap {
    constructor() { this.a = []; }
    get size() { return this.a.length; }
    push(n) {
      const a = this.a; a.push(n);
      let i = a.length - 1;
      while (i > 0) {
        const p = (i - 1) >> 1;
        if (a[p].f <= a[i].f) break;
        [a[p], a[i]] = [a[i], a[p]]; i = p;
      }
    }
    pop() {
      const a = this.a, top = a[0], last = a.pop();
      if (a.length) {
        a[0] = last;
        let i = 0;
        for (;;) {
          const l = 2 * i + 1, r = l + 1;
          let m = i;
          if (l < a.length && a[l].f < a[m].f) m = l;
          if (r < a.length && a[r].f < a[m].f) m = r;
          if (m === i) break;
          [a[m], a[i]] = [a[i], a[m]]; i = m;
        }
      }
      return top;
    }
  }

  function solve(S) {
    const { W, H, wall, goals, boxes, player } = S;
    const N = W * H;
    const nbr = new Int32Array(N * 4).fill(-1);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = y * W + x;
      if (wall[i]) continue;
      for (let d = 0; d < 4; d++) {
        const nx = x + OFF[d][0], ny = y + OFF[d][1];
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const ni = ny * W + nx;
        if (!wall[ni]) nbr[i * 4 + d] = ni;
      }
    }

    // reverse push distance from goals; Infinity = dead square
    const dist = new Array(N).fill(Infinity);
    const q = [];
    goals.forEach(g => { dist[g] = 0; q.push(g); });
    for (let h = 0; h < q.length; h++) {
      const b = q[h];
      for (let d = 0; d < 4; d++) {
        const a = nbr[b * 4 + OPP[d]]; if (a < 0) continue;
        const p = nbr[a * 4 + OPP[d]]; if (p < 0) continue;
        if (dist[a] === Infinity) { dist[a] = dist[b] + 1; q.push(a); }
      }
    }

    const flood = (start, occ) => {
      const seen = new Uint8Array(N), st = [start];
      seen[start] = 1;
      while (st.length) {
        const c = st.pop();
        for (let d = 0; d < 4; d++) {
          const n = nbr[c * 4 + d];
          if (n >= 0 && !seen[n] && !occ[n]) { seen[n] = 1; st.push(n); }
        }
      }
      return seen;
    };

    const hCost = bs => bs.reduce((s, b) => s + dist[b], 0);
    const start = { bs: boxes.slice().sort((a, b) => a - b), p: player, g: 0, par: null, mv: null };
    start.f = hCost(start.bs);
    if (start.f === Infinity) return null;

    const heap = new Heap(); heap.push(start);
    const closed = new Set();
    let nodes = 0;

    while (heap.size) {
      const n = heap.pop();
      const occ = new Uint8Array(N); n.bs.forEach(b => occ[b] = 1);
      const reach = flood(n.p, occ);
      let norm = 0; while (!reach[norm]) norm++;
      const key = n.bs.join(',') + '|' + norm;
      if (closed.has(key)) continue;
      closed.add(key);
      if (n.bs.every(b => dist[b] === 0)) return buildMoves(n);
      if (++nodes > MAX_NODES) return null;

      for (let bi = 0; bi < n.bs.length; bi++) {
        const b = n.bs[bi];
        for (let d = 0; d < 4; d++) {
          const stand = nbr[b * 4 + OPP[d]];
          if (stand < 0 || !reach[stand]) continue;
          const to = nbr[b * 4 + d];
          if (to < 0 || occ[to] || dist[to] === Infinity) continue;
          const nb = n.bs.slice(); nb[bi] = to; nb.sort((a, c) => a - c);
          const g = n.g + 1;
          heap.push({ bs: nb, p: b, g, f: g + hCost(nb), par: n, mv: { from: b, d } });
        }
      }
    }
    return null;

    function pathTo(from, target, occ2) {
      if (from === target) return '';
      const prev = new Int32Array(N).fill(-2), how = new Array(N);
      const qq = [from]; prev[from] = -1;
      for (let h = 0; h < qq.length; h++) {
        const c = qq[h];
        if (c === target) break;
        for (let d = 0; d < 4; d++) {
          const nx = nbr[c * 4 + d];
          if (nx >= 0 && prev[nx] === -2 && !occ2[nx]) { prev[nx] = c; how[nx] = d; qq.push(nx); }
        }
      }
      let s = '';
      for (let c = target; prev[c] !== -1; c = prev[c]) s = L[how[c]] + s;
      return s;
    }

    function buildMoves(goalNode) {
      const pushes = [];
      for (let n = goalNode; n.mv; n = n.par) pushes.push(n.mv);
      pushes.reverse();
      const occ2 = new Uint8Array(N); boxes.forEach(b => occ2[b] = 1);
      let p = player, out = '';
      for (const { from, d } of pushes) {
        out += pathTo(p, nbr[from * 4 + OPP[d]], occ2) + L[d];
        occ2[from] = 0; occ2[nbr[from * 4 + d]] = 1;
        p = from;
      }
      return out;
    }
  }

  /* -------------------------------------------------------------- input */
  const boardSnap = () => {
    const t = document.querySelector('#plan table.plan') || document.querySelector('table.plan');
    return t ? t.innerHTML : '';
  };

  function fire(el, type) {
    const r = el.getBoundingClientRect();
    const init = {
      bubbles: true, cancelable: true, button: 0,
      buttons: type.endsWith('down') ? 1 : 0, detail: type === 'click' ? 1 : 0,
      clientX: r.left + r.width / 2 + (Math.random() - 0.5) * r.width * 0.5,
      clientY: r.top + r.height / 2 + (Math.random() - 0.5) * r.height * 0.5
    };
    let ev;
    if (type.startsWith('pointer') && typeof PointerEvent === 'function')
      ev = new PointerEvent(type, Object.assign({ pointerId: 1, pointerType: 'mouse', isPrimary: true }, init));
    else
      ev = new MouseEvent(type.replace('pointer', 'mouse'), init);
    el.dispatchEvent(ev);
  }

  function fireKey(c) {
    const [key, code] = KEY[c];
    ['keydown', 'keyup'].forEach(t => {
      const ev = new KeyboardEvent(t, { key, code: key, keyCode: code, which: code, bubbles: true, cancelable: true });
      document.dispatchEvent(ev);
    });
  }

  const STRATEGIES = [
    { name: 'click',               run: (el) => { fire(el, 'click'); } },
    { name: 'mousedown+mouseup',   run: (el) => { fire(el, 'mousedown'); fire(el, 'mouseup'); } },
    { name: 'pointer+mouse+click', run: (el) => {
        fire(el, 'pointerdown'); fire(el, 'mousedown'); fire(el, 'pointerup'); fire(el, 'mouseup'); fire(el, 'click'); } },
    { name: 'keyboard',            run: (el, c) => { fireKey(c); } }
  ];

  async function sendMove(c, M) {
    const el = document.getElementById(ARROW_ID[c]);
    // When arrow controls exist, follow the real button. For keyboard-only pages,
    // move the visual pointer to the cell the player is about to enter.
    await agentMoveTo(el || nextPlayerCell(c));
    if (el && M && M.hover) {
      fire(el, 'mouseover'); fire(el, 'mousemove');
      await sleep(bell(M.hover[0], M.hover[1]));
    }
    if (chosen >= 0) {
      STRATEGIES[chosen].run(el, c);
      agentClick();
      return true;
    }
    const before = boardSnap();
    for (let i = 0; i < STRATEGIES.length; i++) {
      if (!el && i !== STRATEGIES.length - 1) continue;      // no arrow button: only keyboard is possible
      STRATEGIES[i].run(el, c);
      await sleep(200);
      if (boardSnap() !== before) {
        chosen = i;
        debug.strategy = STRATEGIES[i].name;
        agentClick();
        return true;
      }
    }
    return false;
  }

  function delayFor(M, i, moves) {
    let d = bell(M.click[0], M.click[1]);
    if (i > 0 && moves[i] === moves[i - 1]) d *= 0.7;         // rhythm on straight runs
    else if (i > 0) d += bell(M.turnExtra[0], M.turnExtra[1]); // slower on turns
    if (Math.random() < M.hesitateP) d += bell(M.hesitate[0], M.hesitate[1]);
    return d * humanScale;
  }

  function nextPlayerCell(c) {
    try {
      const S = readBoard();
      const offset = { u: -S.W, d: S.W, l: -1, r: 1 }[c];
      const target = S.player + offset;
      if (target < 0 || target >= S.W * S.H) return S.table;
      const rows = [...S.table.querySelectorAll('tr')];
      return rows[Math.floor(target / S.W)]?.children[target % S.W] || S.table;
    } catch (_) {
      return document.querySelector('#plan table.plan') || document.querySelector('table.plan');
    }
  }

  /* ---------------------------------------------------------- main action */
  async function solveAndClick(setStatus) {
    const S = readBoard();
    debug.size = S.H + 'x' + S.W; debug.mode = mode;
    debug.boxes = S.boxes.length;

    setStatus('Solving…');
    await sleep(20);
    const t0 = performance.now();
    const moves = solve(S);
    debug.solver = Math.round(performance.now() - t0) + ' ms';
    if (!moves) throw new Error('No solution found for this board.');
    debug.moves = moves;
    console.log('[Sokoban]', moves, '(' + moves.length + ' moves)');

    const M = MODES[mode];
    const human = mode === 'human';
    if (human) { setStatus('Thinking…'); await sleep(bell(M.think[0], M.think[1]) * humanScale); }

    let sinceBreak = 0, nextBreak = Math.round(rand(8, 16));
    for (let i = 0; i < moves.length; i++) {
      if (stopFlag) { setStatus('Stopped (' + i + '/' + moves.length + ').', 'warn'); return; }
      // the game may re-render the board table after each move, so look it up fresh
      // (and wait briefly if it is mid-redraw) instead of holding on to the old element
      for (let w = 0; w < 20 && !document.querySelector('#plan table.plan'); w++) await sleep(50);
      const ok = await sendMove(moves[i], human ? M : null);
      if (!ok) throw new Error('The page did not react to simulated input.');
      setStatus('Playing… ' + (i + 1) + '/' + moves.length);
      await sleep(human ? delayFor(M, i, moves) : mode === 'medium' ? MEDIUM_DELAY_MS : FAST_DELAY_MS);
      // on long move sessions, stop for a bit every so often, like someone looking over the board
      if (human && ++sinceBreak >= nextBreak && i < moves.length - 1) {
        setStatus('Pausing… ' + (i + 1) + '/' + moves.length);
        await sleep(bell(1500, 4000) * humanScale);
        sinceBreak = 0; nextBreak = Math.round(rand(8, 16));
      }
    }
    if (!autoSolveNext) { setStatus('Done: ' + moves.length + ' moves played.', 'ok'); return; }

    // wait for the "Další sklad" button to appear, then click it
    setStatus('Waiting for “Další sklad”…');
    const isShown = el => el && getComputedStyle(el).display !== 'none' && el.getClientRects().length > 0;
    let next = null;
    for (let w = 0; w < 100 && !stopFlag; w++) {          // up to ~5 s
      const el = document.getElementById('next');
      if (isShown(el)) { next = el; break; }
      await sleep(50);
    }
    if (stopFlag) { setStatus('Stopped.', 'warn'); return; }
    if (!next) { setStatus('Done: ' + moves.length + ' moves played (Další sklad did not appear).', 'warn'); return; }
    await sleep(mode === 'human' ? bell(600, 1500) * humanScale : mode === 'medium' ? 300 : 0);
    const before = boardSnap();
    if (autoSolveNext) { try { localStorage.setItem('sokoban-resume', String(Date.now())); } catch (e) { /* ignore */ } }
    next.click();
    debug.nextClicked = true;
    if (!autoSolveNext) { setStatus('Done: ' + moves.length + ' moves, moved on to the next level.', 'ok'); return false; }

    // The next level either loads in place (board changes) or the page reloads
    // (then the saved resume flag restarts the solver on the new page).
    setStatus('Loading next level…');
    for (let w = 0; w < 120 && !stopFlag; w++) {          // up to ~6 s
      await sleep(50);
      const cur = boardSnap();
      const nx = document.getElementById('next');
      if (cur && cur !== before && !isShown(nx)) {
        try { localStorage.removeItem('sokoban-resume'); } catch (e) { /* ignore */ }
        await sleep(mode === 'human' ? bell(500, 1200) * humanScale : 150);
        return true;                                      // solve the next one
      }
    }
    setStatus('Clicked Další sklad; waiting for the page…', 'ok');
    return false;
  }

  /* --------------------------------------------------------------- settings (shown in the main overlay) */
  function initSolver() {
    if (window.__umimeSokobanInited) return;
    window.__umimeSokobanInited = true;

    const offerSettings = () => {
      agentCommand('exercise-settings', {
        id: 'sokoban',
        title: 'Sokoban',
        values: { mode, humanScale },
        fields: [
          { key: 'mode', type: 'choice', label: 'Pace', options: Object.keys(MODES).map(k => ({ id: k, label: MODES[k].label, hint: MODES[k].hint })) },
          { key: 'humanScale', type: 'range', label: 'Human pace', min: 0.5, max: 3, step: 0.1, showWhen: { mode: 'human' } }
        ]
      });
    };

    const setStatus = (t) => { agentStatus(t); };

    const applySettings = (values) => {
      if (!values) return;
      if (values.mode && MODES[values.mode]) {
        mode = values.mode;
        try { localStorage.setItem('sokoban-mode', mode); } catch (e) { /* ignore */ }
      }
      if (values.humanScale != null) {
        const h = parseFloat(values.humanScale);
        if (h >= 0.5 && h <= 3) {
          humanScale = h;
          try { localStorage.setItem('sokoban-humanscale', String(humanScale)); } catch (e) { /* ignore */ }
        }
      }
      offerSettings();
    };

    const run = async () => {
      if (busy) { stopFlag = true; setStatus('Stopping…'); return; }
      busy = true; stopFlag = false;
      await autoNextReady;
      agentStart('Sokoban solver starting');
      try {
        let again = true, levels = 0;
        while (again && !stopFlag && levels < 100) { again = await solveAndClick(setStatus); levels++; }
        if (levels > 1) debug.levelsThisRun = levels;
        agentFinish(stopFlag ? 'stop' : 'complete', stopFlag ? 'Stopped' : 'Exercise completed');
      }
      catch (e) {
        debug.error = String((e && e.message) || e);
        setStatus(debug.error);
        agentFinish('error', 'Solver error');
        console.error(e);
      }
      busy = false; stopFlag = false;
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || typeof changes[AUTO_NEXT_STORAGE_KEY]?.newValue !== 'boolean') return;
      autoSolveNext = changes[AUTO_NEXT_STORAGE_KEY].newValue;
    });
    window.addEventListener('message', e => {
      if (e.source !== window || e.data?.channel !== AGENT_EVENT_CHANNEL) return;
      if (e.data.type === 'ready') offerSettings();
      else if (e.data.type === 'settings-request') offerSettings();
      else if (e.data.type === 'settings-set' && e.data.id === 'sokoban') applySettings(e.data.values);
      else if (e.data.type === 'activate' && findSokobanTable()) run();
      else if (e.data.type === 'stop-requested' && busy) { stopFlag = true; setStatus('Stopping…'); }
    });
    document.addEventListener('keydown', e => {
      if (e.altKey && (e.key === 's' || e.key === 'S')) { e.preventDefault(); run(); }
    });
    offerSettings();

    // resume after a full page reload caused by clicking "Další sklad"
    try {
      const t = +localStorage.getItem('sokoban-resume');
      localStorage.removeItem('sokoban-resume');
      if (t && Date.now() - t < 20000) {
        (async () => {
          await autoNextReady;
          if (!autoSolveNext) return;
          for (let w = 0; w < 100 && !findSokobanTable(); w++) await sleep(50);
          await sleep(mode === 'human' ? bell(500, 1200) * humanScale : 200);
          run();
        })();
      }
    } catch (e) { /* ignore */ }
  }

  const bootSokoban = () => {
    if (findSokobanTable()) { initSolver(); return; }
    const root = document.documentElement || document;
    const observer = new MutationObserver(() => {
      if (findSokobanTable()) { observer.disconnect(); initSolver(); }
    });
    observer.observe(root, { childList: true, subtree: true });
    setTimeout(() => observer.disconnect(), 20000);
  };
  if (document.body) bootSokoban(); else document.addEventListener('DOMContentLoaded', bootSokoban, { once: true });
})();