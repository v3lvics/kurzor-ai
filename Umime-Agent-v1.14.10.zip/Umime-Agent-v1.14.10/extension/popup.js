'use strict';
document.getElementById('settings').addEventListener('click', async () => {
  await chrome.runtime.openOptionsPage();
  window.close();
});
chrome.storage.local.get(['geminiApiKey']).then(data => {
  const el = document.getElementById('status');
  const configured = !!data.geminiApiKey;
  el.textContent = configured ? 'Gemini key configured' : 'Gemini key not configured';
  el.classList.toggle('ok', configured);
});
