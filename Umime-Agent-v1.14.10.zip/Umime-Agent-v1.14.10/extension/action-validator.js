(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.UmimeActionValidator = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const types = new Set(['click', 'fill', 'select', 'click_point', 'set_arrow', 'drag']);
  function validate(result) {
    if (!result || typeof result !== 'object' || Array.isArray(result)) throw new Error('AI response must be an object.');
    if (typeof result.needsMoreContext !== 'boolean' || !Array.isArray(result.actions)) throw new Error('AI response is missing required fields.');
    if (result.noSelectionNeeded !== undefined && typeof result.noSelectionNeeded !== 'boolean') throw new Error('Invalid empty-selection flag.');
    if (result.actions.length > 60) throw new Error('AI action plan is too long.');
    if (result.confidence !== undefined && (typeof result.confidence !== 'number' || !Number.isFinite(result.confidence) || result.confidence < 0 || result.confidence > 1)) throw new Error('Invalid AI confidence.');
    if (result.advanceTargetId && !/^n\d+$/.test(result.advanceTargetId)) throw new Error('Invalid navigation target.');
    for (const action of result.actions) {
      if (!action || !types.has(action.type)) throw new Error('Unsupported AI action.');
      if (action.type === 'click_point') {
        if (!/^c\d+$/.test(action.canvasId || '') || ![action.x, action.y].every(n => typeof n === 'number' && Number.isFinite(n) && n >= 0 && n <= 1)) throw new Error('Invalid canvas coordinates.');
      } else if (!/^[tn]\d+$/.test(action.targetId || '')) throw new Error('Invalid target ID.');
      if (['fill', 'select'].includes(action.type) && (typeof action.value !== 'string' || action.value.length > 2000)) throw new Error('Invalid field value.');
      if (action.type === 'drag' && (!/^t\d+$/.test(action.dropTargetId || '') || action.targetId === action.dropTargetId)) throw new Error('Invalid drop target.');
      if (action.type === 'set_arrow' && !['right', 'down', 'left', 'up'].includes(action.direction)) throw new Error('Invalid arrow direction.');
    }
    return result;
  }
  function canFill(candidate) {
    return candidate && !candidate.readOnly && (candidate.tag === 'textarea' || candidate.editable === true ||
      (candidate.tag === 'input' && ['text', 'number', 'search', 'tel', 'url', 'email'].includes(candidate.inputType || 'text')));
  }
  function planIsCurrent(actions, candidates, canvases) {
    const targets = new Map(candidates.map(c => [c.id, c]));
    const seen = new Set();
    return actions.every(a => {
      if (a.type === 'click_point') return canvases.some(c => c.id === a.canvasId);
      const c = targets.get(a.targetId);
      if (!c || seen.has(a.targetId)) return false;
      seen.add(a.targetId);
      if (a.type === 'drag') return c.draggable === true && targets.get(a.dropTargetId)?.dropTarget === true && targets.get(a.dropTargetId)?.occupied === false;
      if (a.type === 'fill') return canFill(c);
      if (a.type === 'select') return c.tag === 'select';
      if (a.type === 'set_arrow') return !!c.sipkovanaCell;
      return a.type === 'click' && !c.state?.incorrect && c.state?.checked !== 'true';
    });
  }
  return { validate, canFill, planIsCurrent };
});
