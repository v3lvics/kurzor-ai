(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.UmimeAnswerTargetResolver = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function normalize(value) {
    return String(value || '')
      .normalize('NFC')
      .replace(/\\(?:cdot|times)/g, '*')
      .replace(/[×·]/g, '*')
      .replace(/[÷]/g, '/')
      .replace(/[−–]/g, '-')
      .replace(/\s*([=+\-*/:])\s*/g, '$1')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function resolveAnswerTarget(answer, candidates) {
    const expected = normalize(answer);
    if (!expected || !Array.isArray(candidates)) return null;

    const matches = candidates.filter(candidate => {
      if (!candidate || candidate.answerOption !== true || !candidate.id) return false;
      const labels = [
        candidate.answerText,
        candidate.text,
        ...(Array.isArray(candidate.answerLabels) ? candidate.answerLabels : []),
        ...(Array.isArray(candidate.expressions) ? candidate.expressions : [])
      ];
      return labels.some(label => normalize(label) === expected);
    });

    return matches.length === 1 ? matches[0].id : null;
  }

  return { normalize, resolveAnswerTarget };
});
