(function () {
'use strict';
/* ---- solver core ---- */
// ==CORE START==
const Core = (function () {
  'use strict';

  /* =====================================================================
   *  1) IMAGE  ->  GRID OF CLUES
   * ===================================================================== */

  const GW = 10, GH = 14;            // digit feature grid
  // Digit templates (filled in by build step): { '0': [GW*GH numbers 0..9, ...], aspect }
  const TEMPLATES = /*TEMPLATES*/ {} /*END_TEMPLATES*/;

  function isYellow(r, g, b) {
    return r >= 235 && g >= 200 && g <= 248 && b >= 110 && b <= 215 && (r - b) >= 40;
  }

  // 0..1 "ink" amount of a pixel. Digits are dark; yellow dots are ignored.
  function ink(r, g, b) {
    if (isYellow(r, g, b)) return 0;
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    const v = (235 - lum) / (235 - 80);
    return v < 0 ? 0 : v > 1 ? 1 : v;
  }

  function components(mask, w, h, minArea) {
    const seen = new Uint8Array(w * h);
    const out = [];
    const stack = [];
    for (let y0 = 0; y0 < h; y0++) {
      for (let x0 = 0; x0 < w; x0++) {
        const i0 = y0 * w + x0;
        if (!mask[i0] || seen[i0]) continue;
        let area = 0, sx = 0, sy = 0, minX = x0, maxX = x0, minY = y0, maxY = y0;
        stack.length = 0; stack.push(i0); seen[i0] = 1;
        while (stack.length) {
          const i = stack.pop();
          const x = i % w, y = (i - x) / w;
          area++; sx += x; sy += y;
          if (x < minX) minX = x; if (x > maxX) maxX = x;
          if (y < minY) minY = y; if (y > maxY) maxY = y;
          for (let dy = -1; dy <= 1; dy++) {
            const ny = y + dy; if (ny < 0 || ny >= h) continue;
            for (let dx = -1; dx <= 1; dx++) {
              const nx = x + dx; if (nx < 0 || nx >= w) continue;
              const ni = ny * w + nx;
              if (mask[ni] && !seen[ni]) { seen[ni] = 1; stack.push(ni); }
            }
          }
        }
        if (area >= minArea) out.push({ area, cx: sx / area, cy: sy / area, minX, maxX, minY, maxY });
      }
    }
    return out;
  }

  function cluster1D(values, gap) {
    const v = values.slice().sort((a, b) => a - b);
    const groups = [];
    let cur = [v[0]];
    for (let i = 1; i < v.length; i++) {
      if (v[i] - v[i - 1] > gap) { groups.push(cur); cur = []; }
      cur.push(v[i]);
    }
    groups.push(cur);
    return groups.map(g => g.reduce((a, b) => a + b, 0) / g.length);
  }

  function median(a) {
    const s = a.slice().sort((x, y) => x - y);
    return s[Math.floor(s.length / 2)];
  }

  function featureVector(cov, w, c) {
    const bw = c.maxX - c.minX + 1, bh = c.maxY - c.minY + 1;
    const vec = new Array(GW * GH);
    for (let j = 0; j < GH; j++) {
      const ya = c.minY + (j * bh) / GH, yb = c.minY + ((j + 1) * bh) / GH;
      for (let i = 0; i < GW; i++) {
        const xa = c.minX + (i * bw) / GW, xb = c.minX + ((i + 1) * bw) / GW;
        let sum = 0, n = 0;
        for (let y = Math.floor(ya); y < Math.max(Math.ceil(yb), Math.floor(ya) + 1); y++) {
          for (let x = Math.floor(xa); x < Math.max(Math.ceil(xb), Math.floor(xa) + 1); x++) {
            sum += cov[y * w + x]; n++;
          }
        }
        vec[j * GW + i] = n ? sum / n : 0;
      }
    }
    return { vec, aspect: bw / bh };
  }

  function classify(f) {
    let best = null, second = null;
    for (const d of Object.keys(TEMPLATES)) {
      for (const t of TEMPLATES[d]) {
        let s = 0;
        for (let k = 0; k < f.vec.length; k++) {
          const diff = f.vec[k] - t.vec[k] / 9;
          s += diff * diff;
        }
        s = s / f.vec.length;
        const da = f.aspect - t.aspect;
        s += 0.25 * da * da;
        if (!best || s < best.s) {
          if (best && best.d !== d) second = best;
          best = { d, s };
        } else if (best.d !== d && (!second || s < second.s)) {
          second = { d, s };
        }
      }
    }
    if (!best) return { digit: null, score: 1, margin: 0 };
    const margin = second ? second.s / Math.max(best.s, 1e-9) : 99;
    return { digit: Number(best.d), score: best.s, margin };
  }

  /**
   * detect(w, h, rgba)
   * returns { ok, rows, cols, clues[][], conf[][], dots:{xs,ys}, boxes:[], message }
   */
  function detect(w, h, data, opts) {
    opts = opts || {};
    // 1) yellow dots
    const ymask = new Uint8Array(w * h);
    for (let i = 0, p = 0; i < w * h; i++, p += 4) {
      if (data[p + 3] > 128 && isYellow(data[p], data[p + 1], data[p + 2])) ymask[i] = 1;
    }
    let dots = components(ymask, w, h, 3);
    if (dots.length < 4) return { ok: false, message: 'Could not find the yellow grid dots in this image.' };
    const medArea = median(dots.map(d => d.area));
    dots = dots.filter(d => d.area >= medArea * 0.35 && d.area <= medArea * 3);
    const side = Math.sqrt(medArea);
    const gap = Math.max(3, side * 1.2);
    const xs = cluster1D(dots.map(d => d.cx), gap);
    const ys = cluster1D(dots.map(d => d.cy), gap);
    const cols = xs.length - 1, rows = ys.length - 1;
    if (cols < 1 || rows < 1) return { ok: false, message: 'Found dots, but they do not form a grid.' };
    let warn = '';
    if (dots.length !== xs.length * ys.length) {
      warn = 'Some grid dots were not detected (' + dots.length + ' of ' + xs.length * ys.length + '); the grid size may be off.';
    }

    // 2) digits (dark ink)
    const cov = new Float32Array(w * h);
    const dmask = new Uint8Array(w * h);
    for (let i = 0, p = 0; i < w * h; i++, p += 4) {
      const v = data[p + 3] > 128 ? ink(data[p], data[p + 1], data[p + 2]) : 0;
      cov[i] = v;
      if (v > 0.4) dmask[i] = 1;
    }
    const spacing = (xs[xs.length - 1] - xs[0]) / cols;
    const comps = components(dmask, w, h, 4).filter(c => {
      const bh = c.maxY - c.minY + 1, bw = c.maxX - c.minX + 1;
      return bh >= spacing * 0.18 && bh <= spacing * 0.95 && bw <= spacing * 0.95 &&
        c.cx > xs[0] && c.cx < xs[xs.length - 1] && c.cy > ys[0] && c.cy < ys[ys.length - 1];
    });

    const clues = Array.from({ length: rows }, () => new Array(cols).fill(null));
    const conf = Array.from({ length: rows }, () => new Array(cols).fill(1));
    const boxes = [];
    for (const c of comps) {
      let col = -1, row = -1;
      for (let i = 0; i < cols; i++) if (c.cx > xs[i] && c.cx < xs[i + 1]) col = i;
      for (let j = 0; j < rows; j++) if (c.cy > ys[j] && c.cy < ys[j + 1]) row = j;
      if (col < 0 || row < 0) continue;
      const f = featureVector(cov, w, c);
      const cl = classify(f);
      const good = cl.digit !== null && cl.score < 0.06 && cl.margin > 1.5;
      clues[row][col] = cl.digit;
      conf[row][col] = good ? 1 : 0;
      boxes.push({ minX: c.minX, maxX: c.maxX, minY: c.minY, maxY: c.maxY, row, col, digit: cl.digit, good, score: cl.score, margin: cl.margin, f });
    }
    return { ok: true, rows, cols, clues, conf, dots: { xs, ys }, boxes, message: warn };
  }

  /* =====================================================================
   *  2) SOLVER (constraint propagation + backtracking)
   * ===================================================================== */

  function solve(clues, opts) {
    opts = opts || {};
    const limit = opts.limit || 2;
    const timeMs = opts.timeMs || 60000;
    const t0 = Date.now();
    const R = clues.length, C = clues[0].length;
    const NH = (R + 1) * C;                 // horizontal edges
    const E = NH + R * (C + 1);
    const H = (r, c) => r * C + c;
    const V = (r, c) => NH + r * (C + 1) + c;
    const D = (r, c) => r * (C + 1) + c;
    const ND = (R + 1) * (C + 1);

    const edgeDots = new Array(E);
    for (let r = 0; r <= R; r++) for (let c = 0; c < C; c++) edgeDots[H(r, c)] = [D(r, c), D(r, c + 1)];
    for (let r = 0; r < R; r++) for (let c = 0; c <= C; c++) edgeDots[V(r, c)] = [D(r, c), D(r + 1, c)];

    const dotEdges = Array.from({ length: ND }, () => []);
    for (let e = 0; e < E; e++) for (const d of edgeDots[e]) dotEdges[d].push(e);

    const cellEdges = new Array(R * C);
    const edgeCells = Array.from({ length: E }, () => []);
    const clueVal = new Int8Array(R * C).fill(-1);
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
      const k = r * C + c;
      cellEdges[k] = [H(r, c), H(r + 1, c), V(r, c), V(r, c + 1)];
      if (clues[r][c] !== null && clues[r][c] !== undefined) {
        clueVal[k] = clues[r][c];
        for (const e of cellEdges[k]) edgeCells[e].push(k);
      }
    }

    let nodes = 0;
    const solutions = [];
    let timedOut = false;

    function setE(st, e, v, q) {
      if (st[e] === v) return true;
      if (st[e] !== -1) return false;
      st[e] = v; q.push(e); return true;
    }

    function checkDot(st, d, q) {
      const es = dotEdges[d];
      let on = 0, unk = 0;
      for (let i = 0; i < es.length; i++) { const s = st[es[i]]; if (s === 1) on++; else if (s === -1) unk++; }
      if (on > 2) return false;
      if (on === 2) {
        if (unk) for (const e of es) if (st[e] === -1) st[e] = 0, q.push(e);
      } else if (on === 1) {
        if (unk === 0) return false;
        if (unk === 1) for (const e of es) if (st[e] === -1) { st[e] = 1; q.push(e); }
      } else if (unk === 1) {
        for (const e of es) if (st[e] === -1) { st[e] = 0; q.push(e); }
      }
      return true;
    }

    function checkCell(st, k, q) {
      const n = clueVal[k];
      const es = cellEdges[k];
      let on = 0, unk = 0;
      for (let i = 0; i < 4; i++) { const s = st[es[i]]; if (s === 1) on++; else if (s === -1) unk++; }
      if (on > n || on + unk < n) return false;
      if (unk) {
        if (on === n) { for (const e of es) if (st[e] === -1) { st[e] = 0; q.push(e); } }
        else if (on + unk === n) { for (const e of es) if (st[e] === -1) { st[e] = 1; q.push(e); } }
      }
      return true;
    }

    function propagate(st, q) {
      while (q.length) {
        const e = q.pop();
        for (const d of edgeDots[e]) if (!checkDot(st, d, q)) return false;
        for (const k of edgeCells[e]) if (!checkCell(st, k, q)) return false;
      }
      return true;
    }

    // Analyse fences: returns {ok:false} if an invalid early loop exists,
    //                 {ok:true, closed:true} if exactly one finished loop and nothing else
    function analyse(st) {
      const adj = new Map();
      let total = 0;
      for (let e = 0; e < E; e++) if (st[e] === 1) {
        total++;
        const [a, b] = edgeDots[e];
        if (!adj.has(a)) adj.set(a, []); if (!adj.has(b)) adj.set(b, []);
        adj.get(a).push(b); adj.get(b).push(a);
      }
      if (total === 0) return { ok: true, closed: false, total };
      const seen = new Set();
      let comps = 0, closedComps = 0;
      for (const s of adj.keys()) {
        if (seen.has(s)) continue;
        comps++;
        let isClosed = true;
        const stack = [s]; seen.add(s);
        while (stack.length) {
          const d = stack.pop();
          if (adj.get(d).length !== 2) isClosed = false;
          for (const n of adj.get(d)) if (!seen.has(n)) { seen.add(n); stack.push(n); }
        }
        if (isClosed) closedComps++;
      }
      if (closedComps > 0 && comps > 1) return { ok: false };
      if (closedComps === 0 && comps > 1) {
        // connectivity prune: all fences must still be joinable through
        // edges that are not forbidden (state !== 0)
        const parent = new Int32Array(ND);
        for (let i = 0; i < ND; i++) parent[i] = i;
        const find = x => { while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; };
        for (let e = 0; e < E; e++) if (st[e] !== 0) {
          const a = find(edgeDots[e][0]), b = find(edgeDots[e][1]);
          if (a !== b) parent[a] = b;
        }
        let root = -1;
        for (let e = 0; e < E; e++) if (st[e] === 1) {
          const r = find(edgeDots[e][0]);
          if (root < 0) root = r; else if (root !== r) return { ok: false };
        }
      }
      return { ok: true, closed: closedComps === 1 && comps === 1, total };
    }

    function search(st) {
      if (solutions.length >= limit || timedOut) return;
      if ((++nodes & 255) === 0 && Date.now() - t0 > timeMs) { timedOut = true; return; }

      const an = analyse(st);
      if (!an.ok) return;
      if (an.closed) {
        // finished loop: everything else must be empty
        const q = [];
        for (let e = 0; e < E; e++) if (st[e] === -1) { st[e] = 0; q.push(e); }
        if (!propagate(st, q)) return;
        for (let k = 0; k < R * C; k++) {
          if (clueVal[k] < 0) continue;
          let on = 0; for (const e of cellEdges[k]) if (st[e] === 1) on++;
          if (on !== clueVal[k]) return;
        }
        solutions.push(Int8Array.from(st));
        return;
      }

      // choose a branching edge
      let pick = -1;
      // (a) extend an open path end
      for (let d = 0; d < ND && pick < 0; d++) {
        let on = 0, cand = -1;
        for (const e of dotEdges[d]) { if (st[e] === 1) on++; else if (st[e] === -1) cand = e; }
        if (on === 1 && cand >= 0) pick = cand;
      }
      // (b) most constrained clue cell
      if (pick < 0) {
        let bestK = -1, bestU = 99;
        for (let k = 0; k < R * C; k++) {
          if (clueVal[k] < 0) continue;
          let u = 0; for (const e of cellEdges[k]) if (st[e] === -1) u++;
          if (u > 0 && u < bestU) { bestU = u; bestK = k; }
        }
        if (bestK >= 0) for (const e of cellEdges[bestK]) if (st[e] === -1) { pick = e; break; }
      }
      // (c) anything
      if (pick < 0) for (let e = 0; e < E; e++) if (st[e] === -1) { pick = e; break; }
      if (pick < 0) return;   // nothing unknown and not a closed loop -> invalid

      for (const v of [1, 0]) {
        const nxt = Int8Array.from(st);
        const q = [];
        if (setE(nxt, pick, v, q) && propagate(nxt, q)) search(nxt);
        if (solutions.length >= limit || timedOut) return;
      }
    }

    // initial propagation over everything
    const st0 = new Int8Array(E).fill(-1);
    const q0 = [];
    let feasible = true;
    for (let d = 0; d < ND && feasible; d++) feasible = checkDot(st0, d, q0);
    for (let k = 0; k < R * C && feasible; k++) if (clueVal[k] >= 0) feasible = checkCell(st0, k, q0);
    if (feasible) feasible = propagate(st0, q0);
    if (feasible) search(st0);

    const fences = solutions.map(s => {
      const h = [], v = [];
      for (let r = 0; r <= R; r++) { h.push([]); for (let c = 0; c < C; c++) h[r].push(s[H(r, c)] === 1); }
      for (let r = 0; r < R; r++) { v.push([]); for (let c = 0; c <= C; c++) v[r].push(s[V(r, c)] === 1); }
      return { h, v };
    });
    let status = 'none';
    if (timedOut && !fences.length) status = 'timeout';
    else if (fences.length === 1 && !timedOut) status = 'unique';
    else if (fences.length >= 1) status = timedOut ? 'timeout-partial' : 'multiple';
    return { status, solutions: fences, nodes, ms: Date.now() - t0, rows: R, cols: C };
  }

  /* =====================================================================
   *  3) ASCII RENDERING  (same style as the terminal screenshot)
   * ===================================================================== */
  function ascii(clues, sol) {
    const R = clues.length, C = clues[0].length;
    const out = [];
    for (let r = 0; r <= R; r++) {
      let line = '+';
      for (let c = 0; c < C; c++) line += (sol.h[r][c] ? '---' : '   ') + '+';
      out.push(line);
      if (r === R) break;
      line = '';
      for (let c = 0; c <= C; c++) {
        line += sol.v[r][c] ? '|' : ' ';
        if (c < C) line += clues[r][c] !== null && clues[r][c] !== undefined ? ' ' + clues[r][c] + ' ' : '   ';
      }
      out.push(line);
    }
    return out.join('\n');
  }

  return { detect, solve, ascii, classify, featureVector, GW, GH, TEMPLATES };
})();

window.__plotyCore = Core;
})();
/* the page glue below reads window.__plotyCore */
/* ======================= page glue (Umíme to "Ploty") v1.1 =================
 * DOM layout:  #plan > table.grid > tr > td[x][y]
 *   odd x, odd y   -> cell
 *   even x, odd y  -> vertical fence    (class "fence")
 *   odd x, even y  -> horizontal fence  (class "fence")
 *   even x, even y -> dot
 *
 * v1.1: three click modes
 *   Instant - old behaviour, fixed 12 ms between clicks
 *   Smart   - quick, traces the loop in runs, short irregular pauses
 *   Slow    - slower, jumps around in short runs, long pauses, a few
 *             misclicks that it undoes again
 * ========================================================================== */
(function () {
  'use strict';
  const VERSION = '1.4-extension';
  const FAST_DELAY_MS = 12;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rand = (a, b) => a + Math.random() * (b - a);
  const bell = (a, b) => a + (b - a) * (Math.random() + Math.random()) / 2;   // bell-shaped, feels less robotic than uniform
  const debug = { version: VERSION };
  /* -------------------------- AI visual overlay bridge -------------------------- */
  const AGENT_CONTROL_CHANNEL = 'umime-ai-control';
  const AGENT_EVENT_CHANNEL = 'umime-ai-overlay';
  let agentOverlayReady = false;
  let agentRequestSeq = 0;
  const agentMoveWaiters = new Map();
  const ALLOW_SUB_AGENTS_STORAGE_KEY = 'allowSubAgents';
  let allowSubAgents = false;
  const subAgentsReady = chrome.storage.local.get(ALLOW_SUB_AGENTS_STORAGE_KEY).then(data => {
    allowSubAgents = data[ALLOW_SUB_AGENTS_STORAGE_KEY] === true;
  }).catch(error => console.error('[Ploty] Could not load sub-agent setting:', error));

  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.channel !== AGENT_EVENT_CHANNEL) return;
    if (e.data.type === 'ready') agentOverlayReady = true;
    if (e.data.type === 'arrived' && agentMoveWaiters.has(e.data.requestId)) {
      const waiter = agentMoveWaiters.get(e.data.requestId);
      if (waiter.cursorId === (Number(e.data.cursorId) || 0)) waiter.resolve();
    }
  });

  // The extension loads at document_start while Tampermonkey starts later.
  // Ask for readiness explicitly instead of relying on an event we may have missed.
  window.postMessage({ channel: AGENT_CONTROL_CHANNEL, type: 'hello' }, '*');

  function agentCommand(type, extra) {
    if (!agentOverlayReady) return;
    window.postMessage(Object.assign({ channel: AGENT_CONTROL_CHANNEL, type }, extra || {}), '*');
  }

  function agentStart(label) { agentCommand('start', { label }); }
  function agentStatus(text) { agentCommand('status', { text }); }
  function agentClick(cursorId = 0) { agentCommand('click', { cursorId }); }
  function agentFinish(type, text) { agentCommand(type || 'complete', { text }); }

  async function agentMoveTo(el, cursorId = 0) {
    if (!agentOverlayReady || !el || !el.getBoundingClientRect) return false;
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) return false;
    const requestId = 'umime-agent-' + (++agentRequestSeq);
    return new Promise(resolve => {
      const timeout = setTimeout(() => {
        agentMoveWaiters.delete(requestId);
        resolve(false);
      }, 2200);
      agentMoveWaiters.set(requestId, {
        cursorId,
        resolve: () => {
        clearTimeout(timeout);
        agentMoveWaiters.delete(requestId);
        resolve(true);
        }
      });
      window.postMessage({
        channel: AGENT_CONTROL_CHANNEL,
        type: 'move',
        requestId,
        cursorId,
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      }, '*');
    });
  }

  let busy = false;
  let stopFlag = false;
  let chosen = -1;                 // index of the click strategy that worked
  const AUTO_NEXT_STORAGE_KEY = 'autoSolveNextExercises';
  const AUTO_RESUME_KEY = 'ploty-autosolve-resume';
  let autoSolveNext = true;
  const autoNextReady = chrome.storage.local.get(AUTO_NEXT_STORAGE_KEY).then(data => {
    if (typeof data[AUTO_NEXT_STORAGE_KEY] === 'boolean') autoSolveNext = data[AUTO_NEXT_STORAGE_KEY];
  }).catch(error => console.error('[Ploty] Could not load global auto-next setting:', error));

  /* ---------------------------------------------------------------- modes */
  const MODES = {
    instant: { label: 'Instant', hint: 'No delays, no hovering.' },
    smart: {
      label: 'Smart', hint: 'Fast and fluent, follows the loop in runs.',
      click: [130, 330],          // ms between clicks inside a run
      run: [5, 14],               // fences per run
      runPause: [450, 1200],      // pause between runs
      idleP: 0.04, idle: [1500, 3000],
      hover: [20, 70],
      shuffleRuns: false, mistakeP: 0, maxMistakes: 0
    },
    slow: {
      label: 'Slow', hint: 'Hesitant, jumps around, a few misclicks.',
      click: [500, 1300],
      run: [2, 6],
      runPause: [1500, 3800],
      idleP: 0.05, idle: [4000, 9000],
      hover: [60, 220],
      shuffleRuns: true, mistakeP: 0.04, maxMistakes: 3
    }
  };
  let mode = 'smart';
  try { const m = localStorage.getItem('ploty-mode'); if (MODES[m]) mode = m; } catch (e) { /* ignore */ }

  /* ---------------------------------------------------------- read page */
  function readPuzzle() {
    const table = document.querySelector('#plan table.grid') || document.querySelector('table.grid');
    if (!table) throw new Error('No puzzle found on this page (looked for #plan table.grid).');
    const cells = new Map();
    let maxX = 0, maxY = 0;
    table.querySelectorAll('td[x][y]').forEach(td => {
      const x = +td.getAttribute('x'), y = +td.getAttribute('y');
      cells.set(x + ',' + y, td);
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    });
    if (maxX < 2 || maxY < 2 || maxX % 2 || maxY % 2)
      throw new Error('Unexpected grid size (' + maxX + ' x ' + maxY + ' in table units).');
    const C = maxX / 2, R = maxY / 2;
    const clues = [];
    for (let r = 0; r < R; r++) {
      clues.push([]);
      for (let c = 0; c < C; c++) {
        const td = cells.get((2 * c + 1) + ',' + (2 * r + 1));
        const t = td ? td.textContent.trim() : '';
        clues[r].push(/^\d$/.test(t) ? Number(t) : null);
      }
    }
    return { table, cells, R, C, clues };
  }

  /* -------------------------------------------------------------- clicks */
  const snap = td => td.className + '|' + (td.getAttribute('style') || '') + '|' + td.innerHTML;

  function puzzleFingerprint(puzzle) {
    const name = document.getElementById('name')?.textContent.trim() || '';
    return `${location.href}|${name}|${puzzle.R}x${puzzle.C}|${JSON.stringify(puzzle.clues)}`;
  }

  function nextControl() {
    const visible = el => el && el.isConnected && !el.disabled
      && el.getAttribute('aria-disabled') !== 'true'
      && getComputedStyle(el).display !== 'none'
      && getComputedStyle(el).visibility !== 'hidden'
      && el.getClientRects().length > 0;
    for (const id of ['next', 'next-question']) {
      const el = document.getElementById(id);
      if (visible(el)) return el;
    }
    const controls = [...document.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"], a[href]')]
      .filter(visible)
      .filter(el => !/vyhodno|zkontrol|evaluate|check|restart|znovu|přeskoč|preskoc|skip/i.test(
        `${el.innerText || el.value || el.getAttribute('aria-label') || ''} ${el.id || ''} ${el.className || ''}`));
    const labeled = controls.find(el => /^(další|dalsi|pokračovat|pokracovat|next|continue)(?:\b|\s|[›»→>])/i.test(
      (el.innerText || el.value || el.getAttribute('aria-label') || '').trim()));
    if (labeled) return labeled;
    const primary = controls.filter(el => el.classList
      && ['tlacitko', 'large', 'primary'].every(name => el.classList.contains(name))
      && el.closest('.control-panel'));
    return primary.length === 1 ? primary[0] : null;
  }

  async function advanceNextPuzzle(setStatus, beforeFingerprint) {
    const end = Date.now() + 5000;
    let button = null;
    while (Date.now() < end && !stopFlag) {
      button = nextControl();
      if (button) break;
      await sleep(100);
    }
    if (stopFlag || !button) {
      if (!button) setStatus('Solved. No next-puzzle button was found.', 'ok');
      return false;
    }
    if (!autoSolveNext) return false;

    setStatus('Opening the next puzzle…');
    try { localStorage.setItem(AUTO_RESUME_KEY, String(Date.now())); } catch (e) { /* ignore */ }
    button.click();
    const changedBy = Date.now() + 7000;
    while (Date.now() < changedBy && !stopFlag) {
      await sleep(100);
      const table = document.querySelector('#plan table.grid') || document.querySelector('table.grid');
      if (!table) continue;
      try {
        const nextPuzzle = readPuzzle();
        if (puzzleFingerprint(nextPuzzle) !== beforeFingerprint) {
          try { localStorage.removeItem(AUTO_RESUME_KEY); } catch (e) { /* ignore */ }
          return true;
        }
      } catch (e) { /* wait for the next board to finish rendering */ }
    }
    try { localStorage.removeItem(AUTO_RESUME_KEY); } catch (e) { /* ignore */ }
    return false;
  }

  function fire(td, type) {
    const r = td.getBoundingClientRect();
    // land at a slightly random spot inside the cell, like a real pointer would
    const jx = (Math.random() - 0.5) * r.width * 0.6, jy = (Math.random() - 0.5) * r.height * 0.6;
    const init = {
      bubbles: true, cancelable: true, view: window, button: 0,
      buttons: type.endsWith('down') ? 1 : 0, detail: type === 'click' ? 1 : 0,
      clientX: r.left + r.width / 2 + jx, clientY: r.top + r.height / 2 + jy
    };
    let ev;
    if (type.startsWith('pointer') && typeof PointerEvent === 'function')
      ev = new PointerEvent(type, Object.assign({ pointerId: 1, pointerType: 'mouse', isPrimary: true }, init));
    else
      ev = new MouseEvent(type.replace('pointer', 'mouse'), init);
    td.dispatchEvent(ev);
  }

  const STRATEGIES = [
    { name: 'mousedown+mouseup', run: td => { fire(td, 'mousedown'); fire(td, 'mouseup'); } },
    { name: 'click',             run: td => { fire(td, 'click'); } },
    { name: 'pointer+mouse+click', run: td => {
        fire(td, 'pointerdown'); fire(td, 'mousedown'); fire(td, 'pointerup'); fire(td, 'mouseup'); fire(td, 'click'); } }
  ];

  async function waitForFenceState(td, baseline, desiredOn, timeoutMs = 400) {
    const end = Date.now() + timeoutMs;
    do {
      if (!td.isConnected) return false;
      if ((td.className !== baseline) === desiredOn) return true;
      await sleep(25);
    } while (Date.now() < end);
    return false;
  }

  async function toggleFence(td, cursorAlreadyThere = false, desiredOn = true, baseline = 'fence', cursorId = 0) {
    if (!cursorAlreadyThere) await agentMoveTo(td, cursorId);
    if (chosen >= 0) {
      const before = snap(td);
      STRATEGIES[chosen].run(td);
      agentClick(cursorId);
      if (await waitForFenceState(td, baseline, desiredOn)) return true;
      if (td.isConnected && snap(td) === before) {
        STRATEGIES[chosen].run(td);
        agentClick(cursorId);
        return waitForFenceState(td, baseline, desiredOn, 500);
      }
      return false;
    }
    debug.firstFenceBefore = td.outerHTML;
    for (let i = 0; i < STRATEGIES.length; i++) {
      const before = snap(td);
      STRATEGIES[i].run(td);
      if (await waitForFenceState(td, baseline, desiredOn, 400)) {
        chosen = i; debug.strategy = STRATEGIES[i].name; debug.firstFenceAfter = td.isConnected ? td.outerHTML : '(cell replaced)';
        agentClick(cursorId);
        return true;
      }
      if (!td.isConnected || snap(td) !== before) return false;
    }
    return false;
  }

  // Move the virtual pointer to the target first, then hover and click.
  async function humanClick(td, M, desiredOn = true, baseline = 'fence') {
    await agentMoveTo(td);
    fire(td, 'mouseover'); fire(td, 'mousemove');
    await sleep(bell(M.hover[0], M.hover[1]));
    return toggleFence(td, true, desiredOn, baseline);
  }

  async function clickFenceAsSubAgent(td, desiredOn, baseline, cursorId, expectedPuzzleFingerprint) {
    if (stopFlag || !agentOverlayReady || !td.isConnected) return false;
    if (!(await agentMoveTo(td, cursorId)) || stopFlag || !td.isConnected) return false;
    let current;
    try { current = readPuzzle(); }
    catch { return false; }
    if (puzzleFingerprint(current) !== expectedPuzzleFingerprint) return false;
    fire(td, 'mouseover');
    fire(td, 'mousemove');
    await sleep(mode === 'smart' ? bell(12, 32) : 0);
    if (stopFlag || !td.isConnected) return false;
    try {
      if (puzzleFingerprint(readPuzzle()) !== expectedPuzzleFingerprint) return false;
    } catch {
      return false;
    }
    return toggleFence(td, true, desiredOn, baseline, cursorId);
  }

  /* ------------------------------------------------ human-like ordering */
  const ends = td => {
    const x = +td.getAttribute('x'), y = +td.getAttribute('y');
    return (y % 2 === 0) ? [[x - 1, y], [x + 1, y]] : [[x, y - 1], [x, y + 1]];
  };
  const dkey = d => d[0] + ',' + d[1];

  // walk the solution loop edge by edge, starting from a random fence
  function loopOrder(tds) {
    const at = new Map();
    for (const td of tds) for (const d of ends(td)) {
      const k = dkey(d);
      if (!at.has(k)) at.set(k, []);
      at.get(k).push(td);
    }
    const shift = Math.floor(Math.random() * tds.length);
    const starts = tds.slice(shift).concat(tds.slice(0, shift));
    const seen = new Set(), order = [];
    for (const start of starts) {
      if (seen.has(start)) continue;
      let cur = start, far = ends(start)[Math.random() < 0.5 ? 0 : 1];
      while (cur) {
        seen.add(cur); order.push(cur);
        const next = (at.get(dkey(far)) || []).find(t => !seen.has(t));
        if (!next) break;
        const [a, b] = ends(next);
        far = dkey(a) === dkey(far) ? b : a;
        cur = next;
      }
    }
    return order;
  }

  function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function buildRuns(todo, M) {
    const set = new Set(todo);
    const order = loopOrder(todo.slice()).filter(t => set.has(t));
    const runs = [];
    for (let i = 0; i < order.length;) {
      const n = Math.max(1, Math.round(rand(M.run[0], M.run[1])));
      runs.push(order.slice(i, i + n));
      i += n;
    }
    if (M.shuffleRuns) {
      shuffle(runs);
      runs.forEach(r => { if (Math.random() < 0.3) r.reverse(); });
    }
    return runs;
  }

  async function placeFencesWithSubAgents(todo, desiredStates, baseline, expectedPuzzleFingerprint, setStatus) {
    const workers = Math.min(3, Math.max(1, todo.length - 1));
    setStatus(`Calibrating a fence before parallel placement (${todo.length} updates)…`);

    let completed = 0;
    const failed = [];
    const first = todo[0];
    const calibrationStartedAt = performance.now();
    agentCommand('sub-agent-status', { cursorId: 1, text: 'Working…' });
    if (!(await agentMoveTo(first, 1))) {
      agentCommand('sub-agent-status', { cursorId: 1, text: 'Stopped' });
      return 0;
    }
    let firstOk = false;
    try {
      if (!stopFlag && first.isConnected && puzzleFingerprint(readPuzzle()) === expectedPuzzleFingerprint) {
        firstOk = await toggleFence(first, true, desiredStates.get(first), baseline, 1);
      }
    } catch (error) {
      console.warn('[Ploty] Could not verify the first sub-agent fence click:', error);
    }
    if (!firstOk) {
      agentCommand('sub-agent-status', { cursorId: 1, text: 'Stopped' });
      return 0;
    }
    completed++;
    const calibrationMs = Math.max(50, performance.now() - calibrationStartedAt);
    const sequentialEstimate = Math.max(1, Math.round(calibrationMs * todo.length / 1000));
    const parallelEstimate = Math.max(1, Math.round(
      (calibrationMs + Math.ceil((todo.length - 1) / workers) * calibrationMs) / 1000
    ));
    debug.estimatedSequentialSeconds = sequentialEstimate;
    debug.estimatedParallelSeconds = parallelEstimate;
    setStatus(`First fence took ${Math.round(calibrationMs)}ms. Estimated: ${sequentialEstimate}s sequential, ${parallelEstimate}s with ${workers} sub-agents.`);

    let nextIndex = 1;
    const worker = async workerIndex => {
      const cursorId = workerIndex + 1;
      agentCommand('sub-agent-status', { cursorId, text: 'Working…' });
      while (!stopFlag) {
        const index = nextIndex++;
        if (index >= todo.length) break;
        const td = todo[index];
        const ok = await clickFenceAsSubAgent(
          td,
          desiredStates.get(td),
          baseline,
          cursorId,
          expectedPuzzleFingerprint
        );
        if (ok) {
          completed++;
          setStatus(`Sub-agents placing fences… ${completed}/${todo.length}`);
        } else if (td.isConnected) {
          failed.push(td);
        }
      }
      agentCommand('sub-agent-status', { cursorId, text: 'Done' });
    };

    if (todo.length > 1) await Promise.all(Array.from({ length: workers }, (_, index) => worker(index)));
    else agentCommand('sub-agent-status', { cursorId: 1, text: 'Done' });
    if (!stopFlag) {
      try {
        if (puzzleFingerprint(readPuzzle()) !== expectedPuzzleFingerprint) {
          stopFlag = true;
          setStatus('Puzzle changed while sub-agents were working; stopped to protect the new puzzle.', 'warn');
          return completed;
        }
      } catch (error) {
        console.warn('[Ploty] Could not verify the puzzle after sub-agent clicks:', error);
        stopFlag = true;
        setStatus('Could not verify the puzzle after sub-agent clicks; stopped safely.', 'warn');
        return completed;
      }
    }
    if (failed.length) {
      setStatus(`${failed.length} fence click${failed.length === 1 ? '' : 's'} need a verification pass…`, 'warn');
      for (const td of failed) {
        if (stopFlag) break;
        const ok = mode === 'smart'
          ? await humanClick(td, MODES.smart, desiredStates.get(td), baseline)
          : await toggleFence(td, false, desiredStates.get(td), baseline);
        if (ok) completed++;
      }
    }
    return completed;
  }

  /* ---------------------------------------------------------- main action */
  async function solveAndClick(setStatus) {
    const p = readPuzzle();
    const startingFingerprint = puzzleFingerprint(p);
    const nameEl = document.getElementById('name');
    const name = nameEl ? nameEl.textContent.trim() : '';
    debug.puzzle = name; debug.size = p.R + 'x' + p.C; debug.mode = mode;
    debug.unconfirmedFences = [];

    const fenceTds = [...p.cells.values()].filter(td => td.classList.contains('fence'));
    if (!fenceTds.length) throw new Error('No fence cells (td.fence) found; the page layout is different than expected.');
    const counts = new Map();
    fenceTds.forEach(td => counts.set(td.className, (counts.get(td.className) || 0) + 1));
    const baseline = [...counts.entries()].sort((a, b) => b[1] - a[1])[0][0];
    debug.baselineClass = baseline;

    setStatus('Solving…');
    await sleep(0);
    const res = window.__plotyCore.solve(p.clues, { limit: 2, timeMs: 15000 });
    debug.solver = res.status + ', ' + res.ms + ' ms';
    if (!res.solutions.length) {
      throw new Error(res.status === 'timeout'
        ? 'The solver ran out of time on this puzzle.'
        : 'No solution exists for the numbers read from the page (a number was probably read wrongly).');
    }
    const sol = res.solutions[0];

    const wanted = [];
    for (let r = 0; r <= p.R; r++) for (let c = 0; c < p.C; c++)
      wanted.push([p.cells.get((2 * c + 1) + ',' + (2 * r)), sol.h[r][c], 'h' + r + ',' + c]);
    for (let r = 0; r < p.R; r++) for (let c = 0; c <= p.C; c++)
      wanted.push([p.cells.get((2 * c) + ',' + (2 * r + 1)), sol.v[r][c], 'v' + r + ',' + c]);
    for (const [td, , key] of wanted)
      if (!td || !td.classList.contains('fence')) throw new Error('Expected a fence cell for ' + key + ' but did not find one.');

    const desiredStates = new Map(wanted.map(([td, want]) => [td, want]));
    const todo = wanted.filter(([td, want]) => (td.className !== baseline) !== want).map(w => w[0]);
    const total = wanted.filter(w => w[1]).length;
    if (!todo.length) {
      setStatus('Already matches the solution (' + total + ' fences).', 'ok');
      return autoSolveNext ? advanceNextPuzzle(setStatus, startingFingerprint) : false;
    }

    const M = MODES[mode];
    const human = mode !== 'instant';
    const canUseSubAgents = allowSubAgents
      && (mode === 'smart' || mode === 'instant')
      && agentOverlayReady
      && todo.length >= 4;
    debug.subAgents = canUseSubAgents ? Math.min(3, todo.length - 1) : 0;
    const runs = human ? buildRuns(todo, M) : [todo];
    // fences that are off and should stay off: candidates for a "misclick"
    const wrongPool = wanted.filter(([td, want]) => !want && td.className === baseline).map(w => w[0]);
    let mistakes = 0;

    let done = 0;
    if (canUseSubAgents) {
      done = await placeFencesWithSubAgents(todo, desiredStates, baseline, startingFingerprint, setStatus);
      if (stopFlag) {
        setStatus(`Stopped (${done}/${todo.length}).`, 'warn');
        return;
      }
    } else for (let s = 0; s < runs.length; s++) {
      if (human && s > 0) await sleep(bell(M.runPause[0], M.runPause[1]));
      for (const td of runs[s]) {
        if (stopFlag) { setStatus('Stopped (' + done + '/' + todo.length + ').', 'warn'); return; }
        if (!document.body.contains(p.table)) break;             // page already moved on

        // occasional misclick on a nearby fence, noticed and undone
        if (human && chosen >= 0 && mistakes < M.maxMistakes && Math.random() < M.mistakeP) {
          const tx = +td.getAttribute('x'), ty = +td.getAttribute('y');
          const near = wrongPool.filter(t => t.className === baseline &&
            Math.abs(+t.getAttribute('x') - tx) + Math.abs(+t.getAttribute('y') - ty) <= 3);
          if (near.length) {
            const bad = near[Math.floor(Math.random() * near.length)];
            mistakes++;
            await humanClick(bad, M, true, baseline);
            await sleep(bell(500, 1300));                        // "oops"
            await humanClick(bad, M, false, baseline);
            await sleep(bell(300, 800));
          }
        }

        const desiredOn = desiredStates.get(td);
        const ok = human
          ? await humanClick(td, M, desiredOn, baseline)
          : await toggleFence(td, false, desiredOn, baseline);
        if (!ok) {
          if (!debug.unconfirmedFences) debug.unconfirmedFences = [];
          debug.unconfirmedFences.push(td.getAttribute('x') + ',' + td.getAttribute('y'));
          setStatus('A fence click did not register; checking it again at the end…', 'warn');
        } else {
          done++;
          setStatus('Placing fences… ' + done + '/' + todo.length);
        }

        if (!human) { await sleep(FAST_DELAY_MS); continue; }
        let d = bell(M.click[0], M.click[1]);
        if (Math.random() < M.idleP) d += bell(M.idle[0], M.idle[1]);   // zoned out / looked at the keyboard
        await sleep(d);
      }
    }

    await sleep(250);
    const movedOn = !document.body.contains(p.table) || (nameEl && nameEl.isConnected && nameEl.textContent.trim() !== name);
    if (movedOn) { setStatus('Done: the page moved on, which usually means it accepted the solution.', 'ok'); return false; }
    let mismatches = wanted.filter(([td, want]) => (td.className !== baseline) !== want);
    if (mismatches.length && !stopFlag) {
      setStatus(`Checking ${mismatches.length} fence${mismatches.length === 1 ? '' : 's'} that did not register…`);
      for (const [td, desiredOn] of mismatches) {
        if (stopFlag) break;
        const corrected = mode === 'instant'
          ? await toggleFence(td, false, desiredOn, baseline)
          : await humanClick(td, M, desiredOn, baseline);
        if (corrected) await sleep(FAST_DELAY_MS);
      }
      await sleep(250);
      mismatches = wanted.filter(([td, want]) => (td.className !== baseline) !== want);
    }
    const bad = mismatches.length;
    debug.mismatchesAfter = bad;
    if (bad === 0) {
      setStatus('Done: ' + total + ' fences placed (' + res.status + ' solution).', 'ok');
      return autoSolveNext ? advanceNextPuzzle(setStatus, startingFingerprint) : false;
    }
    setStatus('Placed fences, but ' + bad + ' cells do not match the solution.', 'warn');
    return false;
  }

  /* --------------------------------------------------------------- settings (shown in the main overlay) */
  function initSolver() {
    if (window.__umimePlotyInited) return;
    window.__umimePlotyInited = true;

    const offerSettings = () => {
      agentCommand('exercise-settings', {
        id: 'ploty',
        title: 'Ploty',
        values: { mode },
        fields: [
          { key: 'mode', type: 'choice', label: 'Pace', options: Object.keys(MODES).map(k => ({ id: k, label: MODES[k].label, hint: MODES[k].hint })) }
        ]
      });
    };

    const setStatus = (t) => { agentStatus(t); };

    const applySettings = (values) => {
      if (values?.mode && MODES[values.mode]) {
        mode = values.mode;
        try { localStorage.setItem('ploty-mode', mode); } catch (e) { /* ignore */ }
      }
      offerSettings();
    };

    const run = async () => {
      if (busy) { stopFlag = true; setStatus('Stopping…'); return; }
      busy = true; stopFlag = false;
      await autoNextReady;
      await subAgentsReady;
      agentStart('Ploty solver starting');
      try {
        let solveAnother = true, levels = 0;
        while (solveAnother && autoSolveNext && !stopFlag && levels < 100) {
          solveAnother = await solveAndClick(setStatus);
          levels++;
        }
        if (levels === 0) await solveAndClick(setStatus);
        agentFinish(stopFlag ? 'stop' : 'complete', stopFlag ? 'Stopped' : 'Exercise completed');
      }
      catch (e) {
        debug.error = String(e && e.message || e);
        setStatus(debug.error);
        agentFinish('error', 'Solver error');
      }
      busy = false; stopFlag = false;
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (typeof changes[AUTO_NEXT_STORAGE_KEY]?.newValue === 'boolean') {
        autoSolveNext = changes[AUTO_NEXT_STORAGE_KEY].newValue;
      }
      if (typeof changes[ALLOW_SUB_AGENTS_STORAGE_KEY]?.newValue === 'boolean') {
        allowSubAgents = changes[ALLOW_SUB_AGENTS_STORAGE_KEY].newValue;
      }
    });
    window.addEventListener('message', e => {
      if (e.source !== window || e.data?.channel !== AGENT_EVENT_CHANNEL) return;
      if (e.data.type === 'ready') offerSettings();
      else if (e.data.type === 'settings-request') offerSettings();
      else if (e.data.type === 'settings-set' && e.data.id === 'ploty') applySettings(e.data.values);
      else if (e.data.type === 'activate' && (document.querySelector('#plan table.grid') || document.querySelector('table.grid'))) run();
      else if (e.data.type === 'stop-requested' && busy) { stopFlag = true; setStatus('Stopping…'); }
    });
    document.addEventListener('keydown', e => { if (e.altKey && (e.key === 's' || e.key === 'S')) { e.preventDefault(); run(); } });
    offerSettings();

    try {
      const resumedAt = Number(localStorage.getItem(AUTO_RESUME_KEY));
      localStorage.removeItem(AUTO_RESUME_KEY);
      if (resumedAt && Date.now() - resumedAt < 20000) {
        setTimeout(async () => {
          await autoNextReady;
          if (!autoSolveNext) return;
          if (document.querySelector('#plan table.grid, table.grid')) run();
        }, 250);
      }
    } catch (e) { /* ignore */ }
  }

  const bootPloty = () => {
    const selector = '#plan table.grid, table.grid';
    if (document.querySelector(selector)) { initSolver(); return; }
    const root = document.documentElement || document;
    const observer = new MutationObserver(() => {
      if (document.querySelector(selector)) { observer.disconnect(); initSolver(); }
    });
    observer.observe(root, { childList: true, subtree: true });
    setTimeout(() => observer.disconnect(), 20000);
  };
  if (document.body) bootPloty(); else document.addEventListener('DOMContentLoaded', bootPloty, { once: true });
})();