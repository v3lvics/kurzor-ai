(() => {
 let sequence=0;
 window.UmimeOfflineBridge={start:async()=>{
  const prefs=await chrome.storage.local.get(['localSolverPace','autoSolveNextExercises']);
  const requestId='offline-'+Date.now()+'-'+(++sequence);
  return new Promise(resolve=>{
   const finish=value=>{clearTimeout(timer);window.removeEventListener('message',listener);resolve(value);};
   const listener=e=>{if(e.source===window&&e.data?.channel==='umime-offline-response'&&e.data.requestId===requestId)finish(e.data.accepted===true);};
   const timer=setTimeout(()=>finish(false),800);window.addEventListener('message',listener);
   window.postMessage({channel:'umime-offline-request',type:'start',requestId,pace:prefs.localSolverPace||'smart',autoNext:prefs.autoSolveNextExercises!==false},'*');
  });
 }};
})();
