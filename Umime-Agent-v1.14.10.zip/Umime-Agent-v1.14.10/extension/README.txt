# Umíme Agent 1.14.10

Reliability and coverage update for the supplied Chrome extension. It keeps the animated cursor, Alt+click activation, Esc stop, Gemini settings, and existing local puzzle solvers.






## 1.14.10: delayed Next controls

The offline runner now prefers an explicitly visible Next control in the exercise instead of blindly relying on the adapter's shortcut. If no button is initially visible, it invokes the original Next handler once and watches for a delayed button. The cursor moves to the control and waits 500ms before clicking. A node is clicked at most once for the same item/revision; hidden, disabled and modal-contained controls are excluded. Auto-next off still prevents advancement. Finalboards and automatically changed items remain guarded.

89 automated tests pass, including visible-button and delayed-button runner scenarios. All JavaScript syntax checks pass. No live reproduction of the user's exact exercise was available.

## 1.14.2: item events, pacing and settings

Compared the integration with the supplied original neumimeto runner. The original subscribes to the page-data hook's item event and cancels stale work when a question changes. The integration now tracks that event separately from the item ID, checks it between plan steps and after completion waits, and waits at least 500ms after an item event before planning. This covers reused IDs as well as normal navigation.

Every runner-level plan step now has at least a 500ms pause, including Instant; Smart uses the same floor and Human-like slow uses longer bounded pauses. These are runner-level pauses: individual adapters can contain multiple internal clicks within one step. Speed changes apply at the next activation. Restored the overlay's segmented button styling for local pace instead of the native select. Enlarged the primary cursor from 48px to 56px and reduced its click shrink from 70% to 90%.

87 tests pass, including a same-ID item-event case that must cancel stale plan steps. All JavaScript syntax checks pass. The reported failing exercise URL is still missing, so these changes have not been verified on that exact live page.

## 1.14.1: next-question readiness and cursor

The headless runner previously treated a changed item ID or game.ready() as sufficient to plan immediately. Page answers can load later, making the next plan temporarily null. It now polls for an unanswered item with an executable plan for up to 12 seconds. Solved stale cards are ignored during that wait. Auto-advance during an answer is recognized without sending an extra Next action.

Local synthetic clicks now report their target position to the existing overlay cursor; local loading/work statuses restore cursor visibility while active. These reports follow the adapter's click event and do not intercept or delay the click itself. They are visual feedback rather than an exact replay of every drag/key action.

86 tests pass, including a three-question run with delayed plan data and an automatic-next case that must not skip a question. All JavaScript syntax checks pass. The user's exact exercise URL was not provided, so live reproduction of that particular page remains unverified.

## 1.14.0: broader local engine and pacing

The earlier releases used only a unique DOM correctness marker and limited local puzzle rules. That is why a task solved by neumimeto could still fall through to Gemini.

This release adapts the local game registry, solver libraries, game modules and early page-data hook from the user-supplied neumimeto archive. Its original dock, queue and shortcut system are not loaded. A new headless runner connects the game plans to the current overlay. Page data stays in the current page; local execution does not call Gemini or require a key. Gemini remains optional when the local adapter cannot read a task. Neutral activity status is “Working…”. See `extension/offline/PROVENANCE.md`.

Choose **Local solving speed** in the overlay's **Automation** settings:

- Instant executes plan steps without extra pacing delay. Adapters may retain their own page-settling waits.
- Smart adds a short delay between steps.
- Human-like slow uses the adapter's human step plan with bounded pauses.

Existing dedicated Informatics grid/puzzle runners retain their original activation paths and speed controls. The new pace setting applies to the imported headless engine. Auto-next is read at activation; changes take effect on the next run. Refresh the exercise tab after reloading the extension so the early data hook can observe page initialization. Disable any separately installed neumimeto copy to prevent simultaneous solvers.

Validation: 84 automated tests pass and every JavaScript file passes syntax checking. Runner tests cover all three modes, no-provider operation, declining unreadable tasks and stopping between steps. Borrowed adapter internals can finish their current asynchronous action after Esc; immediate cancellation inside every adapter has not been implemented. Live installed-extension validation on every exercise family has not been performed. No universal compatibility or performance percentage is claimed.

## 1.13.1: neutral activity status

Local lookup and local ratio solving now show “Working…” using the standard activity indicator. Local action reasons use the same neutral text. No artificial thinking delay or dummy API request is added. The extension combines local solving with optional Gemini fallback. Local solving requires no API key. If no local rule applies, Gemini starts when configured; otherwise the existing Gemini offer asks the user to add a key in Settings. Unsupported input adapters still report their limits rather than sending unusable AI requests. Detailed error and paused/manual-continuation notices are preserved.

79 regression tests and JavaScript syntax checks pass; no new live Chrome/Gemini validation.

## 1.13.0: transparent local answer lookup

Inspected the supplied neumimeto reference. Its gap adapter uses explicit DOM correctness markers, while its broader adapters capture page/network state. This release integrates only the bounded DOM-marker approach; it does not import that extension, its keys, its UI or its full network/page hooks.

Before requesting Gemini, the generic solver checks the current snapshot's answer options for exactly one live element with `correct="1"`. Rejected, selected, missing and ambiguous options fall through to existing solvers/Gemini. The overlay explicitly says “Answer found locally. Applying it…” and retains the cursor animation. Local answers require no API call or key; actual Gemini fallback still uses the configured key. No dummy prompts, fake AI thinking or claimed speed percentage were added. This especially helps the mapped letter-gap widgets; other formats may expose no usable marker.

79 automated tests and syntax checks pass. No installed-extension/live Gemini validation or measured 40% comparison was performed. The reference's broader answer interception is not integrated in this release.

## 1.12.2: unrecognized answer confirmation

At the 12-second result deadline, the extension now shows a direct paused notice rather than reporting that the page has not confirmed the answer. It keeps watching for a changed question, Check or Next for up to 60 seconds, allowing manual continuation without answering again. If still blocked, it explains that it cannot detect the next step and gives retry instructions. Added recognition of Czech check labels without an evaluate ID. This is a fallback for undetected progression, not proof that the user's reported layout has been fixed; its exact URL is still needed to reproduce it. 75 tests pass. No new live Chrome/Gemini validation.

## 1.12.1: waiting notices

Missing answer controls stop after 15 seconds with an exercise/dialog/layout explanation. An unchanged screen without successful actions stops after 45 seconds. An explicit AI needs-more-context response immediately explains that it cannot answer confidently. Two unusable plans stop without another 15-second idle period. Existing 12-second result confirmation deadline remains. Errors stay visible until Esc or reactivation; Alt+click retries. Unsupported-format notices remain specific to the format. These deadlines apply to the generic AI solver; dedicated local puzzle solvers retain their own timing.

74 automated tests pass, plus JavaScript syntax checks. No new live Chrome/Gemini validation was performed.

## 1.12.0: drag adapter and visual detail

Added an experimental adapter for the mapped Umíme jQuery card sorting layout: `.word.ui-draggable[currentbox]` to empty `.wordBox.ui-droppable[currentword]` slots. AI returns one `drag` with source and destination IDs. The executor sends held-mouse movement and checks placement attributes or DOM containment before proceeding. Failed drops stop before grading; cancellation releases the mouse. Cards are placed sequentially and grading is deferred until none remain in the pool. Both endpoints must be visible in the viewport. Arbitrary HTML5 drag/drop, offscreen dragging and other game engines remain unsupported.

Visual input now uses up to eight attachments, a 1400px maximum side, higher JPEG quality and white compositing for transparent pictures. The prompt includes image dimensions, screen positions and answer-target mapping, and asks for uncertainty when details cannot be read. Cross-origin pictures can still be unavailable. This improves the supplied visual context; it does not guarantee recognition accuracy.

71 tests pass, including drag receipt/rejection/cancellation fixtures. Geometry, mouse handlers and placement state in those tests are simulated. No live Umíme drop or real Gemini vision request was validated in this release. Test a short sorting exercise before relying on this adapter.

## 1.11.0 — wider format audit and regression fixes

This is an incremental compatibility update, not universal exercise support.

New read-only live inspection covered Czech gap-fill text, matching cards, word correction and drag-based categorization. Combined with the previous three mathematics layouts, seven format samples are documented. No answers were submitted to the signed-in site during this audit.

The new DOM tests reproduced six failures in 1.10.0 and now pass:

- Matching and text marking had nested duplicate targets. Each card/word now has one target.
- Custom letter menus are classified as gap-fill, expose only visible variants, and track active blank progression.
- Non-button `span.tlacitko.next` controls are now recognized.
- A vocabulary answer such as “next” is retained as an answer, not discarded as navigation.
- Drag-based categorization is detected explicitly and stops with an unsupported-format message instead of attempting ordinary clicks.

Matching prompts request one pair at a time and disable parallel helper clicks for pairs. The snapshot tracks remaining cards and completed gaps. Text-marking exercises can submit an explicitly high-confidence empty selection when the model reports that no words require marking. Audio-only routes stop with a clear transcription limitation. Hidden correctness attributes from gap widgets are not included in the AI prompt.

**Validation: 67 tests pass**, including 11 tests running real snapshot/extraction code against parsed DOM fixtures, lifecycle tests and the earlier two-question loop simulation. All JavaScript syntax checks pass. DOM geometry and events are simulated: this does not establish real click acceptance or AI answer accuracy on every site.

See **COVERAGE.md** for the supported/partial/missing-format table. No live Gemini request or installed-extension end-to-end run was performed. The API key remains yours to configure in the extension.

## 1.10.0 — continuous solving and less waiting

This update keeps the existing interface and cursor. It focuses on the generic solver's question lifecycle.

- One active run per tab: repeated activation no longer cancels/restarts the current run.
- Question fingerprints exclude progress counters, feedback, selected state, input values, hidden help and duplicated KaTeX markup.
- Explicit pending-answer flow: enter → grade once → wait for feedback → next. The solver does not ask AI to answer the same pending question again or choose navigation buttons.
- Completion panels end the run instead of starting another practice set. A changed question takes priority over a stale next button.
- Progress counts once after a next-step/completion signal, rather than immediately after a click or typed field. It counts completed answer steps, not a guarantee of correctness or the site's shield score.
- Added current `[data-data="question"]` and `[data-data="option"]` layouts, alongside older `#question`, `#cards` and `optionN` layouts.
- Maths expressions are represented once using their source notation, rather than sending both rendered MathML and HTML copies.
- Image encoding only runs when a new AI request is needed. Provider discovery is reused within the run. Automatic Google Search retry is limited to the existing uncertain Czech-case check.
- Cursor travel reduced from 420–1250 ms to 180–650 ms; ordinary settling from 380 ms to 120 ms; post-answer settling from 500 ms to 180 ms. These are configured delays, not measured end-to-end speed guarantees. Gemini/network latency remains variable.
- Per-question status says “Thinking…” instead of repeatedly saying “Starting up…”. Unconfirmed answers pause/stop without guessing or submitting partial multi-field answers.

Validation: **54 automated tests pass**, including an integration simulation of the actual generic solver across two written questions, duplicate activation, one grade per answer, one AI request per answer and continuous progress. All JavaScript files pass syntax checks.

Live inspection: opened three mathematics formats in the browser (step-by-step, written answer and multiple choice) and inspected their question, answer, grading, next and completion markup. No answers were submitted during inspection. This is not a full installed-extension/Gemini end-to-end test and is not a complete map of every Umíme activity. See `SITE-MAP.md` for the observed patterns and limits.

## Install / update

1. Extract this ZIP to a permanent folder.
2. Open `chrome://extensions` and enable **Developer mode**.
3. For a new installation, choose **Load unpacked** and select the `extension` folder (the folder containing `manifest.json`). Disable any older duplicate installation.
4. To keep an existing unpacked installation and its saved settings, copy the new `extension` contents into its existing folder, then press **Reload** on its extension card.
5. Refresh every open Umíme exercise tab.
6. Open the extension's settings, configure your Gemini key/model, and use **Test connection**. Hold **Alt** and click an exercise to start. **Esc** stops it.

The uploaded ZIP was named “ollama”, but its source only contained a Gemini provider. This version still uses Gemini. It does not require or connect to Ollama. No API keys are included.

## Earlier 1.9.0 improvements

- Added the actual German destination `umimenemecky.cz`, plus `umimeto.cz`, while retaining existing aliases. All subject links on the official Umíme landing page are covered by the injection rules. Biology, geography, chemistry, history, physics and civics use Umíme fakta.
- Shared host configuration keeps background authorization and content-script coverage aligned, with manifest regression tests.
- Exact answer matching preserves Czech accents, letter case, signs, inequalities, parentheses and units. `-5` no longer matches `5`; `byt` no longer matches `být`.
- Field labels include associated HTML labels and `aria-labelledby`. Placeholder extraction is consistent between planning and execution. Mutable input values do not become target labels.
- Written answers reject incompatible controls, read-only fields and passwords. Negative/decimal numeric inputs are filled atomically; selects preserve accents, exclude disabled options and reject ambiguous labels.
- Multi-answer questions can request all supported selections in sequential mode; helper cursors are optional.
- Loaded, readable exercise images accompany canvas context (four attachments total). Unreadable cross-origin images are reported in the prompt. No page screenshots are captured.
- The question is rechecked after AI replies, including visible image source changes. Invalid IDs, unknown action types, malformed values, stale/duplicate targets and out-of-range canvas points are rejected.
- Esc cancels active generic-solver network work for that tab and stops further cursor-click/typing operations. Other tabs' requests are unaffected.
- Provider failures stop after four consecutive errors. An unchanged unanswerable question stops after its bounded attempts, instead of spending quota indefinitely. Reactivate after correcting settings or changing the question.
- Network attempts time out after 25 seconds. Streaming text excludes model thought parts; malformed structured output cannot reach action execution.
- Added 14 regression tests in 1.9.0 (41 at that release), including mocked worker and DOM interaction checks.

## Coverage and limits

| Format | Implementation | Validation in this update |
| --- | --- | --- |
| Visible multiple choice / multi-select | Generic Gemini planning, exact target mapping | Automated action/matching tests; live site verification still needed |
| Written answer / native select | Typed fields, atomic number entry, unambiguous selects | Mocked DOM interaction tests |
| Reading comprehension / text marking | Existing generic planner, improved detection | Classification and shared validation tests; accuracy depends on context/model |
| Canvas / image questions | Canvas plus up to three additional loaded images, or four images without a canvas | Provider payload tests; cross-origin restrictions apply |
| Ratio calculations | Existing local rules, Gemini fallback | Existing unit fixtures pass |
| Šipkovaná | Existing deterministic parser/search | Existing puzzle fixtures pass; special mechanics need live checks |
| Ploty / Sokoban | Existing dedicated solvers preserved | Syntax checks only in this update; no new live validation |
| Drag-and-drop, audio-only dictation, arbitrary programming and custom games | No general drag, audio transcription or code execution adapter | Not guaranteed; may require a dedicated adapter |

Domain coverage is not a guarantee of every exercise format or every answer. Synthetic events may be rejected by some games. The extension has not been tested against a real Gemini key in an installed Chrome session in this update; live browser inspection was read-only. The original default Gemini model was retained; model availability depends on your account.

## Quick live acceptance checks

- Open one Czech, mathematics, English, German and facts exercise; confirm Alt+click starts the overlay.
- Check an accented choice pair, a negative numeric input, a native select and an image question.
- Press Esc while the cursor moves, during typing and during an AI request; confirm no subsequent action occurs.
- Change the question while AI is thinking; confirm the previous answer is not applied.
- Test auto-next both off and on. Test Ploty, Sokoban and Šipkovaná separately.
- For a failure, retain its exact URL, exercise type and visible error; those identify the next adapter to improve.

## Developer validation

Requires Node.js and npm. `linkedom` is a development-only dependency for DOM tests; the extension itself still has no runtime package dependencies.

```sh
npm ci
npm test
```

The DOM interaction suite uses small mocks, not a real browser. Do not interpret passing tests as end-to-end site certification.

Reference pages inspected for this update:
- https://www.umimeto.org/ (official subject destinations)
- https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle (service-worker fetch lifecycle)
