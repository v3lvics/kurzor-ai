(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.UmimeSites = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // Official subject destinations plus legacy aliases already supported by this build.
  const domains = Object.freeze(['umimeto.org', 'umimeto.cz', 'umimecesky.cz',
    'umimematiku.cz', 'umimematematiku.cz', 'umimeanglicky.cz',
    'umimenemecky.cz', 'umimenemcinu.cz', 'umimeinformatiku.cz', 'umimefakta.cz']);
  function matches(hostname, domain) {
    const host = String(hostname || '').toLowerCase().replace(/\.$/, '');
    return host === domain || host.endsWith('.' + domain);
  }
  return { domains, matches, allowed: hostname => domains.some(domain => matches(hostname, domain)) };
});
