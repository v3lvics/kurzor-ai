/*
 * Local rules for common, unambiguous steps in ratio-splitting exercises.
 * No network access; unsupported or ambiguous questions are left to the AI solver.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.UmimeMathRatioSolver = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function normalize(text) {
    return String(text || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
  }

  function evaluateExpression(source) {
    let text = String(source || '')
      .replace(/\\frac\s*\{([^{}]+)\}\s*\{([^{}]+)\}/g, '($1/$2)')
      .replace(/\\(?:cdot|times)/g, '*')
      .replace(/[×·]/g, '*')
      .replace(/[÷]/g, '/')
      .replace(/[−–]/g, '-')
      .replace(/[{}]/g, '')
      .replace(/\s+/g, '');
    const tokens = text.match(/\d+(?:[.,]\d+)?|[()+\-*/=]/g);
    if (!tokens || tokens.join('') !== text) return null;
    let index = 0;
    const parsePrimary = () => {
      if (tokens[index] === '+' || tokens[index] === '-') {
        const sign = tokens[index++] === '-' ? -1 : 1;
        const value = parsePrimary();
        return value === null ? null : sign * value;
      }
      if (tokens[index] === '(') {
        index++;
        const value = parseSum();
        if (tokens[index++] !== ')') return null;
        return value;
      }
      const token = tokens[index++];
      if (!token || !/^\d/.test(token)) return null;
      const value = Number(token.replace(',', '.'));
      return Number.isFinite(value) ? value : null;
    };
    const parseProduct = () => {
      let value = parsePrimary();
      while (value !== null && (tokens[index] === '*' || tokens[index] === '/')) {
        const operator = tokens[index++];
        const right = parsePrimary();
        if (right === null || (operator === '/' && right === 0)) return null;
        value = operator === '*' ? value * right : value / right;
      }
      return value;
    };
    const parseSum = () => {
      let value = parseProduct();
      while (value !== null && (tokens[index] === '+' || tokens[index] === '-')) {
        const operator = tokens[index++];
        const right = parseProduct();
        if (right === null) return null;
        value = operator === '+' ? value + right : value - right;
      }
      return value;
    };
    const left = parseSum();
    if (left === null) return null;
    if (tokens[index++] !== '=') return index === tokens.length ? left : null;
    const right = parseSum();
    return right !== null && index === tokens.length ? { left, right, correct: Math.abs(left - right) < 1e-9 } : null;
  }

  function solveRatioDivisionFirstStep(questionText, options) {
    const question = normalize(questionText);
    if (!/rozdel(?:te|ime|it)?\s+cislo\b/.test(question)
      || !/v\s+pom(e|ě)ru/.test(question)) return null;

    const ratio = question.match(/v\s+pom[eě]ru\s+(\d+(?:[.,]\d+)?)\s*[:/]\s*(\d+(?:[.,]\d+)?)/);
    if (!ratio) return null;
    const first = Number(ratio[1].replace(',', '.'));
    const second = Number(ratio[2].replace(',', '.'));
    const total = first + second;
    if (!Number.isFinite(total) || total <= 0) return null;

    const normalizedOptions = (Array.isArray(options) ? options : []).filter(option =>
      option && /^option\d+$/i.test(String(option.domId || '')));
    const promptAsksForParts = /prvni\s+krok/.test(question) || /rozdelime\s+na\b/.test(question);
    const promptAsksForUnit = /jeden\s+dil|hodnotu\s+jednoho\s+dilu|velikost\s+jednoho\s+dilu|jednotkov(?:a|ou)?\s+hodnot(?:a|u)/.test(question);
    const promptAsksForFirst = /prvni\s+(?:cast|dil)|cast\s+odpovidajici\s+prvnimu/.test(question);
    const promptAsksForSecond = /druha?\s+(?:cast|dil)|druhou?\s+(?:cast|dil)|druhy\s+(?:cast|dil)|cast\s+odpovidajici\s+druhemu/.test(question);
    const amountMatch = question.match(/rozdel(?:te|ime|it)?\s+cislo\s+(\d+(?:[.,]\d+)?)/);
    const amount = amountMatch ? Number(amountMatch[1].replace(',', '.')) : NaN;
    let stage = '';
    let expected = 0;
    let expectedOperands = [];
    if (promptAsksForParts) {
      stage = 'parts';
      expected = total;
      expectedOperands = [first, second];
    } else if (promptAsksForUnit) {
      stage = 'unit';
      expected = amount / total;
      expectedOperands = [amount, total];
    } else if (promptAsksForFirst || promptAsksForSecond) {
      stage = promptAsksForFirst ? 'first' : 'second';
      const unit = amount / total;
      expected = (promptAsksForFirst ? first : second) * unit;
      expectedOperands = [promptAsksForFirst ? first : second, unit];
    }
    if (!stage || !Number.isFinite(expected)) return null;

    const matches = normalizedOptions.filter(option => {
      const text = normalize(option.text);
      const expressions = [
        ...(Array.isArray(option.expressions) ? option.expressions : []),
        ...(text.match(/(?:\d+(?:[.,]\d+)?\s*[-+*/×·÷]\s*)+\d+(?:[.,]\d+)?(?:\s*=\s*(?:\d+(?:[.,]\d+)?\s*[-+*/×·÷]\s*)*\d+(?:[.,]\d+)?)?/g) || [])
      ];
      return expressions.some(expression => {
        const result = evaluateExpression(expression);
        if (!result || typeof result !== 'object' || !result.correct) return false;
        const normalizedExpression = String(expression)
          .replace(/\\frac\s*\{([^{}]+)\}\s*\{([^{}]+)\}/g, '($1/$2)')
          .replace(/\\(?:cdot|times)/g, '*')
          .replace(/[×·]/g, '*')
          .replace(/[÷]/g, '/');
        const numbers = (normalizedExpression.match(/\d+(?:[.,]\d+)?/g) || []).map(value => Number(value.replace(',', '.')));
        const hasOperands = expectedOperands.every(operand => numbers.some(number => Math.abs(number - operand) < 1e-9));
        if (stage === 'parts') return hasOperands && /[+]/.test(normalizedExpression) && Math.abs(result.left - expected) < 1e-9;
        if (stage === 'unit') return hasOperands && /[/]/.test(normalizedExpression) && Math.abs(result.left - expected) < 1e-9;
        return hasOperands && /[*]/.test(normalizedExpression) && Math.abs(result.left - expected) < 1e-9;
      });
    });

    if (matches.length !== 1) return null;
    return {
      targetId: matches[0].id,
      summary: stage === 'parts'
        ? `Add the ratio parts: ${first} + ${second} = ${total}.`
        : stage === 'unit'
          ? `One part is the total divided by ${total}.`
          : `The ${stage} share is its ratio part multiplied by one part.`
    };
  }

  return { solveRatioDivisionFirstStep, evaluateExpression };
});
