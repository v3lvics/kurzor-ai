(() => {
 'use strict';
 let generation=0,running=false,itemRevision=0,lastItemAt=0;
 const store=window.__neumimetoData;
 if(store)(store.listeners=store.listeners||[]).push(event=>{if(event==='item'){itemRevision++;lastItemAt=Date.now();}});
 const post=(type,extra={})=>window.postMessage({channel:'umime-ai-control',type,...extra},'*');
 document.addEventListener?.('click',event=>{
  if(!running||event.isTrusted)return;
  const el=event.target?.closest?.('#playground *,#questionParent *,#plan *');
  if(!el)return;post('click');const r=el.getBoundingClientRect();
  if(r.width>0&&r.height>0)post('move',{x:r.left+r.width/2,y:r.top+r.height/2,requestId:'offline-cursor-'+Date.now()});
 },true);
 const nextControl=()=>window.UmimeOfflineNavigation?.find(document)||null;
 const clickedNext=new WeakMap();
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 window.addEventListener('message',async event=>{
  if(event.source!==window)return;
  const m=event.data;
  if(m?.channel==='umime-ai-overlay'&&(m.type==='stop-requested'||m.type==='gemini-solve')){generation++;running=false;return;}
  if(m?.channel!=='umime-offline-request'||m.type!=='start')return;
  const engine=window.UmimeOfflineEngine;
  let ready=false;try{ready=!!engine?.game.ready();}catch{}
  const accepted=running||!!engine?.game;
  window.postMessage({channel:'umime-offline-response',requestId:m.requestId,accepted},'*');
  if(!accepted||running)return;
  running=true;const token=++generation;let solved=0;
  const alive=()=>generation===token;
  const visible=el=>el&&el.getBoundingClientRect().width>0&&getComputedStyle(el).display!=='none';
  const wait=async ms=>{const end=Date.now()+ms;while(alive()&&Date.now()<end)await sleep(Math.min(50,end-Date.now()));return alive();};
  post('start',{label:'Working…'});
  try{
   while(alive()){
    const g=engine.game;
    if(visible(document.getElementById('finalboard'))){post('complete',{text:'Practice set completed.'});return;}
    // updateItemUrl can fire before the cards, shuffled answers or input handlers are ready.
    // Wait for an executable plan for an unanswered item, not merely game.ready().
    let plan=null;
    const readyBy=Date.now()+12000;
    while(alive()&&Date.now()<readyBy){
     if(visible(document.getElementById('finalboard'))){post('complete',{text:'Practice set completed.'});return;}
     try{if(Date.now()-lastItemAt>=500&&g.ready()&&!g.finished())plan=g.plan();}catch{plan=null;}
     if(plan?.steps?.length)break;
     post('status',{text:'Loading the next question…',localActive:true});
     await wait(100);
    }
    if(!alive())return;
    if(!plan?.steps?.length)throw Error('Failed to solve');
    const answerId=engine.currentId();
    const answerRevision=itemRevision;
    const mode=['instant','smart','human'].includes(m.pace)?m.pace:'smart';
    const steps=mode==='human'&&plan.human?.length?plan.human:plan.steps;
    for(const step of steps){
     if(!alive())return;
     if(!await wait(mode==='human'?Math.min(2500,Math.max(500,(Number(step.wait)||0.7)*900)):mode==='smart'?1100:500))return;
     if(engine.currentId()!==answerId||itemRevision!==answerRevision)break;
     if(step.target){const target=step.target();if(!target)throw Error('Failed to solve');const r=target.getBoundingClientRect();post('move',{x:r.left+r.width/2,y:r.top+r.height/2,fast:mode==='instant',requestId:'offline-answer-'+Date.now()});if(!await wait(mode==='instant'?550:1600))return;if(engine.currentId()!==answerId||itemRevision!==answerRevision)break;if(step.target()!==target)throw Error('Failed to solve');}
     if(step.run){post('status',{text:'Working…',localActive:true});await step.run({animate:mode==='human',fast:mode==='instant'});}
    }
    if(!alive())return;
    const end=Date.now()+5000;while(alive()&&engine.currentId()===answerId&&itemRevision===answerRevision&&!g.finished()&&!nextControl()&&Date.now()<end)await wait(100);
    if(!alive())return;
    if(engine.currentId()===answerId&&itemRevision===answerRevision&&!g.finished()&&!nextControl())throw Error('The page did not finish this local solution. Stopped before retrying. You can continue manually or try Gemini.');
    post('progress',{solved:++solved});
    if(m.autoNext===false){post('complete',{text:'Answered.'});return;}
    // Some adapters auto-advance while the action resolves. Do not press Next again.
    if(engine.currentId()!==answerId||itemRevision!==answerRevision)continue;
    const before=engine.currentId();
    if(!await wait(mode==='human'?1100:mode==='smart'?250:0))return;
    if(visible(document.getElementById('finalboard'))){post('complete',{text:'Practice set completed.'});return;}
    const nextKey=String(before)+':'+answerRevision;
    const clickNext=async button=>{
     if(clickedNext.get(button)===nextKey)return false;
     post('status',{text:'Continuing…',localActive:true});
     const r=button.getBoundingClientRect();
     post('move',{x:r.left+r.width/2,y:r.top+r.height/2,fast:mode==='instant',requestId:'offline-next-'+Date.now()});
     if(!await wait(mode==='instant'?550:1600)||engine.currentId()!==before||itemRevision!==answerRevision)return false;
     if(nextControl()!==button)return false;
     clickedNext.set(button,nextKey);post('click');button.click();return true;
    };
    const initial=nextControl();
    if(initial)await clickNext(initial);else await g.next();
    if(!alive())return;
    // A Next control can appear after the adapter's shortcut was ignored during feedback.
    const nextBy=Date.now()+10000;
    while(alive()&&engine.currentId()===before&&itemRevision===answerRevision&&Date.now()<nextBy){
     if(visible(document.getElementById('finalboard'))){post('complete',{text:'Practice set completed.'});return;}
     const button=nextControl();
     if(button&&clickedNext.get(button)!==nextKey)await clickNext(button);
     // A ready adapter alone is not proof that a new question loaded.
     await wait(100);
    }
    if(!alive())return;
    if(engine.currentId()===before&&itemRevision===answerRevision)throw Error('Failed to solve');

   }
  }catch(error){if(alive())post('offer-gemini',{text:'Failed to solve'});}
  finally{if(alive())running=false;}
 });
})();
