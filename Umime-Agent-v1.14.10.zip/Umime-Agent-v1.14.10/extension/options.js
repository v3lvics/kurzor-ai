('use strict');

const apiKeyEl = document.getElementById('apiKey');
const modelEl = document.getElementById('model');
const statusEl = document.getElementById('status');
const saveBtn = document.getElementById('save');
const testBtn = document.getElementById('test');
const testSearchBtn = document.getElementById('testSearch');
const clearBtn = document.getElementById('clear');
const DEFAULT_MODEL = 'gemini-3.1-flash-lite';

function setStatus(message, kind = '') {
  statusEl.textContent = String(message || '');
  statusEl.className = kind;
}

function currentValues() {
  const apiKey = apiKeyEl.value.trim();
  const model = modelEl.value.trim() || DEFAULT_MODEL;
  if (!apiKey) throw new Error('Paste a Gemini API key first.');
  if (!/^[a-zA-Z0-9._-]+$/.test(model)) throw new Error('Model ID contains unsupported characters.');
  return { apiKey, model };
}

async function saveValues(values = currentValues()) {
  await chrome.storage.local.set({ geminiApiKey: values.apiKey, geminiModel: values.model });
}

async function load() {
  const data = await chrome.storage.local.get(['geminiApiKey', 'geminiModel']);
  await chrome.storage.local.remove(['aiProviders']);
  apiKeyEl.value = data.geminiApiKey || '';
  modelEl.value = data.geminiModel || DEFAULT_MODEL;
  setStatus(data.geminiApiKey ? 'Settings loaded from this Chrome profile.' : 'Add a key from Google AI Studio to connect Gemini.');
}

saveBtn.addEventListener('click', async () => {
  try {
    const values = currentValues();
    await saveValues(values);
    setStatus('Settings saved locally in this Chrome profile.', 'good');
  } catch (error) {
    setStatus(error?.message || String(error), 'bad');
  }
});

testBtn.addEventListener('click', async () => {
  let values;
  try { values = currentValues(); }
  catch (error) { setStatus(error.message, 'bad'); return; }

  testBtn.disabled = true;
  testBtn.textContent = 'Testing…';
  setStatus('Sending a small, low-reasoning test prompt to Gemini…');
  const slowNotice = setTimeout(() => {
    if (testBtn.disabled) setStatus('Still waiting for Google’s first response. The key has not been rejected; this can happen while a model is warming up…');
  }, 12000);
  try {
    await saveValues(values);
    const result = await chrome.runtime.sendMessage({
      type: 'UMIME_GEMINI_TEST',
      apiKey: values.apiKey,
      model: values.model
    });
    if (!result) throw new Error('The extension background service did not reply. Open chrome://extensions, check for an extension error, then reload the extension.');
    if (!result.ok) throw new Error(result.error || 'Gemini rejected the test request.');
    setStatus(result.message || 'Gemini connection successful.', 'good');
  } catch (error) {
    setStatus(error?.message || String(error), 'bad');
  } finally {
    clearTimeout(slowNotice);
    testBtn.disabled = false;
    testBtn.textContent = 'Test connection';
  }
});

testSearchBtn.addEventListener('click', async () => {
  let values;
  try { values = currentValues(); }
  catch (error) { setStatus(error.message, 'bad'); return; }

  testSearchBtn.disabled = true;
  testSearchBtn.textContent = 'Searching…';
  setStatus('Checking whether Gemini can invoke Google Search grounding. This test sends a fixed documentation query, not exercise text.');
  try {
    await saveValues(values);
    const result = await chrome.runtime.sendMessage({
      type: 'UMIME_GEMINI_SEARCH_TEST',
      apiKey: values.apiKey,
      model: values.model
    });
    if (!result) throw new Error('The extension background service did not reply. Open chrome://extensions, check for an extension error, then reload the extension.');
    if (!result.ok) throw new Error(result.error || 'Google Search grounding test failed.');
    setStatus(result.message || 'Google Search grounding works.', 'good');
  } catch (error) {
    setStatus(error?.message || String(error), 'bad');
  } finally {
    testSearchBtn.disabled = false;
    testSearchBtn.textContent = 'Test Google Search';
  }
});

clearBtn.addEventListener('click', async () => {
  try {
    await chrome.storage.local.remove(['geminiApiKey', 'aiProviders']);
    apiKeyEl.value = '';
    setStatus('Gemini API key removed from this Chrome profile.', 'good');
  } catch (error) {
    setStatus(`Could not remove key: ${error?.message || error}`, 'bad');
  }
});

document.getElementById('toggleKey').addEventListener('click', () => {
  const showing = apiKeyEl.type === 'text';
  apiKeyEl.type = showing ? 'password' : 'text';
  document.getElementById('toggleKey').textContent = showing ? 'Show' : 'Hide';
});

load().catch(error => setStatus(`Could not load settings: ${error?.message || error}`, 'bad'));
