(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.UmimeDragDrop=factory();})(typeof self!=='undefined'?self:this,function(){
 'use strict';
 function supported(doc){return !!doc.querySelector('.word.ui-draggable[currentbox]') && !!doc.querySelector('.wordBox.ui-droppable[currentword]');}
 function placed(source,target){return target.contains(source) || (source.getAttribute('currentbox')===target.id && target.getAttribute('currentword')===source.getAttribute('word')) || (target.getAttribute('currentword')===source.getAttribute('word') && source.getAttribute('currentbox')!=='-1');}
 async function perform({source,target,doc,alive,move,sleep,emit}){
  if(!source||!target||!alive()||!source.isConnected||!target.isConnected)return false;
  if(placed(source,target))return true;
  if(!source.matches('.word.ui-draggable[currentbox]')||!target.matches('.wordBox.ui-droppable[currentword]')||target.getAttribute('currentword')!=='-1')return false;
  const a=source.getBoundingClientRect(),b=target.getBoundingClientRect();
  const start={x:a.left+a.width/2,y:a.top+a.height/2},end={x:b.left+b.width/2,y:b.top+b.height/2};
  const view=doc.defaultView;
  if(![a,b].every(r=>r.width>0&&r.height>0&&r.top>=0&&r.left>=0&&r.bottom<=view.innerHeight&&r.right<=view.innerWidth))return false;
  if(!await move(start.x,start.y)||!alive())return false;
  let held=false,last=start;
  const fire=(el,type,p,buttons)=>{
   const event=new view.MouseEvent(type,{bubbles:true,cancelable:true,view,clientX:p.x,clientY:p.y,button:0,buttons});
   Object.defineProperty(event,'which',{value:type==='mouseup'?1:buttons?1:0});el.dispatchEvent(event);
  };
  try{
   if(!source.contains(doc.elementFromPoint(start.x,start.y))||!target.contains(doc.elementFromPoint(end.x,end.y)))return false;
   held=true;emit('press');fire(source,'mousedown',start,1);
   if(!await move(end.x,end.y)||!alive())return false;
   for(let i=1;i<=16;i++){
    if(!alive()||!source.isConnected||!target.isConnected)return false;
    last={x:start.x+(end.x-start.x)*i/16,y:start.y+(end.y-start.y)*i/16};
    fire(doc.elementFromPoint(last.x,last.y)||doc,'mousemove',last,1);
    await sleep(18);
   }
   if(!alive())return false;
   const hit=doc.elementFromPoint(end.x,end.y);
   if(!target.contains(hit))return false;
   fire(hit,'mouseup',end,0);held=false;emit('release');
   for(let i=0;i<12;i++){if(!alive())return false;if(placed(source,target))return true;await sleep(50);}
   return false;
  }finally{if(held){fire(doc,'mouseup',last,0);emit('release');}}
 }
 return {supported,placed,perform};
});
