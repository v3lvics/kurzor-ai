(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.UmimeOfflineNavigation=factory();})(typeof self!=='undefined'?self:this,function(){
 const selector='#exercise #next,#exercise #next-question,#exercise .control-panel .next,#playground .tlacitko.next,#questionParent .tlacitko.next';
 function find(doc){return [...(doc.querySelectorAll?.(selector)||[])].find(el=>{
  if(!el.isConnected||el.disabled||el.getAttribute('aria-disabled')==='true'||el.closest('modal-dialog,[hidden],[inert]'))return false;
  const r=el.getBoundingClientRect(),s=doc.defaultView.getComputedStyle(el);
  return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0;
 })||null;}
 return {find};
});
