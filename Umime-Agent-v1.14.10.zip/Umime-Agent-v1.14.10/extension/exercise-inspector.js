(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.UmimeExerciseInspector = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const SCRIPT_TASKS = [
    [/\/exercise\/sipkovana\.js(?:[?#]|$)/i, 'sipkovana', 'Šipkovaná'],
    [/\/exercise\/strilecka\.js(?:[?#]|$)/i, 'target_puzzle', 'Target puzzle'],
    [/\/exercise\/roboti\.js(?:[?#]|$)/i, 'robot_puzzle', 'Robot puzzle'],
    [/\/exercise\/mrizkovana\.js(?:[?#]|$)/i, 'grid_puzzle', 'Grid puzzle'],
    [/\/exercise\/ploty\.js(?:[?#]|$)/i, 'logic_grid', 'Logic-grid puzzle'],
    [/\/exercise\/rushhour\.js(?:[?#]|$)/i, 'sliding_puzzle', 'Sliding puzzle'],
    [/\/exercise\/kalkulacka\.js(?:[?#]|$)/i, 'calculator_puzzle', 'Calculator puzzle'],
    [/\/exercise\/grafar\.js(?:[?#]|$)/i, 'graphing', 'Graphing exercise'],
    [/\/exercise\/klikacka\.js(?:[?#]|$)/i, 'text_marking', 'Text marking'],
    [/\/exercise\/diktat\.js(?:[?#]|$)/i, 'dictation', 'Dictation'],
    [/\/exercise\/chat\.js(?:[?#]|$)/i, 'step_by_step', 'Step-by-step exercise'],
    [/\/exercise\/novaVpisovacka\.js(?:[?#]|$)/i, 'written_answer', 'Written answer'],
    [/\/exercise\/porozumeni\.js(?:[?#]|$)/i, 'reading_comprehension', 'Reading comprehension'],
    [/\/exercise\/pexeso\.js(?:[?#]|$)/i, 'matching', 'Matching exercise'],
    [/\/exercise\/presouvani\.js(?:[?#]|$)/i, 'drag_and_drop', 'Arrange items'],
    [/\/exercise\/rozdelovacka\.js(?:[?#]|$)/i, 'sorting', 'Sorting exercise'],
    [/\/exercise\/novaDoplnovacka\.js(?:[?#]|$)/i, 'multiple_choice', 'Multiple choice']
  ];

  const PATH_TASKS = [
    [/sipkovana/i, 'sipkovana', 'Šipkovaná'],
    [/oznacovani-korektury/i, 'text_marking', 'Text marking'],
    [/doplnovacka-shoda-podmetu-s-prisudkem/i, 'subject_verb_choice', 'Subject-verb agreement'],
    [/doplnovacka-(?:nominativ|genitiv|dativ|akuzativ|vokativ|lokal|instrumental)(?:-|\/)/i, 'czech_case_choice', 'Czech case and inflection'],
    [/diktat-shoda-podmetu-s-prisudkem/i, 'dictation', 'Dictation'],
    [/^\/(?:doplnovacka|rozhodovacka)(?:-|\/)/i, 'multiple_choice', 'Multiple choice'],
    [/^\/(?:vpisovacka|psana-odpoved)(?:-|\/)/i, 'written_answer', 'Written answer'],
    [/^\/porozumeni(?:-|\/)/i, 'reading_comprehension', 'Reading comprehension'],
    [/^\/pexeso(?:-|\/)/i, 'matching', 'Matching exercise'],
    [/^\/presouvani(?:-|\/)/i, 'drag_and_drop', 'Arrange items'],
    [/^\/rozdelovacka(?:-|\/)/i, 'sorting', 'Sorting exercise'],
    [/^\/diktat(?:-|\/)/i, 'dictation', 'Dictation']
  ];

  function classifyExercise({ pathname = '', scriptUrls = [], structure = {} } = {}) {
    if (structure.gapDropdowns) return { type:'gap_fill', label:'Text with letter choices', source:'structure' };
    if (structure.dragItems) return { type:'drag_and_drop', label:'Drag-and-drop exercise', source:'structure' };
    if (/\/(?:mluven[^/]*dikt|poslech)/i.test(pathname)) return {type:'audio',label:'Audio exercise',source:'path'};
    const pathTask = PATH_TASKS.find(([pattern]) => pattern.test(pathname));
    if (pathTask) return { type: pathTask[1], label: pathTask[2], source: 'path' };

    for (const [pattern, type, label] of SCRIPT_TASKS) {
      const script = scriptUrls.find(scriptUrl => pattern.test(String(scriptUrl)));
      if (script) return { type, label, source: 'script', script: String(script) };
    }

    if (structure.memoryCards) return { type: 'matching', label: 'Matching exercise', source: 'structure' };
    if (structure.stepCards) return { type: 'step_by_step', label: 'Step-by-step exercise', source: 'structure' };
    if (structure.choiceOptions) return { type: 'multiple_choice', label: 'Multiple choice', source: 'structure' };
    if (structure.answerInputs) return { type: 'written_answer', label: 'Written answer', source: 'structure' };
    if (structure.grid) return { type: 'grid_puzzle', label: 'Grid puzzle', source: 'structure' };
    return { type: 'generic', label: 'Umíme exercise', source: 'fallback' };
  }

  return { classifyExercise };
});
