(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.UmimeLocalAnswerSolver=factory();})(typeof self!=='undefined'?self:this,function(){
 'use strict';
 // Read only explicit markers on live snapshot options. Never guess from order or hidden/offscreen targets.
 function solve(candidates,lookup){
  const options=candidates.filter(c=>c.answerOption && !c.state?.incorrect && c.state?.checked!=='true');
  const marked=options.filter(c=>{const el=lookup(c.id);return el&&el.isConnected&&el.getAttribute('correct')==='1';});
  if(marked.length!==1)return null;
  const chosen=marked[0];
  return {summary:'Working…',source:'page-data',needsMoreContext:false,confidence:1,
   actions:[{type:'click',targetId:chosen.id,reason:'Working…'}]};
 }
 return {solve};
});
