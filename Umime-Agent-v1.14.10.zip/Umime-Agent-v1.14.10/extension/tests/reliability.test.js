'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { domains, allowed } = require('../site-config');
const { validate, planIsCurrent } = require('../action-validator');
const { resolveAnswerTarget } = require('../answer-target-resolver');
const base = path.join(__dirname, '..');
const option = text => [{ id: 't1', answerOption: true, answerText: text }];
const solution = actions => ({ summary: 'Answer', needsMoreContext: false, actions });

test('signed numbers, inequalities, units, Czech accents and capitalization stay distinct', () => {
  for (const [a,b] of [['-5','5'],['5%','5'],['<5','>5'],['byt','být'],['rada','řada'],['Praha','praha']]) {
    assert.equal(resolveAnswerTarget(a, option(b)), null, `${a} != ${b}`);
  }
  assert.equal(resolveAnswerTarget('−5',option('-5')),'t1');
  assert.equal(resolveAnswerTarget('kůň',option('ku\u030an\u030c')),'t1');
});

test('manifest and worker cover the same sites including real German host', () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(base,'manifest.json')));
  for (const domain of domains) {
    assert.ok(allowed(domain)); assert.ok(allowed(`www.${domain}`));
    assert.ok(!allowed(`${domain}.evil.example`)); assert.ok(!allowed(`fake${domain}`));
    for (const entry of manifest.content_scripts.filter(e=>e.js.includes('content.js') || e.js.includes('ai-agent.js'))) {
      assert.ok(entry.matches.includes(`https://*.${domain}/*`));
    }
  }
  assert.ok(allowed('www.umimenemecky.cz'));
  assert.ok(!allowed('example.org'));
  for(const entry of manifest.content_scripts) for(const file of entry.js) assert.ok(fs.existsSync(path.join(base,file)));
});

test('malformed plans are rejected before any mutation', () => {
  for (const result of [null, [], {}, solution([{type:'eval',value:'code'}]), solution([{type:'click',targetId:'t1"]'}]), solution([{type:'click_point',canvasId:'c1',x:2,y:0.5}]), solution([{type:'click_point',canvasId:'c1',x:'0.5',y:0.5}]), solution([{type:'fill',targetId:'t1',value:5}]), {...solution([]),confidence:-1}]) assert.throws(()=>validate(result));
  assert.deepEqual(validate(solution([{type:'click_point',canvasId:'c1',x:0.4,y:0.5}] )).actions.length,1);
});

test('plans cannot fill buttons/passwords or run partial stale actions', () => {
  const fields=[{id:'t1',tag:'button'},{id:'t2',tag:'input',inputType:'password'},{id:'t3',tag:'input',inputType:'number'},{id:'t4',tag:'select'}];
  for(const id of ['t1','t2','missing']) assert.equal(planIsCurrent([{type:'fill',targetId:id,value:'-4'}],fields,[]),false);
  assert.equal(planIsCurrent([{type:'fill',targetId:'t3',value:'-4'}],fields,[]),true);
  assert.equal(planIsCurrent([{type:'click',targetId:'t1'},{type:'click',targetId:'missing'}],fields,[]),false);
  assert.equal(planIsCurrent([{type:'click',targetId:'t1'},{type:'click',targetId:'t1'}],fields,[]),false);
  assert.equal(planIsCurrent([{type:'select',targetId:'t4',value:'x'}],fields,[]),true);
});

function worker(fetchImpl) {
  let listener;
  const context=vm.createContext({console, setTimeout, clearTimeout, AbortController, TextDecoder, Uint8Array, URL,
    fetch:fetchImpl,
    chrome:{storage:{local:{get:async()=>({geminiApiKey:'fixture-key',geminiModel:'fixture-model'}),remove:async()=>{}}},
      runtime:{onMessage:{addListener(fn){listener=fn;}}},tabs:{sendMessage(_id,_msg,cb){cb();}}}});
  context.importScripts=(...files)=>files.forEach(file=>vm.runInContext(fs.readFileSync(path.join(base,file),'utf8'),context));
  vm.runInContext(fs.readFileSync(path.join(base,'background.js'),'utf8'),context);
  return { context, message:(msg,tab=1,host='https://www.umimenemecky.cz/exercise')=>new Promise(resolve=>listener(msg,{url:host,tab:{id:tab},frameId:0},resolve)) };
}

test('worker rejects non-Umime senders and invalid context without network requests',async()=>{
  let calls=0; const w=worker(async()=>{calls++;throw Error('unexpected fetch');});
  assert.equal((await w.message({type:'UMIME_GEMINI_SOLVE',prompt:'question'},1,'https://example.org')).ok,false);
  assert.equal((await w.message({type:'UMIME_GEMINI_SOLVE',prompt:''})).ok,false);
  assert.equal(calls,0);
});

test('SSE parser handles split UTF-8, CRLF, thought parts and final line without newline',async()=>{
  const w=worker(()=>{});
  const text='data: '+JSON.stringify({candidates:[{content:{parts:[{text:'private',thought:true},{text:JSON.stringify(solution([{type:'fill',targetId:'t1',value:'žluťoučký'}]))}]}}]})+'\r\ndata: [DONE]';
  const bytes=new TextEncoder().encode(text);
  const stream=new ReadableStream({start(controller){for(let i=0;i<bytes.length;i+=3)controller.enqueue(bytes.slice(i,i+3));controller.close();}});
  const result=await w.context.readGeminiStream({body:stream},()=>{});
  const parsed=w.context.parseGeminiText(result);
  assert.equal(parsed.actions[0].value,'žluťoučký');
});

test('worker passes expanded visual attachments and rejects malformed model JSON',async()=>{
  let body;
  const w=worker(async(_url,init)=>{body=JSON.parse(init.body);return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'null'}]}}]}),{status:200});});
  const result=await w.message({type:'UMIME_GEMINI_SOLVE',googleSearch:true,prompt:'question',images:Array.from({length:5},()=>({mimeType:'image/jpeg',data:'AA=='}))});
  assert.equal(result.ok,false);
  assert.equal(body.contents[0].parts.length,6);
  assert.match(result.error,/object/);
});

test('Stop aborts only the requesting tab and permits a subsequent request',async()=>{
  const pending=[];
  const w=worker((_url,init)=>new Promise((_resolve,reject)=>{pending.push(init.signal);init.signal.addEventListener('abort',()=>reject(Object.assign(new Error('aborted'),{name:'AbortError'})));}));
  const a=w.message({type:'UMIME_GEMINI_SOLVE',prompt:'one'},1);
  const b=w.message({type:'UMIME_GEMINI_SOLVE',prompt:'two'},2);
  await new Promise(resolve=>setImmediate(resolve));
  await w.message({type:'UMIME_AI_CANCEL'},1);
  assert.equal(pending[0].aborted,true);assert.equal(pending[1].aborted,false);
  assert.equal((await a).ok,false);
  await w.message({type:'UMIME_AI_CANCEL'},2);await b;
  const c=w.message({type:'UMIME_GEMINI_SOLVE',prompt:'three'},1);
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(pending[2].aborted,false);
  await w.message({type:'UMIME_AI_CANCEL'},1);await c;
});
