'use strict';

const assert = require('node:assert/strict');
const test = require('node:test');
const { resolveAnswerTarget } = require('../answer-target-resolver.js');

const candidates = [
  { id: 't1', answerOption: true, answerText: '7 · 7 = 49', expressions: ['7\\cdot 7=49'] },
  { id: 't2', answerOption: true, answerText: '2 · 7 = 14', expressions: ['2\\cdot 7=14'] },
  { id: 't3', answerOption: false, answerText: '49' }
];

test('maps an exact answer to its option when math formatting differs', () => {
  assert.equal(resolveAnswerTarget('7*7=49', candidates), 't1');
});

test('maps exact Czech labels while preserving diacritics', () => {
  assert.equal(resolveAnswerTarget('Příliš žluťoučký kůň', [
    { id: 't1', answerOption: true, answerText: 'Příliš žluťoučký kůň' }
  ]), 't1');
});

test('does not map partial answers or non-answer controls', () => {
  assert.equal(resolveAnswerTarget('49', candidates), null);
  assert.equal(resolveAnswerTarget('7 * 7', candidates), null);
  assert.equal(resolveAnswerTarget('NewYork', [
    { id: 't1', answerOption: true, answerText: 'New York' }
  ]), null);
});

test('does not choose when multiple answer choices match', () => {
  assert.equal(resolveAnswerTarget('A', [
    { id: 't1', answerOption: true, answerText: 'A' },
    { id: 't2', answerOption: true, answerText: 'A' }
  ]), null);
});
