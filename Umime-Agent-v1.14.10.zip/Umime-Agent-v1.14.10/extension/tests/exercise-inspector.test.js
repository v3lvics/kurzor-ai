'use strict';

const assert = require('node:assert/strict');
const test = require('node:test');
const { classifyExercise } = require('../exercise-inspector.js');

test('preserves known URL-specific task handling', () => {
  assert.equal(classifyExercise({ pathname: '/doplnovacka-akuzativ-4-pad/123' }).type, 'czech_case_choice');
});

test('recognizes exercise type from loaded page scripts when the URL is generic', () => {
  const task = classifyExercise({
    pathname: '/cviceni/123',
    scriptUrls: ['https://cdn.umimefakta.cz/exercise/porozumeni.js?v=3']
  });
  assert.equal(task.type, 'reading_comprehension');
  assert.equal(task.source, 'script');
});

test('structure clues provide a fallback when a page loads bundled scripts', () => {
  assert.equal(classifyExercise({ structure: { stepCards: true } }).type, 'step_by_step');
  assert.equal(classifyExercise({ structure: { answerInputs: true } }).type, 'written_answer');
  assert.equal(classifyExercise({}).type, 'generic');
});

test('prefers specific game scripts over shared exercise scripts', () => {
  assert.equal(classifyExercise({
    pathname: '/some-unrecognized-topic/123',
    scriptUrls: ['/exercise/novaDoplnovacka.js', '/exercise/roboti.js']
  }).type, 'robot_puzzle');
});
test('audio activity routes are distinguished from text gap dictation',()=>{
 for(const pathname of ['/mluveny-diktat-test/1','/mluvené-diktáty','/poslech-slovicek-sport-2']) assert.equal(classifyExercise({pathname}).type,'audio');
 assert.equal(classifyExercise({pathname:'/diktat-test',structure:{gapDropdowns:true}}).type,'gap_fill');
});
