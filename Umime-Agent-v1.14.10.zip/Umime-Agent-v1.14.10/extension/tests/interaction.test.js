'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
function harness() {
  class Element {
    constructor(tag='DIV') {this.tagName=tag;this.isConnected=true;this.value='';this.attrs={};this.events=[];this.options=[];}
    getBoundingClientRect(){return {left:0,top:0,width:100,height:30};}
    getAttribute(name){return this.attrs[name] || null;}
    dispatchEvent(event){this.events.push(event);this.onEvent?.(event);return true;}
    focus(){}
    contains(el){return el===this;}
  }
  class Input extends Element {constructor(){super('INPUT');this.type='text';}}
  class Textarea extends Element {constructor(){super('TEXTAREA');}}
  class Event {constructor(type,options){this.type=type;Object.assign(this,options);}}
  const document={scripts:[],querySelector:()=>null,getElementById:()=>null,elementFromPoint:()=>null};
  const window={UmimeSites:require('../site-config'),postMessage(){}};window.top=window;
  const context=vm.createContext({window,document,location:{hostname:'www.umimecesky.cz',pathname:'/vpisovacka-test/1'},console,
    Element,HTMLInputElement:Input,HTMLTextAreaElement:Textarea,Event,InputEvent:Event,KeyboardEvent:Event,
    setTimeout,clearTimeout,getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'}),
    chrome:{storage:{local:{get:async()=>({})},onChanged:{addListener(){}}}}});
  let source=fs.readFileSync(path.join(__dirname,'../ai-agent.js'),'utf8');
  source=source.slice(0,source.lastIndexOf("  window.addEventListener('message', onOverlayCommand"));
  source+=`globalThis.api={targetText,typeText,fillElement,clickElement,
    stop(){stopRequested=true;},
    allowFill(){clickElement=async()=>true;},
    cancelDuringMove(){scrollElementIntoView=async()=>true; moveCursorTo=async()=>{stopRequested=true;return true;};}
  };})();`;
  vm.runInContext(source,context);
  return {api:context.api,Element,Input,Textarea};
}

test('associated labels and placeholders are consistent and exclude mutable input value',()=>{
  const {api,Input}=harness();const el=new Input();el.value='previous answer';el.attrs.placeholder='Answer';
  assert.equal(api.targetText(el),'Answer');
  el.labels=[{textContent:'Vyplňte číslo'}];assert.equal(api.targetText(el),'Vyplňte číslo');
  el.value='changed';assert.equal(api.targetText(el),'Vyplňte číslo');
});
test('Stop during cursor travel prevents the click',async()=>{
  const {api,Element}=harness();let clicked=false;const el=new Element();el.click=()=>{clicked=true;};
  api.cancelDuringMove();assert.equal(await api.clickElement(el),false);assert.equal(clicked,false);
});
test('Stop during typing halts remaining characters and change event',async()=>{
  const {api,Input}=harness();const el=new Input();el.onEvent=e=>{if(e.type==='input' && e.data==='a')api.stop();};
  assert.equal(await api.typeText(el,'abcdef'),false);assert.equal(el.value,'a');
  assert.equal(el.events.some(e=>e.type==='change'),false);
});
test('negative numeric answer is written as a complete value',async()=>{
  const {api,Input}=harness();const el=new Input();el.type='number';api.allowFill();
  assert.equal(await api.fillElement(el,'-2.5'),true);assert.equal(el.value,'-2.5');
  assert.equal(el.events.filter(e=>e.type==='input').length,1);
});
test('fill rejects buttons and password fields without clicking them',async()=>{
  const {api,Input,Element}=harness();const password=new Input();password.type='password';
  assert.equal(await api.fillElement(password,'secret'),false);
  assert.equal(await api.fillElement(new Element('BUTTON'),'oops'),false);
});
test('select preserves accents and rejects duplicate labels and disabled choices',async()=>{
  const {api,Element}=harness();api.allowFill();const el=new Element('SELECT');
  el.options=[{value:'1',textContent:'byt'},{value:'2',textContent:'být'},{value:'3',textContent:'x',disabled:true}];
  assert.equal(await api.fillElement(el,'být'),true);assert.equal(el.value,'2');
  assert.equal(await api.fillElement(el,'x'),false);
  el.options.push({value:'4',textContent:'být'});assert.equal(await api.fillElement(el,'být'),false);
});
