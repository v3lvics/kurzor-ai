'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {identity,transition,confirm,questionChanged}=require('../exercise-state');
const choices=['A','B'].map((text,i)=>({id:`t${i}`,tag:'span',answerOption:true,text}));
const snap=(questionText='Question',candidates=choices,textFp='same')=>({questionText,candidates,textFp});
test('typing, selected states and generated IDs do not change question identity',()=>{
 const base=[...choices,{id:'t3',tag:'input',inputType:'text',value:''}];
 assert.equal(identity('Question',base),identity('Question',base.map(c=>({...c,id:'t99',value:'filled',state:{checked:'true'},position:{x:100,y:400}}))));
});
test('select selection does not change question identity',()=>{
 const c={tag:'select',options:[{value:'a',text:'A',selected:false}]};
 assert.equal(identity('Q',[c]),identity('Q',[{...c,options:[{value:'a',text:'A',selected:true}]}]));
});
test('progress-only decorations do not change identity',()=>{
 assert.equal(identity('Q',choices),identity('Q',[...choices,{tag:'span',text:'1 / 12 done'}]));
});
test('math, choice labels and image changes do change identity',()=>{
 assert.notEqual(identity('2/3',choices),identity('3/2',choices));
 assert.notEqual(identity('Q',choices),identity('Q',[{...choices[0],text:'C'}]));
 assert.notEqual(identity('Q',choices,['a.png']),identity('Q',choices,['b.png']));
});
test('a completed set never starts another solve or clicks continue',()=>{
 assert.equal(transition({finished:true,pending:true,next:true}),'complete');
});
test('new question takes priority over a stale next button',()=>{
 assert.equal(transition({pending:true,changed:true,next:true}),'advanced');
});
test('written answer is evaluated once and waits for feedback',()=>{
 assert.equal(transition({pending:true,evaluate:true}),'evaluate');
 assert.equal(transition({pending:true,evaluate:true,evaluated:true}),'wait');
 assert.equal(transition({pending:true,evaluated:true,next:true}),'advance');
});
test('unchanged answered question never sends another solve request',()=>{
 for(const elapsed of [0,200,1200,10000]) assert.equal(transition({pending:true,elapsed}),'wait');
 assert.equal(transition({pending:true,elapsed:12000}),'stalled');
});
test('progress is counted once per pending answer, not per action or poll',()=>{
 const state={solved:0,counted:false};
 for(let i=0;i<20;i++) confirm(state);
 assert.equal(state.solved,1);
 state.counted=false;confirm(state);assert.equal(state.solved,2);
});
test('vanishing choices and loading frames are not new questions',()=>{
 assert.equal(questionChanged(snap(),snap('Question',[])),false);
 assert.equal(questionChanged(snap(),snap('',[])),false);
});
test('changed question or nonempty choice set advances without page reload',()=>{
 assert.equal(questionChanged(snap(),snap('New question')),true);
 assert.equal(questionChanged(snap(),snap('Question',[{...choices[0],text:'C'}])),true);
});
test('same question with different progress text remains pending',()=>{
 assert.equal(questionChanged(snap('Q',choices,'0/12'),snap('Q',choices,'1/12')),false);
});
test('empty submissions require explicit high-confidence text-marking result',()=>{
 const {canSubmitEmpty}=require('../exercise-state');
 const result={noSelectionNeeded:true,needsMoreContext:false,confidence:0.95,actions:[]};
 assert.equal(canSubmitEmpty('text_marking',result),true);
 assert.equal(canSubmitEmpty('written_answer',result),false);
 assert.equal(canSubmitEmpty('text_marking',{...result,confidence:0.6}),false);
 assert.equal(canSubmitEmpty('text_marking',{...result,noSelectionNeeded:false}),false);
 assert.equal(canSubmitEmpty('text_marking',{...result,actions:[{type:'click'}]}),false);
});
test('missing controls produce an actionable notice at 15 seconds',()=>{
 const {waitFailure}=require('../exercise-state');assert.equal(waitFailure('controls',14999),'');assert.match(waitFailure('controls',15000),/may not be supported/);assert.match(waitFailure('controls',15000),/Alt\+click/);
});
test('global no-progress deadline is 45 seconds',()=>{
 const {waitFailure}=require('../exercise-state');assert.equal(waitFailure('progress',44999),'');assert.match(waitFailure('progress',45000),/No progress/);
});
test('fresh progress does not trigger a waiting failure',()=>{
 const {waitFailure}=require('../exercise-state');assert.equal(waitFailure('progress',0),'');assert.equal(waitFailure('controls',0),'');
});
