const test=require('node:test');const assert=require('node:assert/strict');const {solve}=require('../local-answer-solver');
const c=[{id:'t1',answerOption:true},{id:'t2',answerOption:true}];
const lookup=markers=>id=>markers[id]===undefined?null:{isConnected:true,getAttribute:()=>markers[id]};
test('returns unique explicit local answer with no AI request',()=>{const r=solve(c,lookup({t1:'0',t2:'1'}));assert.equal(r.actions[0].targetId,'t2');assert.equal(r.source,'page-data');});
test('ambiguous and missing markers fall through to AI',()=>{assert.equal(solve(c,lookup({t1:'1',t2:'1'})),null);assert.equal(solve(c,lookup({t1:'0'})),null);});
test('ignores rejected/selected or disconnected targets',()=>{assert.equal(solve([{...c[0],state:{incorrect:true}}],lookup({t1:'1'})),null);assert.equal(solve(c,()=>({isConnected:false,getAttribute:()=> '1'})),null);});
test('non-answer controls cannot become local answers',()=>{assert.equal(solve([{id:'next',answerOption:false}],lookup({next:'1'})),null);});
