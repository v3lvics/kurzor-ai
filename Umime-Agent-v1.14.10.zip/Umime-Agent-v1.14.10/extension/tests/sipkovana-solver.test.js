'use strict';

const assert = require('node:assert/strict');
const test = require('node:test');
const solver = require('../sipkovana-solver.js');

function snapshot({ start = true, commandClass = 'arrow green', commandCount = '1' } = {}) {
  const cells = [];
  for (let y = 0; y < 2; y++) {
    for (let x = 0; x < 2; x++) {
      const children = [];
      if (x === 0 && y === 0) {
        children.push({ tag: 'img', cls: 'bot green', src: '/frodoD.png', id: 'bot1' });
      }
      if (x === 1 && y === 1) {
        children.push({ tag: 'img', cls: '', src: '/doorgreen.png', id: '' });
      }
      cells.push({
        x, y, cls: 'sand', text: '',
        children
      });
    }
  }
  return {
    cells,
    commands: [{ index: 0, domId: 'command0', cls: commandClass, text: commandCount }],
    flags: { hasTable: true, hasStart: true, startVisible: start, solved: false }
  };
}

test('parses a clean board and searches a verified arrow route', () => {
  const parsed = solver.parseSnapshot(snapshot());
  assert.equal(parsed.ok, true);

  const result = solver.solve(parsed.puzzle, { maxMs: 1000, maxWork: 10000 });
  assert.equal(result.status, 'solved');
  assert.equal(result.plan.steps, 2);
  assert.deepEqual(result.plan.placements, [
    { x: 0, y: 1, type: 'arrow', color: 'green', direction: 0 }
  ]);
  assert.equal(solver.verifyPlan(parsed.puzzle, result.plan.placements).ok, true);
});

test('classifies grass as blocked and frozen terrain as walkable but not placeable', () => {
  const board = snapshot();
  board.cells.find(cell => cell.x === 1 && cell.y === 0).cls = 'grass';
  board.cells.find(cell => cell.x === 0 && cell.y === 1).cls = 'frozen';
  const parsed = solver.parseSnapshot(board);
  assert.equal(parsed.ok, true);
  assert.deepEqual(parsed.puzzle.plan, ['*#', '+*']);
});

test('finds and verifies a jump placement needed to cross a hole', () => {
  const puzzle = {
    width: 5, height: 1, plan: ['**@**'],
    bots: [{ x: 0, y: 0, direction: 0, color: 'green' }],
    goals: [{ x: 4, y: 0, color: 'green' }],
    treasures: [], actions: [],
    commands: [{ type: 'jump', color: 'green', remaining: 1 }]
  };
  const result = solver.solve(puzzle, { maxMs: 1000, maxWork: 10000 });
  assert.equal(result.status, 'solved');
  assert.equal(result.plan.placements.length, 1);
  assert.equal(result.plan.placements[0].type, 'jump');
  assert.equal(solver.verifyPlan(puzzle, result.plan.placements).ok, true);
});

test('reports no route when the only path is blocked and there are no commands', () => {
  const puzzle = {
    width: 3, height: 1, plan: ['*#*'],
    bots: [{ x: 0, y: 0, direction: 0, color: 'green' }],
    goals: [{ x: 2, y: 0, color: 'green' }],
    treasures: [], actions: [], commands: []
  };
  assert.equal(solver.solve(puzzle, { maxMs: 1000, maxWork: 10000 }).status, 'no-solution');
});

test('places teleport pairs to route around a blocked cell', () => {
  const puzzle = {
    width: 5, height: 1, plan: ['**#**'],
    bots: [{ x: 0, y: 0, direction: 0, color: 'green' }],
    goals: [{ x: 4, y: 0, color: 'green' }],
    treasures: [], actions: [],
    commands: [{ type: 'teleport', color: null, remaining: 2 }]
  };
  const result = solver.solve(puzzle, { maxMs: 1000, maxWork: 10000, minimise: false });
  assert.equal(result.status, 'solved');
  assert.equal(result.plan.placements.filter(item => item.type === 'teleport').length, 2);
  assert.equal(solver.verifyPlan(puzzle, result.plan.placements).ok, true);
});

test('refuses boards that are already running', () => {
  const parsed = solver.parseSnapshot(snapshot({ start: false }));
  assert.equal(parsed.ok, false);
  assert.equal(parsed.status, 'not-clean');
});

test('rejects unknown command types instead of guessing', () => {
  const parsed = solver.parseSnapshot(snapshot({ commandClass: 'laser green' }));
  assert.equal(parsed.ok, false);
  assert.equal(parsed.status, 'unsupported');
  assert.match(parsed.reasons.join(' '), /unknown command type/);
});

test('parses palette metadata when selected classes come first', () => {
  const parsed = solver.parseSnapshot(snapshot({ commandClass: 'selected arrow green' }));
  assert.equal(parsed.ok, true);
  assert.equal(parsed.puzzle.commands[0].type, 'arrow');
  assert.equal(parsed.puzzle.commands[0].color, 'green');
});

test('rejects malformed grid coordinates without throwing', () => {
  const malformed = snapshot();
  malformed.cells[0].x = NaN;
  assert.doesNotThrow(() => solver.parseSnapshot(malformed));
  assert.equal(solver.parseSnapshot(malformed).status, 'unsupported');
});

test('verifies command budgets and board bounds', () => {
  const parsed = solver.parseSnapshot(snapshot());
  assert.equal(parsed.ok, true);
  const invalid = [
    { x: 0, y: 1, type: 'arrow', color: 'green', direction: 0 },
    { x: 0, y: 0, type: 'arrow', color: 'green', direction: 1 }
  ];
  assert.match(solver.checkPlacements(parsed.puzzle, invalid).join(' '), /not a free|budget exceeded/);
});
