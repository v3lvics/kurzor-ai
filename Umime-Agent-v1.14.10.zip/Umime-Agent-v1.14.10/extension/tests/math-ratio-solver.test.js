'use strict';

const assert = require('node:assert/strict');
const test = require('node:test');
const solver = require('../math-ratio-solver.js');

const question = 'Rozdělte číslo 15 15 v poměru 3 : 2 3:2 Jaký bude první krok výpočtu?';
const options = [
  { id: 't1', domId: 'option0', text: 'Číslo 15 15 rozdělíme na 3 + 2 = 5 3+2=5 dílů.' },
  { id: 't2', domId: 'option1', text: 'Číslo 15 15 vydělíme prvním členem poměru, tedy třemi.' }
];

test('solves the first-step ratio-splitting exercise locally', () => {
  assert.deepEqual(solver.solveRatioDivisionFirstStep(question, options), {
    targetId: 't1',
    summary: 'Add the ratio parts: 3 + 2 = 5.'
  });
});

test('matches the live page text with line breaks from rendered math', () => {
  const liveQuestion = 'Rozdělte číslo \n15\n15 v poměru \n3\n:\n2\n3:2\nJaký bude první krok výpočtu?';
  const liveOptions = [
    { id: 't1', domId: 'option0', text: 'Číslo \n15\n15 rozdělíme na \n3\n+\n2\n=\n5\n3+2=5 dílů.' },
    { id: 't2', domId: 'option1', text: 'Číslo \n15\n15 vydělíme prvním členem poměru, tedy třemi.' }
  ];
  assert.equal(solver.solveRatioDivisionFirstStep(liveQuestion, liveOptions)?.targetId, 't1');
});

test('solves the saved exercise step asking how many parts to split into', () => {
  const savedQuestion = 'Rozdělte číslo 63 v poměru 7 : 2 Číslo 63 rozdělíme na:';
  const savedOptions = [
    { id: 't1', domId: 'option0', text: '7 − 2 = 5 dílů' },
    { id: 't2', domId: 'option1', text: '7 + 2 = 9 dílů' }
  ];
  assert.equal(solver.solveRatioDivisionFirstStep(savedQuestion, savedOptions)?.targetId, 't2');
});

test('solves the one-part calculation from a rendered math expression', () => {
  const result = solver.solveRatioDivisionFirstStep(
    'Rozdělte číslo 63 v poměru 7 : 2. Jeden díl je:',
    [
      { id: 't1', domId: 'option0', text: '63 : 9 = 7', expressions: ['\\frac{63}{9}=7'] },
      { id: 't2', domId: 'option1', text: '63 : 7 = 9', expressions: ['63/7=9'] }
    ]
  );
  assert.equal(result?.targetId, 't1');
  assert.equal(solver.solveRatioDivisionFirstStep(
    'Rozdělte číslo 63 v poměru 7 : 2. Jednotková hodnota:',
    [
      { id: 't1', domId: 'option0', expressions: ['63/9=7'] },
      { id: 't2', domId: 'option1', expressions: ['63/7=9'] }
    ]
  )?.targetId, 't1');
});

test('solves first and second shares using the ratio and one-part value', () => {
  const options = [
    { id: 't1', domId: 'option0', text: '7 · 7 = 49', expressions: ['7\\cdot 7=49'] },
    { id: 't2', domId: 'option1', text: '2 · 7 = 14', expressions: ['2\\cdot 7=14'] }
  ];
  assert.equal(solver.solveRatioDivisionFirstStep(
    'Rozdělte číslo 63 v poměru 7 : 2. První část:',
    options
  )?.targetId, 't1');
  assert.equal(solver.solveRatioDivisionFirstStep(
    'Rozdělte číslo 63 v poměru 7 : 2. Druhá část:',
    options
  )?.targetId, 't2');
});

test('evaluates basic arithmetic without executing arbitrary code', () => {
  assert.deepEqual(solver.evaluateExpression('\\frac{63}{9}=7'), {
    left: 7,
    right: 7,
    correct: true
  });
  assert.equal(solver.evaluateExpression('globalThis.alert(1)'), null);
});

test('handles changed numbers and reversed ratio-part order', () => {
  const result = solver.solveRatioDivisionFirstStep(
    'Rozdělte číslo 84 v poměru 4:3. Jaký bude první krok výpočtu?',
    [{ id: 't7', domId: 'option0', text: 'Číslo rozdělíme na 3 + 4 = 7 dílů.' }]
  );
  assert.equal(result?.targetId, 't7');
});

test('does not guess when the question or matching choice is unsupported', () => {
  assert.equal(solver.solveRatioDivisionFirstStep('Vypočítejte části v poměru 3:2.', options), null);
  assert.equal(solver.solveRatioDivisionFirstStep(question, [options[1]]), null);
});

test('does not choose between multiple matching options', () => {
  assert.equal(solver.solveRatioDivisionFirstStep(question, [
    options[0],
    { ...options[0], id: 't3', domId: 'option2' }
  ]), null);
});
