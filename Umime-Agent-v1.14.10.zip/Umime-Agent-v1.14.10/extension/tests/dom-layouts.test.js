const test=require('node:test');const assert=require('node:assert/strict');const harness=require('./helpers/dom-harness');
const state=require('../exercise-state');
const wrap=html=>`<div id="exercise"><div id="playground">${html}</div></div>`;
test('modern choice cards retain complete formula and avoid nested glyph targets',()=>{
 const {api}=harness(wrap('<div data-data="question">Choose the fraction.</div><span class="card" data-data="option"><span class="katex"><span class="katex-mathml"><annotation encoding="application/x-tex">\\frac{1}{2}</annotation></span><span class="katex-html" aria-hidden="true"><span>1</span><span>2</span></span></span></span>'));
 const snap=api.captureSnapshot();assert.equal(snap.candidates.filter(c=>c.answerOption).length,1);assert.match(snap.candidates.find(c=>c.answerOption).answerText,/frac/);
});
test('matching has one target per card rather than separate child text',()=>{
 const {api}=harness(wrap('<div id="pexeso"><div class="card even" data-index="0"><div class="card-content"><span>velký</span></div></div><div class="card odd" data-index="1"><div class="card-content"><span>obrovský</span></div></div></div>'),'/pexeso-test/1');
 assert.equal(api.captureSnapshot().candidates.length,2);
});
test('word marking has one target per selectable word',()=>{
 const {api}=harness(wrap('<div id="question-content"><span class="selectable-area" data-index="0"><span class="content">Slovo<span class="anchor"></span></span></span><span class="selectable-area" data-index="1"><span class="content">druhé<span class="anchor"></span></span></span></div>'),'/oznacovani-korektury-test/1');
 assert.equal(api.captureSnapshot().candidates.length,2);
});
test('custom gaps expose only current visible variants and identify the active gap',()=>{
 const {api}=harness(wrap('<div id="dictate">M<span class="gap-dropdown" id="gap0" answered="0"><span class="gap-cursor current">_</span><span class="gap-dropdown-content"><span class="variant" gapid="gap0">i</span><span class="variant" gapid="gap0">y</span></span></span> jsme doma.</div>'));
 assert.equal(api.detectTask().type,'gap_fill');
 const snap=api.captureSnapshot();assert.equal(snap.candidates.length,2);assert.equal(snap.widgetState.activeGap,'gap0');
});
test('span next controls are recognized',()=>{
 const {api}=harness(wrap('<div id="question">Example question.</div><span class="tlacitko large primary next">Další</span>'));
 assert.ok(api.findAdvanceControl(null));
});
test('a vocabulary option named next remains an answer',()=>{
 const {api}=harness(wrap('<div data-data="question">Translate následující.</div><span class="card" data-data="option">next</span>'));
 assert.equal(api.captureSnapshot().candidates.filter(c=>c.answerOption).length,1);
 assert.equal(api.findAdvanceControl(null),null);
});
test('question identity excludes selected marking but includes passage text',()=>{
 const {api,document}=harness(wrap('<div id="question-content"><span class="selectable-area">A word</span></div>'),'/oznacovani-korektury-test/1');
 const before=api.captureSnapshot();document.querySelector('.selectable-area').classList.add('selected');
 assert.equal(api.captureSnapshot().questionFp,before.questionFp);
});
test('drag-and-drop layout is identified instead of being mistaken for generic clicks',()=>{
 const {api}=harness(wrap('<div class="ui-draggable" id="word0">item</div><div class="ui-droppable" id="slot0"></div>'),'/rozrazovacka-test');
 assert.equal(api.detectTask().type,'drag_and_drop');
});
test('moving to another gap is a new step even when its letter choices are identical',()=>{
 const {api,document}=harness(wrap('<div id="dictate">M<span class="gap-dropdown" id="gap0" answered="0"><span class="gap-cursor current">_</span><span class="gap-dropdown-content"><span class="variant">i</span><span class="variant">y</span></span></span> a v<span class="gap-dropdown" id="gap1" answered="0"><span class="gap-cursor">_</span></span>.</div>'));
 const before=api.captureSnapshot();document.querySelector('#gap0').setAttribute('answered','1');document.querySelector('.current').classList.remove('current');document.querySelector('#gap1 .gap-cursor').classList.add('current');
 const menu=document.querySelector('.gap-dropdown-content');document.querySelector('#gap1').append(menu);
 const after=api.captureSnapshot();assert.equal(state.questionChanged(before,after),true);
});
test('matching selection alone is stable but removing a completed pair advances',()=>{
 const {api,document}=harness(wrap('<div id="pexeso">'+['a','b','c','d'].map((x,i)=>`<div class="card" data-index="${i}">${x}</div>`).join('')+'</div>'),'/pexeso-test/1');
 const before=api.captureSnapshot();document.querySelector('.card').classList.add('selected');
 assert.equal(state.questionChanged(before,api.captureSnapshot()),false);
 document.querySelectorAll('.card')[0].remove();document.querySelectorAll('.card')[0].remove();
 assert.equal(state.questionChanged(before,api.captureSnapshot()),true);
});
test('hidden answer metadata and irrelevant UI are absent from model prompt',()=>{
 const {api}=harness(wrap('<modal-dialog>UNRELATED-PRIVATE-TEXT</modal-dialog><div id="dictate">Slov<span class="gap-dropdown" id="gap0" variants="i|y|01" answered="0"><span class="gap-cursor current">_</span><span class="gap-dropdown-content"><span class="variant" correct="0">i</span><span class="variant" correct="1">y</span></span></span></div>'));
 const prompt=api.captureSnapshot().prompt;
 assert.ok(!prompt.includes('UNRELATED-PRIVATE-TEXT'));assert.ok(!prompt.includes('i|y|01'));assert.ok(!prompt.includes('correct="1"'));
});
test('Czech check controls without evaluate ID can be detected',()=>{
 const {api}=harness(wrap('<div id="question">A test question.</div><div class="control-panel"><button>Zkontrolovat</button></div>'));
 assert.ok(api.findEvaluationControl());
});
