const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../offline/engine.js'),'utf8');
const fn=source.slice(source.indexOf('    function correctIndex()'),source.indexOf('    async function answer()',source.indexOf('    function correctIndex()')));
function resolve(labels,onScreen=true){return vm.runInNewContext(fn+';correctIndex()',{
 currentItem:()=>({onScreen,item:{options:[{correct:1,option:'right'},{correct:0,option:'wrong'}]}}),
 isCorrect:o=>o.correct===1,optionEl:i=>({textContent:labels[i]}),window:{renderContentFormat:text=>({textContent:text})}
});}
test('choice remaps a uniquely matching rendered answer after reshuffle',()=>assert.equal(resolve(['wrong','right']),1));
test('choice declines missing answer instead of clicking old index',()=>assert.equal(resolve(['other','wrong']),-1));
test('downloaded answer refuses ambiguous duplicate labels',()=>assert.equal(resolve(['right','right'],false),-1));
