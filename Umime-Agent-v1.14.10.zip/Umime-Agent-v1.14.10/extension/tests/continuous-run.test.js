'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');

test('actual solver runs two written questions with one start and one AI call per answer',async()=>{
 const events=[];const metrics={ask:0,apply:0,evaluate:0,next:0};let q=1,phase='question';
 const snapshot=()=>({prompt:`question ${q}`,questionText:`Question ${q}`,textFp:`q${q}`,questionFp:`q${q}`,
  candidates:[{id:'t1',tag:'input',inputType:'text',text:''}],canvasImages:[],baseline:new Set(),hasContent:true});
 const next={id:'next',isConnected:true};const evaluate={id:'evaluate'};
 const document={scripts:[],querySelector:()=>null,querySelectorAll:()=>phase==='finished'?[{}]:[]};
 const window={UmimeSites:require('../site-config'),UmimeExerciseState:require('../exercise-state'),postMessage:m=>events.push(m)};window.top=window;
 const context=vm.createContext({window,document,location:{hostname:'www.umimecesky.cz',pathname:'/vpisovacka-test/1'},console,
  setTimeout,clearTimeout,Set,sessionStorage:{setItem(){},removeItem(){}},
  chrome:{runtime:{sendMessage:async()=>({ok:true})},storage:{local:{get:async()=>({})},onChanged:{addListener(){}}}},});
 context.fixture={metrics,snapshot,next,evaluate,
  phase:()=>phase,ask:async()=>{metrics.ask++;return{needsMoreContext:false,actions:[{type:'fill',targetId:'t1',value:'answer'}]};},
  execute:async()=>{metrics.apply++;phase='filled';return{done:1,interrupted:false,answerTargetIds:['t1']};},
  click:async el=>{if(el===evaluate){metrics.evaluate++;phase='graded';}else{metrics.next++;q++;phase=q>2?'finished':'question';}return true;}};
 let source=fs.readFileSync(path.join(__dirname,'../ai-agent.js'),'utf8');
 source=source.slice(0,source.lastIndexOf("  window.addEventListener('message', onOverlayCommand"));
 source+=`settle=async()=>{}; pause=async()=>true; isVisible=()=>true;
 captureSnapshot=fixture.snapshot; textFingerprint=()=>fixture.snapshot().textFp;
 askGemini=fixture.ask; executeActions=fixture.execute; clickElement=fixture.click;
 findAdvanceControl=()=>fixture.phase()==='graded'?fixture.next:null;
 findEvaluationControl=()=>fixture.phase()==='filled'?fixture.evaluate:null;
 controlText=el=>el.id; findRejectedAttempt=()=>null;
 globalThis.run=runSolver;})();`;
 vm.runInContext(source,context);
 const first=context.run();
 const duplicate=context.run();
 await Promise.all([first,duplicate]);
 assert.deepEqual(metrics,{ask:2,apply:2,evaluate:2,next:2});
 assert.equal(events.filter(e=>e.type==='start').length,1);
 assert.deepEqual(events.filter(e=>e.type==='progress').map(e=>e.solved),[1,2]);
 assert.equal(events.at(-1).type,'complete');
});
