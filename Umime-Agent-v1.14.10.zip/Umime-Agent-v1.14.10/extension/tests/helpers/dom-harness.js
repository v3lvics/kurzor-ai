const {parseHTML}=require('linkedom');
const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
module.exports=function(html,pathname='/cviceni/1'){
 const {document,window:dom}=parseHTML('<html><head><title>Fixture</title></head><body>'+html+'</body></html>');
 Object.defineProperty(document,'scripts',{get:()=>document.querySelectorAll('script')});
 dom.Element.prototype.getBoundingClientRect=function(){const hidden=this.closest('[hidden],[style*="display:none"],[style*="display: none"]');return {x:0,y:0,left:0,top:0,right:hidden?0:100,bottom:hidden?0:30,width:hidden?0:100,height:hidden?0:30};};
 const win={UmimeSites:require('../../site-config'),UmimeExerciseState:require('../../exercise-state'),UmimeExerciseInspector:require('../../exercise-inspector'),UmimeActionValidator:require('../../action-validator'),postMessage(){}};win.top=win;
 const context=vm.createContext({window:win,document,location:{hostname:'www.umimecesky.cz',pathname,href:'https://www.umimecesky.cz'+pathname},
  Element:dom.Element,HTMLInputElement:dom.HTMLInputElement,HTMLTextAreaElement:dom.HTMLTextAreaElement,console,setTimeout,clearTimeout,
  getComputedStyle:el=>({display:el.style.display||'block',visibility:el.style.visibility||'visible',opacity:'1',cursor:el.style.cursor||'pointer'}),
  chrome:{storage:{local:{get:async()=>({})},onChanged:{addListener(){}}}}});
 let source=fs.readFileSync(path.join(__dirname,'../../ai-agent.js'),'utf8');
 source=source.slice(0,source.lastIndexOf("  window.addEventListener('message', onOverlayCommand"));
 source+='globalThis.api={captureSnapshot,findEvaluationControl,findAdvanceControl,getCandidateElements,cleanExerciseText,extractQuestionText,detectTask};})();';
 vm.runInContext(source,context);return {document,api:context.api};
};
