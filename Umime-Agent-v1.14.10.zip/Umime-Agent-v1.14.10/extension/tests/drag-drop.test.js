const test=require('node:test');const assert=require('node:assert/strict');
const drag=require('../drag-drop');const {validate,planIsCurrent}=require('../action-validator');
function fixture(accept=true){
 let held=false,cancel=false,ups=0;
 const source={id:'word0',isConnected:true,getAttribute:n=>({word:'0',currentbox:held?'slot0':'-1'}[n]),matches:()=>true,getBoundingClientRect:()=>({left:10,top:10,width:30,height:20,right:40,bottom:30}),contains:e=>e===source,dispatchEvent(){}};
 const target={id:'slot0',isConnected:true,getAttribute:()=>held?'0':'-1',matches:()=>true,getBoundingClientRect:()=>({left:100,top:10,width:40,height:30,right:140,bottom:40}),contains:e=>e===target,dispatchEvent(e){if(e.type==='mouseup'){ups++;if(accept)held=true;}}};
 class MouseEvent{constructor(type,args){this.type=type;Object.assign(this,args);}}
 const doc={defaultView:{innerHeight:600,innerWidth:800,MouseEvent},elementFromPoint:x=>x<70?source:target,dispatchEvent(e){if(e.type==='mouseup')ups++;}};
 return {source,target,doc,alive:()=>!cancel,move:async()=>true,sleep:async()=>{},emit(){},stop(){cancel=true;},get ups(){return ups;}};
}
test('accepts only paired source/drop-target metadata',()=>{
 const actions=[{type:'drag',targetId:'t1',dropTargetId:'t2'}];
 validate({needsMoreContext:false,actions});
 assert.equal(planIsCurrent(actions,[{id:'t1',draggable:true},{id:'t2',dropTarget:true,occupied:false}],[]),true);
 assert.equal(planIsCurrent(actions,[{id:'t1',draggable:true},{id:'t2',dropTarget:true,occupied:true}],[]),false);
 assert.throws(()=>validate({needsMoreContext:false,actions:[{type:'drag',targetId:'t1',dropTargetId:'t1'}]}));
});
test('reports success only after page placement state changes',async()=>assert.equal(await drag.perform(fixture()),true));
test('does not claim success if the page rejects mouse drop',async()=>assert.equal(await drag.perform(fixture(false)),false));
test('cancellation during drag releases mouse and reports failure',async()=>{
 const f=fixture();f.sleep=async()=>f.stop();assert.equal(await drag.perform(f),false);assert.equal(f.ups,1);
});
