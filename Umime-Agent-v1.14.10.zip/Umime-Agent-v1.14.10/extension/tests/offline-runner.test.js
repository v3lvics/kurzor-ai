const test=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
function setup(game,currentId=()=> '1',navigation=null){let listener;const events=[];let now=0;const win={UmimeOfflineNavigation:navigation,__neumimetoData:{listeners:[]},UmimeOfflineEngine:{game,currentId},addEventListener:(_type,fn)=>{listener=fn;},postMessage:m=>events.push(m)};
 const ctx=vm.createContext({window:win,document:{getElementById:()=>null},getComputedStyle:()=>({display:'block'}),Date:{now:()=>now+=1000},setTimeout:fn=>{queueMicrotask(fn);return 1;},clearTimeout(){},console});
 vm.runInContext(fs.readFileSync(path.join(__dirname,'../offline-runner.js'),'utf8'),ctx);
 return {events,item:()=>win.__neumimetoData.listeners.forEach(fn=>fn('item')),send:data=>listener({source:win,data})};}
for(const pace of ['instant','smart','human'])test('offline runner completes without any API in '+pace,async()=>{
 let done=false,actions=0,next=0;const g={ready:()=>true,finished:()=>done,plan:()=>({steps:[{run:()=>{actions++;done=true;}}],human:[{wait:.5,run:()=>{actions++;done=true;}}]}),next:()=>next++};
 const h=setup(g);await h.send({channel:'umime-offline-request',type:'start',requestId:'x',pace,autoNext:false});
 assert.equal(actions,1);assert.equal(next,0);assert.equal(h.events[0].accepted,true);assert.equal(h.events.at(-1).type,'complete');
});
test('unreadable supported exercise waits then offers Gemini',async()=>{
 const h=setup({ready:()=>false});await h.send({channel:'umime-offline-request',type:'start',requestId:'x'});
 assert.equal(h.events[0].accepted,true);assert.equal(h.events.at(-1).type,'offer-gemini');assert.equal(h.events.at(-1).text,'Failed to solve');
});
test('Stop prevents subsequent local steps after current async step returns',async()=>{
 let release;let actions=0;const h=setup({ready:()=>true,finished:()=>false,plan:()=>({steps:[{run:()=>new Promise(r=>{actions++;release=r;})},{run:()=>actions++}]})});
 const running=h.send({channel:'umime-offline-request',type:'start',requestId:'x',pace:'instant'});
 await h.send({channel:'umime-ai-overlay',type:'stop-requested'});release();await running;
 assert.equal(actions,1);assert.equal(h.events.some(e=>e.type==='complete'),false);
});
test('continues across three questions while the second plan is still loading',async()=>{
 let q=1,done=false,actions=0,delayed=0;let h;
 const g={ready:()=>true,finished:()=>done,
  plan:()=>{if(q===2&&delayed++<2)return null;return{steps:[{run:()=>{actions++;done=true;}}]};},
  next:()=>{q++;done=false;if(q===4)h.send({channel:'umime-ai-overlay',type:'stop-requested'});}};
 h=setup(g,()=>String(q));await h.send({channel:'umime-offline-request',type:'start',requestId:'x',pace:'instant',autoNext:true});
 assert.equal(actions,3);assert.deepEqual(h.events.filter(e=>e.type==='progress').map(e=>e.solved),[1,2,3]);assert.equal(h.events.some(e=>e.type==='error'),false);
});
test('auto-loaded question is not skipped with another Next',async()=>{
 let q=1,done=false,actions=0,next=0;let h;
 const g={ready:()=>true,finished:()=>done,plan:()=>({steps:[{run:()=>{actions++;if(q===1)q=2;else done=true;}}]}),
  next:()=>{next++;h.send({channel:'umime-ai-overlay',type:'stop-requested'});}};
 h=setup(g,()=>String(q));await h.send({channel:'umime-offline-request',type:'start',requestId:'x',pace:'instant',autoNext:true});
 assert.equal(actions,2);assert.equal(next,1);assert.equal(h.events.some(e=>e.type==='error'),false);
});
test('item event cancels stale steps even when the page reuses the same item ID',async()=>{
 let fresh=false,done=false,stale=0,actions=0;let h;
 const g={ready:()=>true,finished:()=>done,plan:()=>fresh?{steps:[{run:()=>{actions++;done=true;}}]}:{steps:[{run:()=>{actions++;fresh=true;h.item();}},{run:()=>stale++}]},next:()=>h.send({channel:'umime-ai-overlay',type:'stop-requested'})};
 h=setup(g,()=> 'same-id');await h.send({channel:'umime-offline-request',type:'start',requestId:'x',pace:'instant',autoNext:true});
 assert.equal(actions,2);assert.equal(stale,0);assert.equal(h.events.some(e=>e.type==='error'),false);
});
test('clicks a Next button that appears after the adapter shortcut',async()=>{
 let done=false,shortcut=false,clicks=0;let h;
 const button={getBoundingClientRect:()=>({left:10,top:20,width:100,height:30}),click:()=>{clicks++;h.send({channel:'umime-ai-overlay',type:'stop-requested'});}};
 h=setup({ready:()=>true,finished:()=>done,plan:()=>({steps:[{run:()=>done=true}]}),next:()=>{shortcut=true;}},()=> '1',{find:()=>shortcut?button:null});
 await h.send({channel:'umime-offline-request',type:'start',requestId:'x',pace:'smart',autoNext:true});
 assert.equal(clicks,1);
});
test('visible Next is clicked instead of invoking the adapter shortcut',async()=>{
 let done=false,shortcuts=0,clicks=0;let h;
 const button={getBoundingClientRect:()=>({left:0,top:0,width:100,height:30}),click:()=>{clicks++;h.send({channel:'umime-ai-overlay',type:'stop-requested'});}};
 h=setup({ready:()=>true,finished:()=>done,plan:()=>({steps:[{run:()=>done=true}]}),next:()=>shortcuts++},()=> '1',{find:()=>done?button:null});
 await h.send({channel:'umime-offline-request',type:'start',requestId:'x',pace:'instant',autoNext:true});
 assert.equal(clicks,1);assert.equal(shortcuts,0);
});
test('unchanged question after Next pauses instead of solving it again',async()=>{
 let done=false,actions=0;
 const h=setup({ready:()=>true,finished:()=>done,plan:()=>({steps:[{run:()=>{actions++;done=true;}}]}),next:()=>{}});
 await h.send({channel:'umime-offline-request',type:'start',autoNext:true});
 assert.equal(actions,1);assert.equal(h.events.at(-1).type,'offer-gemini');
});
test('answer cursor moves before the target action',async()=>{
 let done=false,h;const target={getBoundingClientRect:()=>({left:0,top:0,width:40,height:40})};
 h=setup({ready:()=>true,finished:()=>done,plan:()=>({steps:[{target:()=>target,run:()=>{assert.ok(h.events.some(e=>e.type==='move'));done=true;}}]})});
 await h.send({channel:'umime-offline-request',type:'start',autoNext:false});assert.equal(done,true);
});
test('supported exercise may become ready after activation',async()=>{
 let polls=0,done=false;
 const h=setup({ready:()=>++polls>2,finished:()=>done,plan:()=>({steps:[{run:()=>done=true}]})});
 await h.send({channel:'umime-offline-request',type:'start',autoNext:false});assert.equal(done,true);
});
