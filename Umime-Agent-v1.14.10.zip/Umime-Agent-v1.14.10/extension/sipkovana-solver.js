/*
 * sipkovana-solver.js — deterministic Šipkovaná (umimeinformatiku.cz/sipkovana) parser, simulator and solver.
 *
 * Plain JavaScript, no dependencies, no DOM access except readSnapshot(doc).
 * Works as a Manifest V3 content-script global (window.SipkovanaSolver) and as a CommonJS module for tests.
 *
 * The simulator covers the mechanics represented below; compare it with live exercises when
 * the site changes or when adding support for additional board elements.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.SipkovanaSolver = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]]; // R D L U (getDirectionCoordinates)
  const DIR_LETTERS = ['R', 'D', 'L', 'U'];
  const ARROW_TYPES = ['arrow', 'arrow1', 'arrowR+', 'arrowR-'];
  const COMMAND_TYPES = ['arrow', 'arrow1', 'arrowR+', 'arrowR-', 'jump', 'gate', 'bomb', 'teleport'];
  const FIXED_TYPES = COMMAND_TYPES.concat(['wand']);
  const isArrow = (t) => ARROW_TYPES.indexOf(t) !== -1;

  /* ------------------------------------------------------------------ */
  /* Snapshot reading + parsing                                          */
  /* ------------------------------------------------------------------ */

  const tokens = (s) => String(s || '').split(/\s+/).filter(Boolean);

  function baseName(src) {
    let n = String(src || '').split('?')[0].split('/').pop();
    try { n = decodeURIComponent(n); } catch (e) { /* keep raw */ }
    return n;
  }

  function isVisible(el) {
    if (!el) return false;
    const win = el.ownerDocument && el.ownerDocument.defaultView;
    if (win && win.getComputedStyle) {
      const cs = win.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return rect.width >= 2 && rect.height >= 2
        && cs.display !== 'none' && cs.visibility !== 'hidden' && Number(cs.opacity || 1) > 0;
    }
    const st = (el.getAttribute && el.getAttribute('style')) || '';
    return !/display\s*:\s*none/.test(st);
  }

  /** Turn the live DOM into plain JSON (also usable as a test fixture: copy(JSON.stringify(readSnapshot(document)))). */
  function readSnapshot(doc) {
    const table = doc.querySelector('table.plan');
    const planRoot = doc.getElementById('plan');
    const cells = table ? Array.from(table.querySelectorAll('td')).map((td) => ({
      x: td.getAttribute('posX') === null ? NaN : Number(td.getAttribute('posX')),
      y: td.getAttribute('posY') === null ? NaN : Number(td.getAttribute('posY')),
      cls: td.getAttribute('class') || '',
      text: (td.textContent || '').trim(),
      children: Array.from(td.children || []).map((k) => ({
        tag: String(k.tagName || '').toLowerCase(),
        cls: k.getAttribute('class') || '',
        src: k.getAttribute('src') || '',
        id: k.getAttribute('id') || '',
      })),
    })) : [];
    const commands = Array.from(doc.querySelectorAll('#commandBar td')).map((td) => {
      const first = td.querySelector('div');
      return {
        index: Number(td.getAttribute('data-command-id')),
        domId: td.getAttribute('id') || '',
        cls: td.getAttribute('class') || '',
        text: ((first || td).textContent || '').trim(),
      };
    });
    const start = doc.getElementById('start');
    return {
      cells, commands,
      flags: {
        hasTable: !!table,
        hasStart: !!start,
        startVisible: isVisible(start),
        solved: !!planRoot && tokens(planRoot.getAttribute('class')).indexOf('correct') !== -1,
      },
    };
  }

  function classifyImage(name) {
    let m;
    if ((m = /^arrow_hide_([a-z]+)([RDLU])\.png$/.exec(name))) return { kind: 'action', type: 'arrow1', color: m[1], value: DIR_LETTERS.indexOf(m[2]) };
    if ((m = /^arrow_rot([+-])_([a-z]+)([RDLU])\.png$/.exec(name))) return { kind: 'action', type: 'arrowR' + m[1], color: m[2], value: DIR_LETTERS.indexOf(m[3]) };
    if ((m = /^arrow_([a-z]+)([RDLU])\.png$/.exec(name))) return { kind: 'action', type: 'arrow', color: m[1], value: DIR_LETTERS.indexOf(m[2]) };
    if ((m = /^catapult([a-z]*)\.png$/.exec(name))) return { kind: 'action', type: 'jump', color: m[1] || null, value: 0 };
    if (name === 'teleport.svg') return { kind: 'action', type: 'teleport', color: null, value: 0 };
    if (name === 'bomba.png') return { kind: 'action', type: 'bomb', color: null, value: 0 };
    if (name === 'wand.png') return { kind: 'action', type: 'wand', color: null, value: 0 };
    if (/^bomba[1-3]\.png$/.test(name)) return { kind: 'midrun' };
    if (name === 'tree3.png') return { kind: 'tile', ch: '#' };
    if (name === 'hole.png') return { kind: 'tile', ch: '@' };
    if (name === 'rock.png') return { kind: 'tile', ch: '&' };
    if (name === 'corn2.png') return { kind: 'treasure' };
    if ((m = /^door([a-z]+?)(open)?\.png$/.exec(name))) return { kind: 'goal', color: m[1], open: !!m[2] };
    if (name === 'spell.png' || name === 'explosion.png') return { kind: 'midrun' };
    return { kind: 'unknown' };
  }

  function classifyBot(src) {
    const m = /^(frodo|frodored|deer|gandalf)(R|D|L|U|Dead)(2)?\.png$/.exec(baseName(src));
    if (!m) return null;
    return { direction: DIR_LETTERS.indexOf(m[2]), dead: m[2] === 'Dead', animFrame: !!m[3] };
  }

  /**
   * Read every cell into a neutral structure. Never throws; problems are collected in `issues`
   * (cannot be modelled => unsupported) and `dirty` (board is not in a clean pre-run state).
   */
  function analyzeSnapshot(snap) {
    const out = { width: 0, height: 0, cells: [], bots: [], goals: [], treasures: [], actions: [], issues: [], dirty: [] };
    if (!snap || !snap.cells || !snap.cells.length) { out.issues.push('no board cells found (table.plan td)'); return out; }
    snap.cells.forEach((c) => {
      if (!Number.isInteger(c.x) || !Number.isInteger(c.y) || c.x < 0 || c.y < 0) {
        out.issues.push('cell without valid posX/posY');
        return;
      }
      out.width = Math.max(out.width, c.x + 1);
      out.height = Math.max(out.height, c.y + 1);
    });
    if (!out.width || !out.height) return out;
    const W = out.width, H = out.height;
    const seen = new Array(W * H).fill(false);
    out.cells = new Array(W * H).fill(null);
    snap.cells.forEach((c) => {
      const where = '(' + c.x + ',' + c.y + ')';
      if (!Number.isInteger(c.x) || !Number.isInteger(c.y) || c.x < 0 || c.y < 0) return;
      const idx = c.y * W + c.x;
      if (idx >= W * H) return;
      if (seen[idx]) { out.issues.push('duplicate cell ' + where); return; }
      seen[idx] = true;
      const floor = tokens(c.cls);
      let ch = null, overlay = false;
      const cell = { x: c.x, y: c.y, ch: null, occupied: false };
      c.children.forEach((k) => {
        const kcls = tokens(k.cls);
        if (k.tag === 'img' && kcls.indexOf('bot') !== -1) {
          const info = classifyBot(k.src);
          const mm = /^bot(\d+)$/.exec(k.id || '');
          const color = kcls.filter((t) => t !== 'bot')[0];
          if (!info || !mm || !color) { out.issues.push('unrecognised bot at ' + where); return; }
          if (info.dead || info.animFrame || floor.indexOf('dead') !== -1) out.dirty.push('bot at ' + where + ' is dead or mid-animation (simulation has run)');
          out.bots.push({ index: Number(mm[1]), x: c.x, y: c.y, direction: info.direction, color });
          overlay = true;
        } else if (k.tag === 'img') {
          const info = classifyImage(baseName(k.src));
          if (info.kind === 'tile') ch = info.ch;
          else if (info.kind === 'treasure') { out.treasures.push({ x: c.x, y: c.y }); overlay = true; }
          else if (info.kind === 'goal') {
            if (info.open) out.dirty.push('open door at ' + where);
            out.goals.push({ x: c.x, y: c.y, color: info.color }); overlay = true;
          } else if (info.kind === 'action') {
            const placed = floor.indexOf('sand') !== -1;
            out.actions.push({ x: c.x, y: c.y, type: info.type, color: info.color, value: info.value, placed });
            if (placed) out.dirty.push('player-placed ' + info.type + ' at ' + where);
            overlay = true;
          } else if (info.kind === 'midrun') out.dirty.push('mid-run image at ' + where + ' (' + baseName(k.src) + ')');
          else out.issues.push('unrecognised image "' + baseName(k.src) + '" at ' + where);
        } else if (k.tag === 'div' && kcls.indexOf('circleX') !== -1) {
          const color = kcls.filter((t) => ['circleX', 'big', 'action'].indexOf(t) === -1)[0] || null;
          const placed = floor.indexOf('sand') !== -1;
          out.actions.push({ x: c.x, y: c.y, type: 'gate', color, value: 0, placed });
          if (placed) out.dirty.push('player-placed gate at ' + where);
          overlay = true;
        } else out.issues.push('unrecognised element <' + k.tag + '> at ' + where);
      });
      if (ch === null) {
        if (overlay) ch = '*';
        else if (c.text === '+') ch = '+';
        else if (floor.indexOf('sand') !== -1 && !c.text) ch = '*';
        else if (floor.indexOf('frozen') !== -1 && !c.text) ch = '+';
        else if (floor.indexOf('grass') !== -1 && !c.text) ch = '#';
        else out.issues.push('cannot classify empty cell ' + where + ' (class "' + c.cls + '")');
      } else if (overlay) out.issues.push('tile object combined with other objects at ' + where);
      cell.ch = ch; cell.occupied = overlay;
      out.cells[idx] = cell;
    });
    for (let i = 0; i < W * H; i++) if (!seen[i]) out.issues.push('missing cell (' + (i % W) + ',' + Math.floor(i / W) + ')');
    out.bots.sort((a, b) => a.index - b.index);
    return out;
  }

  function parseCommands(snap, issues) {
    const cmds = [];
    const colors = ['green', 'red', 'blue', 'black', 'yellow', 'purple'];
    (snap.commands || []).forEach((c) => {
      const t = tokens(c.cls);
      const type = t.find((name) => COMMAND_TYPES.indexOf(name) !== -1);
      const color = t.find((name) => colors.indexOf(name) !== -1) || null;
      const remaining = parseInt((String(c.text).match(/\d+/) || [])[0], 10);
      if (COMMAND_TYPES.indexOf(type) === -1) { issues.push('unknown command type "' + type + '"'); return; }
      if (!isFinite(remaining)) { issues.push('cannot read remaining count of command ' + c.index); return; }
      cmds.push({ index: c.index, domId: c.domId, type, color, remaining, selected: t.indexOf('selected') !== -1 });
    });
    return cmds;
  }

  /** @returns {{ok:true, puzzle}|{ok:false, status:'unsupported'|'not-clean'|'already-solved', reasons:string[]}} */
  function parseSnapshot(snap) {
    if (!snap || !snap.flags || !snap.flags.hasTable) return { ok: false, status: 'unsupported', reasons: ['no table.plan on the page'] };
    if (snap.flags.solved) return { ok: false, status: 'already-solved', reasons: ['page is already in the solved state'] };
    const a = analyzeSnapshot(snap);
    const issues = a.issues.slice();
    const commands = parseCommands(snap, issues);
    if (issues.length) return { ok: false, status: 'unsupported', reasons: issues };
    const dirty = a.dirty.slice();
    if (snap.flags.hasStart && !snap.flags.startVisible) dirty.push('simulation is running or finished (Start button hidden)');
    if (dirty.length) return { ok: false, status: 'not-clean', reasons: dirty };
    if (!a.bots.length) return { ok: false, status: 'unsupported', reasons: ['no bots on the board'] };
    const W = a.width, H = a.height;
    const plan = [];
    for (let y = 0; y < H; y++) { let row = ''; for (let x = 0; x < W; x++) row += a.cells[y * W + x].ch; plan.push(row); }
    const puzzle = {
      width: W, height: H, plan,
      bots: a.bots.map((b) => ({ x: b.x, y: b.y, direction: b.direction, color: b.color })),
      goals: a.goals, treasures: a.treasures,
      actions: a.actions.map((x) => ({ x: x.x, y: x.y, type: x.type, color: x.color, value: x.value })),
      commands,
    };
    return { ok: true, puzzle };
  }

  /** Placed (non-fixed) actions currently on the board, for verification after each click. */
  function readPlacedActions(snap) {
    return analyzeSnapshot(snap).actions.filter((x) => x.placed).map((x) => ({ x: x.x, y: x.y, type: x.type, color: x.color, direction: isArrow(x.type) ? x.value : null }));
  }

  /* ------------------------------------------------------------------ */
  /* Pure simulator (port of the game's step logic)                      */
  /* ------------------------------------------------------------------ */

  function mkAction(a, fixed) {
    const v = a.value || 0;
    return { x: a.x, y: a.y, type: a.type, color: a.color == null ? null : a.color, value: v, direction: v, fixed, used: 0, visible: true, state: 0, activated: false };
  }

  function initState(puzzle, placements) {
    const W = puzzle.width, H = puzzle.height, plan = [];
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) plan.push(puzzle.plan[y][x]);
    const S = {
      W, H, plan, steps: 0,
      bots: puzzle.bots.map((b) => ({ x: b.x, y: b.y, direction: b.direction, color: b.color, finished: false, status: 'alive', teleportApplied: 0, nX: undefined, nY: undefined })),
      treasures: puzzle.treasures.map((t) => ({ x: t.x, y: t.y, collected: false, visible: true })),
      goals: puzzle.goals.map((g) => ({ x: g.x, y: g.y, color: g.color, completed: 0, visible: true })),
      actions: [],
    };
    puzzle.actions.forEach((a) => S.actions.push(mkAction(a, true)));
    (placements || []).forEach((p) => S.actions.push(mkAction({ x: p.x, y: p.y, type: p.type, color: p.color, value: p.direction == null ? 0 : p.direction }, false)));
    return S;
  }

  function cloneState(S) {
    return {
      W: S.W, H: S.H, plan: S.plan.slice(), steps: S.steps,
      bots: S.bots.map((b) => Object.assign({}, b)),
      treasures: S.treasures.map((t) => Object.assign({}, t)),
      goals: S.goals.map((g) => Object.assign({}, g)),
      actions: S.actions.map((a) => Object.assign({}, a)),
      decided: S.decided ? new Set(S.decided) : undefined,
      remaining: S.remaining ? S.remaining.slice() : undefined,
      placed: S.placed ? S.placed.slice() : undefined,
    };
  }

  function prepareMoveBot(S, bot, steps) {
    if (bot.status === 'dead' || bot.finished) return;
    const W = S.W, H = S.H;
    const d = DIRS[bot.direction] || [0, 0];
    const nX = bot.x + d[0] * steps, nY = bot.y + d[1] * steps;
    const oneX = bot.x + d[0], oneY = bot.y + d[1];
    if (nX >= 0 && nY >= 0 && nX < W && nY < H) {
      if (steps === 2 && S.plan[oneY * W + oneX] === '#') { bot.nX = bot.x; bot.nY = bot.y; bot.status = 'dead'; return; }
      const ch = S.plan[nY * W + nX];
      if (ch === '#' || ch === '@' || ch === '&') { bot.nX = bot.x; bot.nY = bot.y; bot.status = 'dead'; return; }
      if (ch === '*' || ch === '+') { bot.nX = nX; bot.nY = nY; }
    } else {
      bot.nX = bot.x; bot.nY = bot.y; bot.status = 'dead';
    }
  }

  function collideBot(S, i) {
    const cur = S.bots[i];
    if (cur.status === 'dead' || cur.finished) return;
    const goal = S.goals.find((g) => g.x === cur.nX && g.y === cur.nY && g.visible);
    if (goal && goal.color !== cur.color) { cur.status = 'dead'; cur.nX = cur.x; cur.nY = cur.y; return; }
    for (let j = 0; j < S.bots.length; j++) {
      const o = S.bots[j];
      if (cur.color !== 'black' && i !== j && cur.nX === o.nX && cur.nY === o.nY) {
        if (goal) { cur.nX = cur.x; cur.nY = cur.y; } // waits in front of a shared door
        else { cur.status = 'dead'; return; }
      }
      if (cur.color !== 'black' && i !== j && cur.nX === o.x && cur.nY === o.y && cur.x === o.nX && cur.y === o.nY) {
        cur.status = 'dead'; return; // swap
      }
    }
  }

  function moveBotFinal(S, i) {
    const bot = S.bots[i];
    if (bot.status === 'dead' || bot.finished) return;
    const nX = bot.nX, nY = bot.nY;
    S.treasures.forEach((t) => { if (t.y === nY && t.x === nX && !t.collected && t.visible) t.collected = true; });
    S.goals.forEach((g) => {
      if (g.y === nY && g.x === nX && g.color === bot.color && g.visible) {
        bot.x = -1; bot.y = -1; bot.nX = -1; bot.nY = -1; bot.finished = true; g.completed++;
      }
    });
    bot.x = bot.nX; bot.y = bot.nY;
  }

  function moveBots(S) {
    const acts = S.actions;
    for (let i = 0; i < S.bots.length; i++) {
      const bot = S.bots[i];
      if (bot.status === 'dead' || bot.finished) continue;
      let steps = 1;
      for (let j = 0; j < acts.length; j++) {
        const a = acts[j];
        if (!(bot.y === a.y && bot.x === a.x && a.visible)) continue;
        if (a.color === bot.color) {
          if (a.type === 'arrow') { if (a.value >= 0 && a.value <= 3) bot.direction = a.value; }
          if (a.type === 'arrow1' && a.used === 0) { if (a.value >= 0 && a.value <= 3) bot.direction = a.value; a.used = 1; }
          if (a.type === 'arrowR+') { bot.direction = a.direction; a.direction = (a.direction + 3) % 4; }
          if (a.type === 'arrowR-') { bot.direction = a.direction; a.direction = (a.direction + 1) % 4; }
          if (a.type === 'jump') steps = 2;
        } else if (a.type === 'arrow1' && a.used === 0) a.used = 1;
        if (a.type === 'gate' && bot.color !== a.color) bot.color = a.color;
        if (a.type === 'bomb' && a.state === 0) { a.activated = true; a.state++; }
        if (a.type === 'teleport' && bot.teleportApplied === 0) {
          const other = acts.find((o, idx) => o.type === 'teleport' && idx !== j && o.visible);
          if (other) { bot.x = other.x; bot.y = other.y; bot.teleportApplied = 2; steps = 0; }
          else bot.status = 'dead';
        }
      }
      prepareMoveBot(S, bot, steps);
      if (bot.teleportApplied > 0) bot.teleportApplied--;
    }
    for (let i = 0; i < S.bots.length; i++) collideBot(S, i);
    S.bots.forEach((b) => { if (b.status === 'dead') { b.nX = b.x; b.nY = b.y; } });
    for (let i = 0; i < S.bots.length; i++) moveBotFinal(S, i);
  }

  function removeRocks(S) {
    S.bots.forEach((bot) => S.actions.forEach((a) => {
      if (a.type === 'wand' && a.visible && a.x === bot.x && a.y === bot.y) {
        for (let k = 0; k < S.plan.length; k++) if (S.plan[k] === '&') S.plan[k] = '*';
      }
    }));
  }

  const BLAST = [[1, 0], [0, 1], [-1, 0], [0, -1], [0, 0]];
  function explode(S) {
    S.actions.forEach((a) => {
      if (!(a.type === 'bomb' && a.activated && a.state === 4)) return;
      a.visible = false; a.activated = false;
      BLAST.forEach((d) => {
        const nX = a.x + d[0], nY = a.y + d[1];
        if (!(nX >= 0 && nY >= 0 && nX < S.W && nY < S.H)) return;
        S.actions.forEach((o) => { if (o.x === nX && o.y === nY) o.visible = false; });
        S.goals.forEach((g) => { if (g.x === nX && g.y === nY) g.visible = false; });
        S.treasures.forEach((t) => { if (t.x === nX && t.y === nY && !t.collected) t.visible = false; });
        S.bots.forEach((b) => { if (b.x === nX && b.y === nY && !b.finished) b.status = 'dead'; });
        const k = nY * S.W + nX;
        if (S.plan[k] === '#' || S.plan[k] === '@' || S.plan[k] === '&') S.plan[k] = '*';
      });
    });
  }

  /** redrawPlan() advances every visible, activated bomb's countdown once per step (state<4). */
  function bombTick(S) {
    S.actions.forEach((a) => { if (a.type === 'bomb' && a.visible && a.state < 4 && a.activated) a.state++; });
  }

  const isWon = (S) => S.bots.every((b) => b.finished || b.color === 'black') && S.treasures.every((t) => t.collected);

  /** One game tick (what the game runs every `botsSpeed` ms). Returns true when the page would show success. */
  function stepState(S) {
    S.steps++;
    moveBots(S);
    removeRocks(S);
    explode(S);
    const won = isWon(S);
    bombTick(S);
    return won;
  }

  /** Reasons why the current state can never reach the win condition (all derived from monotone game rules). */
  function deadEnd(S, hasGates) {
    if (S.bots.some((b) => b.status === 'dead' && b.color !== 'black')) return 'a bot died';
    if (S.treasures.some((t) => !t.collected && !t.visible)) return 'a treasure was destroyed';
    const open = S.bots.filter((b) => !b.finished && b.color !== 'black');
    if (!hasGates && open.some((b) => !S.goals.some((g) => g.visible && g.color === b.color))) return 'no door left for a bot';
    if (!open.length && S.treasures.some((t) => !t.collected) && !S.bots.some((b) => b.color === 'black' && b.status === 'alive')) return 'treasures cannot be collected any more';
    return null;
  }

  function stateKey(S, withPlan) {
    let k = '';
    S.bots.forEach((b) => { k += b.x + ',' + b.y + ',' + b.direction + ',' + b.color + ',' + (b.finished ? 1 : 0) + (b.status === 'dead' ? 'd' : 'a') + b.teleportApplied + (b.status === 'dead' ? ',' + b.nX + ',' + b.nY : '') + ';'; });
    k += '|';
    S.treasures.forEach((t) => { k += (t.collected ? 1 : 0) + (t.visible ? 1 : 0); });
    S.goals.forEach((g) => { k += g.visible ? 1 : 0; });
    k += '|';
    S.actions.forEach((a) => { k += a.x + ',' + a.y + a.type + (a.color || '') + a.value + a.direction + a.used + (a.visible ? 1 : 0) + a.state + (a.activated ? 1 : 0) + ';'; });
    if (withPlan) k += '|' + S.plan.join('');
    if (S.decided) k += '|' + Array.from(S.decided).sort((x, y) => x - y).join(',');
    return k;
  }

  /**
   * Run a complete plan on a fresh board.
   * @returns {{won:boolean, steps:number, outcome:string, trace?:object[]}}
   */
  function simulate(puzzle, placements, opts) {
    const o = Object.assign({ maxSteps: 300, trace: false }, opts);
    const S = initState(puzzle, placements);
    const hasGates = puzzle.actions.some((a) => a.type === 'gate') || (placements || []).some((p) => p.type === 'gate');
    const withPlan = puzzle.actions.some((a) => a.type === 'bomb' || a.type === 'wand') || (placements || []).some((p) => p.type === 'bomb');
    const seen = new Set();
    const trace = [];
    for (let n = 0; n < o.maxSteps; n++) {
      const won = stepState(S);
      if (o.trace) trace.push(snapshotState(S));
      if (won) return { won: true, steps: S.steps, outcome: 'won', trace };
      const dead = deadEnd(S, hasGates);
      if (dead) return { won: false, steps: S.steps, outcome: 'dead-end: ' + dead, trace };
      const key = stateKey(S, withPlan);
      if (seen.has(key)) return { won: false, steps: S.steps, outcome: 'loop (state repeats, game never ends)', trace };
      seen.add(key);
    }
    return { won: false, steps: S.steps, outcome: 'step limit ' + o.maxSteps + ' reached', trace };
  }

  function snapshotState(S) {
    return JSON.parse(JSON.stringify({
      bots: S.bots.map((b) => [b.x, b.y, b.direction, b.color, b.finished, b.status]),
      treasures: S.treasures.map((t) => [t.collected, t.visible]),
      goals: S.goals.map((g) => [g.visible, g.completed]),
      actions: S.actions.map((a) => [a.used, a.visible, a.state, a.activated, a.direction]),
      plan: S.plan.join(''),
    }));
  }

  /* ------------------------------------------------------------------ */
  /* Placement legality + plan verification                              */
  /* ------------------------------------------------------------------ */

  function buildContext(puzzle) {
    const W = puzzle.width, H = puzzle.height;
    const occupied = new Uint8Array(W * H);
    const mark = (o) => { occupied[o.y * W + o.x] = 1; };
    puzzle.bots.forEach(mark); puzzle.goals.forEach(mark); puzzle.treasures.forEach(mark); puzzle.actions.forEach(mark);
    const placeable = new Uint8Array(W * H);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) placeable[y * W + x] = puzzle.plan[y][x] === '*' && !occupied[y * W + x] ? 1 : 0;
    const pools = [], byKey = {};
    puzzle.commands.forEach((c) => {
      if (c.remaining <= 0) return;
      const key = c.type + '|' + (c.color || '');
      if (!byKey[key]) { byKey[key] = { key, type: c.type, color: c.color, count: 0 }; pools.push(byKey[key]); }
      byKey[key].count += c.remaining;
    });
    const has = (t) => puzzle.actions.some((a) => a.type === t) || pools.some((p) => p.type === t);
    const gateColors = new Set();
    puzzle.actions.forEach((a) => { if (a.type === 'gate') gateColors.add(a.color); });
    pools.forEach((p) => { if (p.type === 'gate') gateColors.add(p.color); });
    return { puzzle, W, H, placeable, pools, byKey, gateColors, has, planMutable: has('bomb') || has('wand') };
  }

  /** Legality of a plan against the game's click rules + command budget. Returns a list of problems. */
  function checkPlacements(puzzle, placements) {
    const ctx = buildContext(puzzle), errs = [], used = {}, cells = new Set();
    placements.forEach((p, i) => {
      const where = 'placement ' + i + ' (' + p.type + ' at ' + p.x + ',' + p.y + ')';
      if (!(p.x >= 0 && p.y >= 0 && p.x < ctx.W && p.y < ctx.H)) { errs.push(where + ': outside the board'); return; }
      const idx = p.y * ctx.W + p.x;
      if (!ctx.placeable[idx]) errs.push(where + ': cell is not a free "*" cell');
      if (cells.has(idx)) errs.push(where + ': cell used twice');
      cells.add(idx);
      const key = p.type + '|' + (p.color || '');
      if (!ctx.byKey[key]) errs.push(where + ': no such command');
      else { used[key] = (used[key] || 0) + 1; if (used[key] > ctx.byKey[key].count) errs.push(where + ': command budget exceeded'); }
      if (isArrow(p.type) && !(p.direction >= 0 && p.direction <= 3)) errs.push(where + ': invalid direction');
    });
    return errs;
  }

  /** Legality + full simulation of the real win condition. */
  function verifyPlan(puzzle, placements, opts) {
    const errs = checkPlacements(puzzle, placements);
    if (errs.length) return { ok: false, reason: errs.join('; '), steps: 0 };
    const r = simulate(puzzle, placements, opts);
    return { ok: r.won, reason: r.won ? 'won' : r.outcome, steps: r.steps };
  }

  /* ------------------------------------------------------------------ */
  /* Support check                                                       */
  /* ------------------------------------------------------------------ */

  function findUnsupported(puzzle) {
    const r = [];
    if (!puzzle.bots.length) r.push('no bots');
    puzzle.actions.forEach((a) => {
      if (FIXED_TYPES.indexOf(a.type) === -1) r.push('unknown fixed action "' + a.type + '"');
      if (isArrow(a.type) && !(a.value >= 0 && a.value <= 3)) r.push('arrow with unreadable direction');
    });
    if (puzzle.actions.filter((a) => a.type === 'teleport').length > 2) r.push('more than two fixed teleports (partner choice depends on hidden JSON order)');
    puzzle.commands.forEach((c) => { if (COMMAND_TYPES.indexOf(c.type) === -1) r.push('unknown command "' + c.type + '"'); });
    puzzle.plan.forEach((row, y) => { if (row.length !== puzzle.width) r.push('ragged plan row ' + y); if (/[^#*+@&]/.test(row)) r.push('unknown tile in plan row ' + y); });
    return r;
  }

  /* ------------------------------------------------------------------ */
  /* Turn-count lower bound (admissible relaxation, single bot)          */
  /* ------------------------------------------------------------------ */

  function heuristicEligible(ctx) {
    return !ctx.has('gate') && !ctx.has('teleport') && !ctx.has('bomb') && !ctx.pools.some((p) => p.type === 'jump');
  }

  /** dist[(cell*4+dir)] = minimum number of NEW arrows the bot of `color` still needs, ignoring other bots. */
  function buildDist(ctx, color) {
    const { W, H, puzzle } = ctx, N = W * H;
    const wand = puzzle.actions.some((a) => a.type === 'wand');
    const blocked = new Uint8Array(N), own = new Uint8Array(N), foreign = new Uint8Array(N);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const c = puzzle.plan[y][x]; blocked[y * W + x] = c === '#' || c === '@' || (c === '&' && !wand) ? 1 : 0; }
    puzzle.goals.forEach((g) => { if (g.color === color) own[g.y * W + g.x] = 1; else foreign[g.y * W + g.x] = 1; });
    const fixedAt = {};
    puzzle.actions.forEach((a) => { fixedAt[a.y * W + a.x] = a; });
    const edges = new Array(N * 4); // per node: list of [steps, d2, cost]
    for (let c = 0; c < N; c++) for (let d = 0; d < 4; d++) {
      const f = fixedAt[c], list = [];
      if (f) {
        const match = f.color === color;
        if (f.type === 'arrow' && match) list.push([1, f.value, 0]);
        else if (f.type === 'arrow1' && match) { list.push([1, f.value, 0]); list.push([1, d, 0]); }
        else if ((f.type === 'arrowR+' || f.type === 'arrowR-') && match) for (let d2 = 0; d2 < 4; d2++) list.push([1, d2, 0]);
        else if (f.type === 'jump' && match) { list.push([1, d, 0]); list.push([2, d, 0]); }
        else list.push([1, d, 0]);
      } else if (ctx.placeable[c]) {
        list.push([1, d, 0]);
        for (let d2 = 0; d2 < 4; d2++) if (d2 !== d) list.push([1, d2, 1]);
      } else list.push([1, d, 0]);
      edges[c * 4 + d] = list;
    }
    const dist = new Array(N * 4).fill(Infinity);
    for (let changed = true; changed;) {
      changed = false;
      for (let c = 0; c < N; c++) {
        if (blocked[c]) continue;
        const cx = c % W, cy = Math.floor(c / W);
        for (let d = 0; d < 4; d++) {
          const u = c * 4 + d;
          if (own[c]) { if (dist[u] !== 0) { dist[u] = 0; changed = true; } continue; }
          let best = dist[u];
          for (const e of edges[u]) {
            const nx = cx + DIRS[e[1]][0] * e[0], ny = cy + DIRS[e[1]][1] * e[0];
            if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
            const n = ny * W + nx;
            if (blocked[n] || foreign[n]) continue;
            const v = e[2] + (own[n] ? 0 : dist[n * 4 + e[1]]);
            if (v < best) best = v;
          }
          if (best < dist[u]) { dist[u] = best; changed = true; }
        }
      }
    }
    const next = (c, d2) => {
      const nx = (c % W) + DIRS[d2][0], ny = Math.floor(c / W) + DIRS[d2][1];
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) return Infinity;
      const n = ny * W + nx;
      if (blocked[n] || foreign[n]) return Infinity;
      return own[n] ? 0 : dist[n * 4 + d2];
    };
    return { dist, next };
  }

  /* ------------------------------------------------------------------ */
  /* Search                                                              */
  /* ------------------------------------------------------------------ */

  class LimitError extends Error {}

  /**
   * Lazy-decision DFS. The simulation is run forward; the first time an alive bot stands on a free,
   * placeable, still-undecided cell, we branch over {leave empty} ∪ {each affordable command (+direction)}.
   * A placed action can only influence the game after a bot stands on its cell (teleports are the one global
   * exception and are enumerated up-front), so deciding lazily at the first visit is exact.
   */
  function solve(puzzle, options) {
    const t0 = Date.now();
    const o = Object.assign({ maxSteps: 150, maxWork: 400000, maxMs: 8000, minimise: true }, options);
    const unsupported = findUnsupported(puzzle);
    if (unsupported.length) return { status: 'unsupported', reasons: unsupported };
    const ctx = buildContext(puzzle);
    const useH = heuristicEligible(ctx);
    const heur = {};
    const hFor = (color) => heur[color] || (heur[color] = buildDist(ctx, color));
    const hasGates = ctx.has('gate');
    const seen = new Set();
    let work = 0, truncated = false;
    const poolIdx = (p) => ctx.pools.indexOf(p);
    const arrowPool = (S, color) => { let n = 0; ctx.pools.forEach((p, i) => { if (isArrow(p.type) && p.color === color) n += S.remaining[i]; }); return n; };

    const tick = () => {
      if (++work > o.maxWork) throw new LimitError('search work limit (' + o.maxWork + ') reached');
      if ((work & 255) === 0 && Date.now() - t0 > o.maxMs) throw new LimitError('search time limit (' + o.maxMs + ' ms) reached');
    };

    // Arrows still needed by a bot. On a cell whose decision is already made, the turn (if any) has been paid for,
    // so the optional "turn here" edge of the relaxation must not be charged again.
    const botNeed = (S, b) => {
      const idx = b.y * S.W + b.x, h = hFor(b.color);
      if (!ctx.placeable[idx] || !S.decided.has(idx)) return h.dist[idx * 4 + b.direction];
      let d = b.direction;
      const a = S.actions.find((x) => x.x === b.x && x.y === b.y && x.visible);
      if (a && a.color === b.color) {
        if (a.type === 'arrow' || (a.type === 'arrow1' && a.used === 0)) d = a.value;
        else if (a.type === 'arrowR+' || a.type === 'arrowR-') d = a.direction;
      }
      return h.next(idx, d);
    };

    const feasible = (S) => {
      if (deadEnd(S, hasGates)) return false;
      if (!useH) return true;
      for (const b of S.bots) {
        if (b.finished || b.status === 'dead' || b.color === 'black') continue;
        if (b.x < 0 || b.x >= S.W || b.y < 0 || b.y >= S.H) continue;
        if (botNeed(S, b) > arrowPool(S, b.color)) return false;
      }
      return true;
    };

    const anyCommandLeft = (S) => S.remaining.some((n, i) => n > 0 && ctx.pools[i].type !== 'teleport');

    const findDecision = (S) => {
      if (!anyCommandLeft(S)) return null;
      for (let i = 0; i < S.bots.length; i++) {
        const b = S.bots[i];
        if (b.finished || b.status === 'dead') continue;
        const idx = b.y * S.W + b.x;
        if (ctx.placeable[idx] && !S.decided.has(idx)) return { bot: i, idx };
      }
      return null;
    };

    const colorMattersLater = (S, color, bot) => ctx.gateColors.has(color) || S.bots.some((b) => b !== bot && !b.finished && b.status !== 'dead' && b.color === color);

    const makeOptions = (S, dec) => {
      const bot = S.bots[dec.bot], list = [{ empty: true, score: 0 }];
      const cx = bot.x, cy = bot.y, c = dec.idx;
      const baseNeed = useH && bot.color !== 'black' ? hFor(bot.color).next(c, bot.direction) : 0;
      ctx.pools.forEach((p, pi) => {
        if (S.remaining[pi] <= 0 || p.type === 'teleport') return;
        const matches = p.color === bot.color;
        if (isArrow(p.type)) {
          if (!matches && !colorMattersLater(S, p.color, bot)) return;
          for (let d = 0; d < 4; d++) list.push({ pi, direction: d, matches });
        } else if (p.type === 'jump') {
          if (!matches && !colorMattersLater(S, p.color, bot)) return;
          list.push({ pi, direction: null, matches });
        } else if (p.type === 'gate') {
          if (p.color === bot.color && !S.bots.some((b) => b !== bot && !b.finished && b.status !== 'dead' && b.color !== p.color)) return;
          list.push({ pi, direction: null, matches: false });
        } else if (p.type === 'bomb') list.push({ pi, direction: null, matches: false });
      });
      // Score + prune with the turn bound (only when the relaxation is valid for this puzzle).
      const kept = [];
      list.forEach((opt) => {
        let need = 0;
        if (useH && bot.color !== 'black') {
          const h = hFor(bot.color);
          if (opt.empty || !(opt.matches && isArrow(ctx.pools[opt.pi].type))) need = baseNeed + 0;
          else need = h.next(c, opt.direction);
          const pool = arrowPool(S, bot.color) - (!opt.empty && isArrow(ctx.pools[opt.pi].type) && ctx.pools[opt.pi].color === bot.color ? 1 : 0);
          if (need > pool) return;
        }
        opt.score = need + (opt.empty ? 0 : 0.5);
        kept.push(opt);
      });
      if (useH) kept.sort((a, b) => a.score - b.score);
      return kept;
    };

    const apply = (S, dec, opt) => {
      const T = cloneState(S);
      T.decided.add(dec.idx);
      if (opt.empty) return T;
      const p = ctx.pools[opt.pi], b = S.bots[dec.bot];
      const pl = { x: b.x, y: b.y, type: p.type, color: p.color, direction: opt.direction };
      T.remaining[opt.pi]--;
      T.placed.push(pl);
      T.actions.push(mkAction({ x: pl.x, y: pl.y, type: pl.type, color: pl.color, value: pl.direction == null ? 0 : pl.direction }, false));
      return T;
    };

    const dfs = (S0) => {
      let S = S0;
      const segment = new Set();
      for (;;) {
        if (!feasible(S)) return null;
        const dec = findDecision(S);
        if (dec) {
          const key = stateKey(S, ctx.planMutable);
          if (seen.has(key)) return null;
          seen.add(key);
          tick();
          for (const opt of makeOptions(S, dec)) {
            const r = dfs(apply(S, dec, opt));
            if (r) return r;
          }
          return null;
        }
        tick();
        if (stepState(S)) return S;
        if (deadEnd(S, hasGates)) return null;
        if (S.steps >= o.maxSteps) { truncated = true; return null; }
        const k = stateKey(S, ctx.planMutable);
        if (segment.has(k)) return null; // no new decision possible and state repeats => endless loop
        segment.add(k);
      }
    };

    // Teleports are global (a bot needs a partner on the board), so they are enumerated eagerly.
    const fixedTp = puzzle.actions.filter((a) => a.type === 'teleport').length;
    const tpPool = ctx.pools.find((p) => p.type === 'teleport');
    const tpVariants = [[]];
    const freeCells = [];
    for (let i = 0; i < ctx.placeable.length; i++) if (ctx.placeable[i]) freeCells.push(i);
    if (tpPool && fixedTp === 1 && tpPool.count >= 1) freeCells.forEach((c) => tpVariants.push([c]));
    if (tpPool && fixedTp === 0 && tpPool.count >= 2) for (let a = 0; a < freeCells.length; a++) for (let b = a + 1; b < freeCells.length; b++) tpVariants.push([freeCells[a], freeCells[b]]);

    let found = null, limitReason = null;
    try {
      for (const variant of tpVariants) {
        const S = initState(puzzle, []);
        S.decided = new Set(); S.remaining = ctx.pools.map((p) => p.count); S.placed = [];
        variant.forEach((c) => {
          const pl = { x: c % ctx.W, y: Math.floor(c / ctx.W), type: 'teleport', color: null, direction: null };
          S.decided.add(c); S.placed.push(pl); S.remaining[poolIdx(tpPool)]--;
          S.actions.push(mkAction({ x: pl.x, y: pl.y, type: 'teleport', color: null, value: 0 }, false));
        });
        found = dfs(S);
        if (found) break;
      }
    } catch (e) {
      if (e instanceof LimitError) limitReason = e.message; else throw e;
    }
    const stats = { work, states: seen.size, ms: Date.now() - t0 };
    if (!found) {
      if (limitReason) return { status: 'limit', reason: limitReason, stats };
      if (truncated) return { status: 'limit', reason: 'some branches were cut at the ' + o.maxSteps + '-step simulation limit', stats };
      return { status: 'no-solution', reason: 'search space exhausted: no placement of the available commands wins', stats };
    }
    let placements = found.placed.slice();
    if (o.minimise) {
      for (let i = placements.length - 1; i >= 0; i--) {
        const cand = placements.slice(0, i).concat(placements.slice(i + 1));
        if (verifyPlan(puzzle, cand, { maxSteps: o.maxSteps }).ok) placements = cand;
      }
    }
    const v = verifyPlan(puzzle, placements, { maxSteps: o.maxSteps });
    if (!v.ok) return { status: 'internal-error', reason: 'search result failed independent verification: ' + v.reason, stats };
    return { status: 'solved', plan: { placements, steps: v.steps }, stats };
  }

  return {
    DIRS, DIR_LETTERS, ARROW_TYPES, COMMAND_TYPES, isArrow,
    readSnapshot, analyzeSnapshot, parseSnapshot, readPlacedActions, isVisible,
    initState, stepState, simulate, checkPlacements, verifyPlan, findUnsupported, solve,
  };
});