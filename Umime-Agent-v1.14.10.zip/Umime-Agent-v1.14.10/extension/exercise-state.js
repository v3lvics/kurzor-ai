(function(root,factory){
  if(typeof module==='object' && module.exports) module.exports=factory();
  else root.UmimeExerciseState=factory();
})(typeof self!=='undefined'?self:this,function(){
  'use strict';
  function identity(question, candidates, images=[]) {
    const useful=candidates.filter(c=>c.answerOption || ['input','textarea','select'].includes(c.tag) || c.editable || c.sipkovanaCell);
    return JSON.stringify({question, images, targets:useful.map(c=>({
      tag:c.tag, domId:c.domId, text:c.answerText || c.text || '',
      expressions:c.expressions, inputType:c.inputType,
      options:c.options?.map(o=>typeof o==='string'?o:{value:o.value,text:o.text}),
      cell:c.sipkovanaCell
    }))});
  }
  function questionChanged(before, after) {
    if (!before || !after) return false;
    const oldWidget=before.widgetState, newWidget=after.widgetState;
    if (oldWidget && newWidget) {
      if (oldWidget.activeGap && newWidget.activeGap && oldWidget.activeGap!==newWidget.activeGap) return true;
      if (oldWidget.gaps?.length && newWidget.gaps?.filter(g=>g.answered).length > oldWidget.gaps.filter(g=>g.answered).length) return true;
      if (oldWidget.cards?.length && newWidget.cards?.length && JSON.stringify(oldWidget.cards)!==JSON.stringify(newWidget.cards)) return true;
    }
    const a=before.questionText || '', b=after.questionText || '';
    if (a && b && a!==b) return true;
    const choices=s=>s.candidates.filter(c=>c.answerOption).map(c=>c.answerText||c.text||'');
    const oldChoices=choices(before), newChoices=choices(after);
    if (a===b && oldChoices.length && newChoices.length && JSON.stringify(oldChoices)!==JSON.stringify(newChoices)) return true;
    return !a && !b && after.candidates.length>0 && before.textFp!==after.textFp;
  }
  function transition({finished=false,pending=false,changed=false,next=false,evaluate=false,evaluated=false,elapsed=0}) {
    if(finished) return 'complete';
    if(!pending) return 'solve';
    if(changed) return 'advanced';
    if(next) return 'advance';
    if(evaluate && !evaluated) return 'evaluate';
    return elapsed>=12000?'stalled':'wait';
  }
  function canSubmitEmpty(task, result) {
    return task === 'text_marking' && result?.noSelectionNeeded === true
      && result.needsMoreContext === false && Number.isFinite(result.confidence)
      && result.confidence >= 0.9 && Array.isArray(result.actions) && result.actions.length === 0;
  }
  function waitFailure(kind, elapsed) {
    if (kind === 'controls' && elapsed >= 15000) return 'No answer controls found. Open an exercise and close any dialog. If it is already open, this layout may not be supported yet. Alt+click to retry.';
    if (kind === 'progress' && elapsed >= 45000) return 'No progress for 45 seconds. I cannot continue on this screen. Close any dialog or refresh the exercise, then Alt+click to retry.';
    return '';
  }
  function confirm(state) {
    if(state.counted) return false;
    state.counted=true;state.solved++;return true;
  }
  return {identity,transition,confirm,questionChanged,canSubmitEmpty,waitFailure};
});
