// Runs at document_start in the page, before the exercise scripts.
// Records what the exercises reveal about the current item, for exercises whose state is
// hidden inside a closure (Šipkovaná, Rozhodovačka, Psaná odpověď, Přesouvání, Pexeso...).
// content.js reads it from window.__neumimetoData.
(function () {
  const store = (window.__neumimetoData = window.__neumimetoData || {});
  store.items = store.items || null;     // downloaded items (merged by id)
  store.currentId = store.currentId || null;
  store.shownItem = null;                // item passed to displayItem() (binary choice)
  store.inputAnswers = null;             // { id, answers: [[...accepted], ...] } of the last rendered question
  store.shuffles = [];                   // { id, arr } arrays shuffled by the page, newest last
  store.listeners = store.listeners || []; // f(event, data) – content.js subscribes

  const emit = (event, data) => store.listeners.forEach(f => { try { f(event, data); } catch (e) {} });

  // ---------------------------------------------------------------- downloaded data
  // Same format as fjWEDGjivdsXloadQuestionData(): plain JSON, or atbash(a-z) + base64(UTF-8).
  function decode(text) {
    if (/^\s*{/.test(text)) return JSON.parse(text);
    const b64 = text.replace(/[a-z]/g, c => String.fromCharCode(219 - c.charCodeAt(0)));
    const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
    return JSON.parse(new TextDecoder().decode(bytes));
  }

  const origFetch = window.fetch;
  window.fetch = function (input) {
    const promise = origFetch.apply(this, arguments);
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      // universalLoadItems.php, vpisovackaLoadWrittenAnswerData.php, pexesoLoadSetsDynamic.php,
      // loadStrilecka.php, loadRobots.php, ...
      if (/[Ll]oad[A-Za-z]*\.php/.test(url)) {
        promise
          .then(res => res.clone().text())
          .then(text => {
            const data = decode(text);
            // Raw responses too (newest last), for data whose items have no id.
            store.loads = store.loads || [];
            store.loads.push({ url, data });
            if (store.loads.length > 10) store.loads.shift();
            const list = data && (Array.isArray(data.items) ? data.items : Array.isArray(data.sets) ? data.sets : null);
            if (!list) return;
            // Keep earlier batches too: questions are fetched in rounds.
            const byId = new Map((store.items || []).map(it => [String(it.id), it]));
            list.forEach(it => byId.set(String(it.id), it));
            store.items = [...byId.values()];
          })
          .catch(() => {});
      }
    } catch (e) {}
    return promise;
  };

  // ---------------------------------------------------------------- page helpers
  // Global helper functions the exercises call by name from their closures. Each is wrapped
  // as soon as the script defining it has run, i.e. before any exercise starts.
  const taps = {
    updateItemUrl: orig => function (itemId) {
      store.currentId = itemId;
      store.shownItem = null;
      const result = orig.apply(this, arguments);
      emit('item', itemId);
      return result;
    },
    // Binary choice: shuffles item.options in place, then draws options[0] / options[1].
    displayItem: orig => function (item, parent) {
      const result = orig.apply(this, arguments);
      if (parent && parent.id === 'question-wrapper') store.shownItem = item;
      return result;
    },
    shuffle: orig => function (arr) {
      const result = orig.apply(this, arguments);
      if (Array.isArray(arr)) {
        store.shuffles.push({ id: store.currentId, arr });
        if (store.shuffles.length > 30) store.shuffles.shift();
      }
      return result;
    },
    // Written answers: the question is rendered with an 'input' handler that receives
    // ['input', { answer, ... }] for every answer box, in order.
    renderContentFormat: orig => function (content, handlers, ...rest) {
      if (handlers && typeof handlers.input === 'function' && !handlers.input.__neumimeto) {
        const answers = [];
        store.inputAnswers = { id: store.currentId, answers };
        const inner = handlers.input;
        const input = function (part) {
          try { answers.push([].concat(part[1].answer)); } catch (e) { answers.push([]); }
          return inner.apply(this, arguments);
        };
        input.__neumimeto = true;
        handlers = Object.assign({}, handlers, { input });
      }
      return orig.call(this, content, handlers, ...rest);
    },
  };

  const tapped = new Set();
  function tap() {
    for (const name in taps) {
      if (tapped.has(name) || typeof window[name] !== 'function') continue;
      window[name] = taps[name](window[name]);
      tapped.add(name);
    }
  }
  // 'load' of external scripts reaches document in the capture phase.
  document.addEventListener('load', e => { if (e.target && e.target.tagName === 'SCRIPT') tap(); }, true);
  document.addEventListener('DOMContentLoaded', tap);
  tap(); // nothing is defined yet at document_start; matters only if this runs on a loaded page
})();
