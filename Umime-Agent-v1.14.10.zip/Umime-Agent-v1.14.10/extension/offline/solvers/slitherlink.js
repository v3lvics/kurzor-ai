// Slitherlink solver: constraint propagation + DFS.
// grid: array of rows, each cell a number 0-3 or -1 (empty).
// Returns { h: [[0/1]] (R+1 x C), v: [[0/1]] (R x C+1) } or null.
window.solveSlitherlink = function (grid) {
  const R = grid.length, C = grid[0].length;
  const W = C + 1;
  const HN = (R + 1) * C, E = HN + R * W, VC = (R + 1) * W;

  const ends = [];
  for (let r = 0; r <= R; r++) for (let c = 0; c < C; c++) ends.push([r * W + c, r * W + c + 1]);
  for (let r = 0; r < R; r++) for (let c = 0; c <= C; c++) ends.push([r * W + c, (r + 1) * W + c]);

  const vEdges = Array.from({ length: VC }, () => []);
  ends.forEach(([u, v], e) => { vEdges[u].push(e); vEdges[v].push(e); });

  const cells = [];
  const edgeCells = Array.from({ length: E }, () => []);
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
    if (grid[r][c] < 0) continue;
    const edges = [r * C + c, (r + 1) * C + c, HN + r * W + c, HN + r * W + c + 1];
    edges.forEach(e => edgeCells[e].push(cells.length));
    cells.push({ n: grid[r][c], edges });
  }

  const st = new Int8Array(E).fill(-1);
  const trail = [];
  let onCount = 0;
  const FOUND = {};

  function finish() {
    for (const cell of cells) {
      let on = 0;
      for (const e of cell.edges) if (st[e] === 1) on++;
      if (on !== cell.n) return false;
    }
    throw FOUND;
  }

  // Called after edge e turned on: detect closed loops.
  function loopCheck(e) {
    const [u, v] = ends[e];
    let prev = e, cur = v, len = 1;
    for (let guard = 0; guard < E; guard++) {
      let next = -1;
      for (const f of vEdges[cur]) if (f !== prev && st[f] === 1) { next = f; break; }
      if (next < 0) return true;
      len++;
      cur = ends[next][0] === cur ? ends[next][1] : ends[next][0];
      prev = next;
      if (cur === u) return len === onCount ? finish() : false;
    }
    return true;
  }

  function set(e, val, q) {
    if (st[e] !== -1) return st[e] === val;
    st[e] = val;
    trail.push(e);
    q.push(e);
    if (val === 1) { onCount++; return loopCheck(e); }
    return true;
  }

  function checkVertex(v, q) {
    let on = 0, unk = 0;
    for (const e of vEdges[v]) { if (st[e] === 1) on++; else if (st[e] === -1) unk++; }
    if (on > 2 || (on === 1 && unk === 0)) return false;
    if (unk === 0) return true;
    let val = -1;
    if (on === 2) val = 0;
    else if (on === 1 && unk === 1) val = 1;
    else if (on === 0 && unk === 1) val = 0;
    if (val < 0) return true;
    for (const e of vEdges[v]) if (st[e] === -1 && !set(e, val, q)) return false;
    return true;
  }

  function checkCell(i, q) {
    const { n, edges } = cells[i];
    let on = 0, unk = 0;
    for (const e of edges) { if (st[e] === 1) on++; else if (st[e] === -1) unk++; }
    if (on > n || on + unk < n) return false;
    if (unk === 0) return true;
    const val = on === n ? 0 : on + unk === n ? 1 : -1;
    if (val < 0) return true;
    for (const e of edges) if (st[e] === -1 && !set(e, val, q)) return false;
    return true;
  }

  function propagate(q) {
    while (q.length) {
      const e = q.pop();
      if (!checkVertex(ends[e][0], q) || !checkVertex(ends[e][1], q)) return false;
      for (const i of edgeCells[e]) if (!checkCell(i, q)) return false;
    }
    return true;
  }

  function undo(to) {
    while (trail.length > to) {
      const e = trail.pop();
      if (st[e] === 1) onCount--;
      st[e] = -1;
    }
  }

  // Prefer extending a path end; otherwise any edge of the most constrained cell.
  function pick() {
    for (let v = 0; v < VC; v++) {
      let on = 0, cand = -1;
      for (const e of vEdges[v]) { if (st[e] === 1) on++; else if (st[e] === -1) cand = e; }
      if (on === 1 && cand >= 0) return cand;
    }
    for (const cell of cells) for (const e of cell.edges) if (st[e] === -1 && cell.n === 3) return e;
    for (let e = 0; e < E; e++) if (st[e] === -1) return e;
    return -1;
  }

  function dfs() {
    const e = pick();
    if (e < 0) return false;
    for (const val of [1, 0]) {
      const t = trail.length, q = [];
      if (set(e, val, q) && propagate(q) && dfs()) return true;
      undo(t);
    }
    return false;
  }

  function result() {
    const h = [], v = [];
    for (let r = 0; r <= R; r++) { h.push([]); for (let c = 0; c < C; c++) h[r].push(st[r * C + c] === 1 ? 1 : 0); }
    for (let r = 0; r < R; r++) { v.push([]); for (let c = 0; c <= C; c++) v[r].push(st[HN + r * W + c] === 1 ? 1 : 0); }
    return { h, v };
  }

  try {
    const q = [];
    for (let i = 0; i < cells.length; i++) if (!checkCell(i, q)) return null;
    for (let v = 0; v < VC; v++) if (!checkVertex(v, q)) return null;
    if (!propagate(q)) return null;
    dfs();
    return null;
  } catch (x) {
    if (x === FOUND) return result();
    throw x;
  }
};
