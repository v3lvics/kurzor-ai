// Šipkovaná solver. Simulates the bots exactly like moveBots() in the page's sipkovana.js and
// decides what to place on a free cell the first time a bot steps on it (DFS with backtracking).
// The simulation is a line-by-line port of the page code: it keeps the raw value types of the data
// (numbers or strings), gives placed actions string coordinates (the page reads them from the posX/posY
// DOM attributes) and uses the same ==, === and parseInt as the page, so its quirks are reproduced.
// puzzle: items[k].item.item = {plan, bots, commands, treasures, goals, actions}
// Returns [{x, y, cmd, value}] in click order, or null. For arrows, value - Number(command.value)
// is the number of extra clicks on the placed arrow (each one turns it by one).
window.solveSipkovana = function (puzzle, timeLimitMs = 8000) {
  const MAX_STEPS = 250; // the adapter steps the bots at most 300 times
  const isArrow = t => ['arrow', 'arrow1', 'arrowR-', 'arrowR+'].includes(t);
  const key = (x, y) => Number(x) + ',' + Number(y);
  const copy = o => JSON.parse(JSON.stringify(o));

  const plan0 = puzzle.plan.split('|').map(r => r.split(''));
  const H = plan0.length;
  const W = Math.max(...plan0.map(r => r.length));
  const commands = puzzle.commands;

  // getDirectionCoordinates(): a strict switch, so a string direction does not move the bot.
  function dirCoords(d) {
    switch (d) {
      case 0: return [1, 0];
      case 1: return [0, 1];
      case 2: return [-1, 0];
      case 3: return [0, -1];
      default: return [0, 0];
    }
  }

  // Cells the player may click (clickPlanCell): '*' without a bot, treasure, goal or fixed action.
  const taken = new Set();
  [puzzle.bots, puzzle.treasures, puzzle.goals, puzzle.actions].forEach(list =>
    (list || []).forEach(o => taken.add(key(o.x, o.y))));
  const placeable = (x, y) => {
    const nx = Number(x), ny = Number(y);
    return Number.isInteger(nx) && Number.isInteger(ny) && plan0[ny] && plan0[ny][nx] === '*' && !taken.has(key(nx, ny));
  };

  // State after prepareGame() + startBots() -> stopBots().
  const start = {
    plan: plan0.map(r => r.slice()),
    planVersion: 0,
    bots: copy(puzzle.bots).map(b => Object.assign(b, { finished: false, status: 'alive', teleportApplied: 0 })),
    actions: copy(puzzle.actions || []).map(a => {
      a.visible = true;
      a.fixed = true;
      if (a.type == 'arrow1') a.used = 0;
      if (a.type == 'bomb') { a.state = 0; a.activated = false; }
      if (a.type === 'arrowR+' || a.type === 'arrowR-') a.direction = a.value;
      return a;
    }),
    treasures: copy(puzzle.treasures || []).map(t => Object.assign(t, { collected: false, visible: true })),
    goals: copy(puzzle.goals || []).map(g => Object.assign(g, { completed: 0, visible: true })),
    remaining: commands.map(c => Number(c.count)),
    decided: new Set(),
    placements: [],
  };

  const clone = s => ({
    plan: s.plan.map(r => r.slice()),
    planVersion: s.planVersion,
    bots: s.bots.map(b => ({ ...b })),
    actions: s.actions.map(a => ({ ...a })),
    treasures: s.treasures.map(t => ({ ...t })),
    goals: s.goals.map(g => ({ ...g })),
    remaining: s.remaining.slice(),
    decided: new Set(s.decided),
    placements: s.placements.slice(),
  });

  // Value of an arrow after `clicks` extra clicks: clickPlanCell does value + 1 (string concatenation
  // when the data has string values) and removes the arrow when the value == 4.
  function arrowValues(c) {
    const out = [];
    let v = c.value;
    for (let k = 0; k < 4; k++) {
      out.push({ raw: v, clicks: k });
      v = v + 1;
      if (v == 4) break;
    }
    return out;
  }

  // The action exactly as clickPlanCell() pushes it, reset like stopBots() does at the start.
  function place(s, x, y, cmd, raw, clicks) {
    const c = commands[cmd];
    const a = clicks > 0
      ? { x: String(x), y: String(y), commandIndex: cmd, type: c.type, value: raw, direction: raw, color: c.color, fixed: false, used: 0, visible: true }
      : c.type == 'bomb'
        ? { x: String(x), y: String(y), commandIndex: cmd, type: c.type, value: c.value, color: c.color, fixed: false, used: 0, visible: true, activated: false, state: 0 }
        : { x: String(x), y: String(y), commandIndex: cmd, type: c.type, color: c.color, value: c.value, direction: c.value, fixed: false, used: 0, visible: true };
    if (a.type == 'arrow1') a.used = 0;
    if (a.type == 'bomb') { a.state = 0; a.activated = false; }
    if (a.type === 'arrowR+' || a.type === 'arrowR-') a.direction = a.value;
    s.actions.push(a);
    s.remaining[cmd]--;
    s.decided.add(key(x, y));
    s.placements.push({ x: Number(x), y: Number(y), cmd, value: isArrow(c.type) ? (Number(c.value) || 0) + clicks : c.value });
  }

  // What can go on a cell right now (null = leave it empty).
  function options(s, x, y) {
    const opts = [null];
    commands.forEach((c, i) => {
      if (s.remaining[i] <= 0) return;
      if (isArrow(c.type)) {
        for (const v of arrowValues(c)) opts.push({ cmd: i, raw: v.raw, clicks: v.clicks });
      } else if (c.type === 'teleport') {
        const other = s.actions.some(a => a.type === 'teleport' && a.visible);
        if (other) opts.push({ cmd: i, clicks: 0 });
        if (s.remaining[i] >= 2) {
          // A teleport needs a partner: also pick where the second one goes.
          for (let py = 0; py < H; py++) for (let px = 0; px < W; px++) {
            if ((px !== Number(x) || py !== Number(y)) && placeable(px, py) && !s.decided.has(key(px, py))) {
              opts.push({ cmd: i, clicks: 0, partner: { x: px, y: py } });
            }
          }
        }
      } else {
        opts.push({ cmd: i, clicks: 0 });
      }
    });
    return opts;
  }

  function die(b) { b.nX = b.x; b.nY = b.y; b.status = 'dead'; }

  // prepareMoveBot()
  function prepareMove(s, b, steps) {
    if (b.status == 'dead' || b.finished == true) return;
    const [dx, dy] = dirCoords(b.direction);
    const nX = parseInt(b.x) + parseInt(dx * steps);
    const nY = parseInt(b.y) + parseInt(dy * steps);
    const oneX = parseInt(b.x) + parseInt(dx);
    const oneY = parseInt(b.y) + parseInt(dy);
    if (nX >= 0 && nY >= 0 && nX < W && nY < H) {
      if (steps == 2 && s.plan[oneY][oneX] == '#') return die(b);
      const c = s.plan[nY][nX];
      if (c == '#' || c == '@' || c === '&') return die(b);
      if (c == '*' || c == '+') { b.nX = nX; b.nY = nY; }
    } else {
      die(b);
    }
  }

  // One call of moveBots() followed by removeRocks(), explode(), evaluate() and redrawPlan().
  function step(s) {
    const { bots, actions, plan, goals, treasures } = s;

    for (let i = 0; i < bots.length; i++) {
      const b = bots[i];
      if (b.status == 'dead' || b.finished == true) continue;
      let steps = 1;
      for (let j = 0; j < actions.length; j++) {
        const a = actions[j];
        if (!(b.y == a.y && b.x == a.x && a.visible == true)) continue;
        if (a.color == b.color) {
          if (a.type == 'arrow') {
            if (a.value == 0) b.direction = 0;
            if (a.value == 1) b.direction = 1;
            if (a.value == 2) b.direction = 2;
            if (a.value == 3) b.direction = 3;
          }
          if (a.type == 'arrow1' && a.used == 0) {
            if (a.value == 0) b.direction = 0;
            if (a.value == 1) b.direction = 1;
            if (a.value == 2) b.direction = 2;
            if (a.value == 3) b.direction = 3;
            a.used = 1;
          }
          if (a.type === 'arrowR+') { b.direction = a.direction; a.direction = (a.direction + 3) % 4; }
          if (a.type === 'arrowR-') { b.direction = a.direction; a.direction = (a.direction + 1) % 4; }
          if (a.type == 'jump') steps = 2;
        } else if (a.type == 'arrow1' && a.used == 0) {
          a.used = 1;
        }
        if (a.type == 'gate' && b.color !== a.color) b.color = a.color;
        if (a.type == 'bomb' && a.state == 0) { a.activated = true; a.state++; }
        if (a.type == 'teleport' && b.teleportApplied == 0) {
          const other = actions.find((o, index) => o.type === 'teleport' && index !== j && o.visible);
          if (other) { b.x = other.x; b.y = other.y; b.teleportApplied = 2; steps = 0; }
          else b.status = 'dead';
        }
      }
      prepareMove(s, b, steps);
      if (b.teleportApplied > 0) b.teleportApplied--;
    }

    // executeCollisionsBot()
    for (let i = 0; i < bots.length; i++) {
      const c = bots[i];
      if (c.status == 'dead' || c.finished == true) continue;
      const goal = goals.find(g => g.x === c.nX && g.y === c.nY && g.visible);
      if (goal && goal.color !== c.color) { c.status = 'dead'; c.nX = c.x; c.nY = c.y; continue; }
      for (let j = 0; j < bots.length; j++) {
        const o = bots[j];
        if (c.color !== 'black' && i !== j && c.nX === o.nX && c.nY === o.nY) {
          if (goal) { c.nX = c.x; c.nY = c.y; }
          else { c.status = 'dead'; break; }
        }
        if (c.color != 'black' && i != j && c.nX == o.x && c.nY == o.y && c.x == o.nX && c.y == o.nY) {
          c.status = 'dead';
          break;
        }
      }
    }
    for (const b of bots) if (b.status === 'dead') { b.nX = b.x; b.nY = b.y; }

    // executeMoveBot()
    for (const b of bots) {
      if (b.status == 'dead' || b.finished == true) continue;
      const nX = b.nX, nY = b.nY;
      for (const t of treasures) {
        if (t.y == nY && t.x == nX && t.collected == false && t.visible == true) t.collected = true;
      }
      for (const g of goals) {
        if (g.y == nY && g.x == nX && g.color == b.color && g.visible) {
          b.x = -1; b.y = -1; b.nX = -1; b.nY = -1;
          b.finished = true;
          g.completed++;
        }
      }
      b.x = nX; b.y = nY;
    }

    // removeRocks() (strict comparison: a wand works only when its coordinates have the bot's type)
    for (const b of bots) {
      for (const a of actions) {
        if (a.type === 'wand' && a.visible && a.x === b.x && a.y === b.y) {
          for (let x = 0; x < W; x++) for (let y = 0; y < H; y++) {
            if (plan[y][x] === '&') { plan[y][x] = '*'; s.planVersion++; }
          }
        }
      }
    }

    // explode()
    for (const a of actions) {
      if (!(a.type == 'bomb' && a.activated == true && a.state == 4)) continue;
      a.visible = false;
      a.activated = false;
      for (let d = 0; d < 5; d++) {
        const [dx, dy] = dirCoords(d);
        const nX = parseInt(a.x) + parseInt(dx);
        const nY = parseInt(a.y) + parseInt(dy);
        if (!(nX >= 0 && nY >= 0 && nX < W && nY < H)) continue;
        s.decided.add(key(nX, nY)); // anything placed there now would be invisible
        for (const o of actions) if (o.y == nY && o.x == nX) o.visible = false;
        for (const g of goals) if (g.y == nY && g.x == nX && g.visible == true) g.visible = false;
        for (const t of treasures) if (t.y == nY && t.x == nX && !t.collected) t.visible = false;
        for (const b of bots) if (b.y == nY && b.x == nX && b.finished == false) b.status = 'dead';
        if (plan[nY][nX] == '#' || plan[nY][nX] == '@' || plan[nY][nX] === '&') { plan[nY][nX] = '*'; s.planVersion++; }
      }
    }

    // redrawPlan() advances the countdown of every drawn, activated bomb.
    for (const a of actions) {
      if (a.type == 'bomb' && a.visible == true && a.state < 4 && a.activated == true) {
        const x = Number(a.x), y = Number(a.y);
        if (Number.isInteger(x) && Number.isInteger(y) && x >= 0 && y >= 0 && x < W && y < H) a.state++;
      }
    }
  }

  function outcome(s) {
    // evaluate()
    const home = s.bots.every(b => b.finished || b.color === 'black');
    if (home && s.treasures.every(t => t.collected)) return 'win';
    // Hopeless: a non-black bot can never finish once dead, a destroyed mushroom never comes back.
    if (s.bots.some(b => b.status === 'dead' && !b.finished && b.color !== 'black')) return 'lose';
    if (s.treasures.some(t => !t.collected && !t.visible)) return 'lose';
    if (s.bots.every(b => b.status === 'dead' || b.finished)) return 'lose';
    return null;
  }

  // Everything that can change while the bots run (the decided set only grows, so a repeated
  // signature between two decisions means an endless loop).
  function signature(s) {
    let sig = s.planVersion + '|';
    for (const b of s.bots) sig += b.x + ',' + b.y + ',' + b.nX + ',' + b.nY + ',' + b.direction + ',' + b.color + ',' + b.status + ',' + b.finished + ',' + b.teleportApplied + ';';
    for (const a of s.actions) sig += (a.visible ? 1 : 0) + ',' + a.used + ',' + a.direction + ',' + a.state + ',' + a.activated + ';';
    for (const t of s.treasures) sig += (t.collected ? 1 : 0) + (t.visible ? 1 : 0);
    for (const g of s.goals) sig += g.visible ? 1 : 0;
    return sig;
  }

  const deadline = Date.now() + timeLimitMs;
  let ticks = 0;

  function run(s, tick) {
    const seen = new Set();
    for (; tick < MAX_STEPS; tick++) {
      if ((++ticks & 1023) === 0 && Date.now() > deadline) throw new Error('timeout');
      // A bot standing on an undecided free cell: branch on what was placed there.
      const b = s.bots.find(b => b.status !== 'dead' && !b.finished &&
        placeable(b.x, b.y) && !s.decided.has(key(b.x, b.y)));
      if (b) {
        const bx = Number(b.x), by = Number(b.y);
        for (const o of options(s, bx, by)) {
          const c = clone(s);
          c.decided.add(key(bx, by));
          if (o) {
            place(c, bx, by, o.cmd, o.raw, o.clicks);
            if (o.partner) place(c, o.partner.x, o.partner.y, o.cmd, o.raw, 0);
          }
          const r = run(c, tick);
          if (r) return r;
        }
        return null;
      }
      const sig = signature(s);
      if (seen.has(sig)) return null;
      seen.add(sig);
      step(s);
      const res = outcome(s);
      if (res === 'win') return s.placements;
      if (res === 'lose') return null;
    }
    return null;
  }

  try {
    return run(start, 0);
  } catch (e) {
    if (e.message === 'timeout') return null;
    throw e;
  }
};
