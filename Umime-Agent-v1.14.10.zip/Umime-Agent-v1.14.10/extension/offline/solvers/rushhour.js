// Rush hour solver: BFS over car positions, one move = slide one car any distance.
// plan: rows of chars ('#' free, '-' wall, letters = cars), cars: rushhour.js objects
// {type, x, y, size, orientation}, exit cell (exitX, exitY).
// Returns [{type, x, y}] (new top-left of the moved car) or null.
window.solveRushHour = function (plan, cars, exitX, exitY) {
  const H = plan.length;
  const W = Math.max(...plan.map(r => r.length));
  const movable = cars.filter(c => c.size > 1 && c.orientation !== '?');
  const horiz = movable.map(c => c.orientation === 'E' || c.orientation === 'W');
  const target = movable.findIndex(c => c.type === 'x');
  if (target < 0) return null;

  // Static obstacles: everything that is not free space or a movable car.
  const movableTypes = new Set(movable.map(c => c.type));
  const base = new Uint8Array(W * H).fill(1);
  for (let y = 0; y < H; y++) for (let x = 0; x < plan[y].length; x++) {
    const ch = plan[y][x];
    if (ch === '#' || movableTypes.has(ch)) base[y * W + x] = 0;
  }

  const fixed = movable.map((c, i) => (horiz[i] ? c.y : c.x));
  const start = movable.map((c, i) => (horiz[i] ? c.x : c.y));

  function occupancy(pos) {
    const occ = base.slice();
    movable.forEach((c, i) => {
      for (let s = 0; s < c.size; s++) {
        occ[horiz[i] ? fixed[i] * W + pos[i] + s : (pos[i] + s) * W + fixed[i]] = 1;
      }
    });
    return occ;
  }

  // Same test as evaluate() in rushhour.js.
  function solved(pos) {
    const size = movable[target].size;
    const x = horiz[target] ? pos[target] : fixed[target];
    const y = horiz[target] ? fixed[target] : pos[target];
    return x + size - 1 === exitX || y + size - 1 === exitY || x - 1 === exitX || y - 1 === exitY;
  }

  const key = pos => String.fromCharCode(...pos);
  const prev = new Map([[key(start), null]]); // state -> [prevKey, carIndex, newPos]
  let queue = [start];
  let found = null;

  search:
  while (queue.length) {
    const next = [];
    for (const pos of queue) {
      const occ = occupancy(pos);
      const k = key(pos);
      for (let i = 0; i < movable.length; i++) {
        const size = movable[i].size;
        const cell = p => (horiz[i] ? fixed[i] * W + p : p * W + fixed[i]);
        const limit = horiz[i] ? W : H;
        const targets = [];
        // The page never lets a car slide into row/column 0.
        for (let p = pos[i] - 1; p >= 1 && !occ[cell(p)]; p--) targets.push(p);
        for (let p = pos[i] + 1; p + size - 1 < limit && !occ[cell(p + size - 1)]; p++) targets.push(p);
        for (const p of targets) {
          const np = pos.slice();
          np[i] = p;
          const nk = key(np);
          if (prev.has(nk)) continue;
          prev.set(nk, [k, i, p]);
          if (solved(np)) { found = nk; break search; }
          next.push(np);
        }
      }
    }
    queue = next;
  }
  if (!found) return null;

  const moves = [];
  for (let k = found; prev.get(k); k = prev.get(k)[0]) {
    const [, i, p] = prev.get(k);
    const c = movable[i];
    moves.unshift({ type: c.type, x: horiz[i] ? p : fixed[i], y: horiz[i] ? fixed[i] : p });
  }
  return moves;
};
