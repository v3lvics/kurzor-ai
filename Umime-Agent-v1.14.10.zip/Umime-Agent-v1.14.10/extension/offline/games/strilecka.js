// Střílečka (strilecka.js): statements fly across #plan as .word[data-index=i]; shoot (click) every
// true one, never a false one. 3 lives, 5 levels, the level is time driven (45–90 s, ~20 s with
// "Popožeň" held). The truth flags come from the downloaded loadStrilecka.php ({items: [{id,
// correct: 0|1, term}]}, data order = data-index), which hook.js keeps in store.loads.
// One plan() = one level. The page never calls updateItemUrl, so next() emits the runner's 'item' event.
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { store, until, sleep, rand, hasScript, urlName } = kit;
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const shown = el => !!el && getComputedStyle(el).display !== 'none';
  const norm = s => String(s || '').replace(/\s+/g, '');
  // `specs` is a top-level const of the page (not on window), reachable by name from the MAIN world.
  const spec = () => (typeof specs !== 'undefined' ? specs : null);
  const level = () => Number(window.level);
  const maxLevel = () => Number(spec() && spec().maxLevel) || 5;
  const levelConfig = () => (spec() && spec().levelConfig && spec().levelConfig[level()]) || {};

  const allDone = () => shown($('#finalboard')) || level() > maxLevel();
  const running = () => shown($('#playground')) && !!$('#plan .word');
  const boardBtn = () => ['#board-start', '#board-win', '#board-lose'].map(s => $(s)).filter(shown)
    .map(b => b.querySelector('[data-data=load-level]')).filter(Boolean)[0] || null;
  const won = () => shown($('#board-win')) || allDone();
  const lost = () => shown($('#board-lose')) || ($$('#lives img').length > 0 && !$('#lives img:not(.removed)'));
  const hit = el => el.classList.contains('correct') || el.classList.contains('wrong');

  // ------------------------------------------------------------ data
  // Rendered text of a term, the same way fireWord() renders it (renderWithUnderscores without
  // substitutions, which Střílečka pages do not enable).
  const rendered = new WeakMap();
  function termText(item) {
    if (!rendered.has(item)) rendered.set(item, norm(window.renderContentFormat(item.term).textContent));
    return rendered.get(item);
  }
  const wordText = el => norm(el.textContent);
  const loadLevelOf = l => { try { return Number(new URL(l.url, location.href).searchParams.get('level')); } catch (e) { return NaN; } };

  // The downloaded array that is on screen now. Newest loadStrilecka response first (the page plays
  // the newest one; after a lost level an older one of the same level is still in the list), and
  // it must explain the board exactly: same level, length = words launched + "Zbývá", and every
  // launched word's text equals its item's term.
  function pickData() {
    const words = $$('#plan .word');
    const remaining = Number(($('#remaining-stats') || {}).textContent);
    const loads = (store.loads || []).filter(l => /loadStrilecka\.php/i.test(l.url) && l.data && Array.isArray(l.data.items)).reverse();
    for (const l of loads) {
      const items = l.data.items;
      const lv = loadLevelOf(l);
      if (lv && lv !== level()) continue;
      if (Number.isFinite(remaining) && items.length !== words.length + remaining) continue;
      if (words.every(el => { const it = items[Number(el.dataset.index)]; return it && it.term && termText(it) === wordText(el); })) return items;
    }
    return null;
  }

  // ------------------------------------------------------------ playing
  // "Popožeň": mousedown speeds the level up until a mouseup reaches document (and ≥ 500 ms passed).
  function holdSpeedUp() {
    const btn = $('#speed-up');
    if (!btn) return () => {};
    btn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, button: 0, buttons: 1 }));
    return () => document.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 0 }));
  }

  async function startIfNeeded() {
    if (running()) return true;
    const btn = boardBtn();
    if (!btn) return false;
    btn.click();
    return until(running, 8000, 40);
  }

  // Shortest time a word of this level is on screen (ms): baseTime × slowness × 0.8 (random factor),
  // a third of it while "Popožeň" is held.
  const minFlight = fast => (Number(spec() && spec().baseTime) || 3000) * (Number(levelConfig().slowness) || 3) * 0.8 / (fast ? 3 : 1);

  // pace: { speedUp, delay(): ms from noticing a word to the shot }
  async function play(pace) {
    const L0 = level();
    const seen = new Set();
    let items = null, waitingSince = 0, release = null;
    try {
      if (!(await startIfNeeded())) return console.warn('[neumimeto] Střílečka: level se nespustil.');
      if (pace.speedUp) release = holdSpeedUp();
      const end = Date.now() + 10 * 60 * 1000;
      while (Date.now() < end && level() === L0 && !lost() && shown($('#playground'))) {
        const fresh = $$('#plan .word').filter(el => !seen.has(el.dataset.index));
        if (fresh.length) {
          // hook.js decodes its copy of the response alongside the page: give it a moment.
          if (!items) {
            items = pickData();
            if (!items) {
              waitingSince = waitingSince || Date.now();
              if (Date.now() - waitingSince > 2500) return console.warn('[neumimeto] Střílečka: slova na ploše neodpovídají staženým datům, nestřílím.');
              await sleep(30);
              continue;
            }
          }
          for (const el of fresh) {
            const i = Number(el.dataset.index);
            const item = items[i];
            // Never shoot on a mismatch: one wrong shot costs a life.
            if (!item || termText(item) !== wordText(el)) return console.warn('[neumimeto] Střílečka: slovo', i, 'neodpovídá datům, střelba zastavena.');
            seen.add(el.dataset.index);
            if (!item.correct || hit(el)) continue; // the page checks truthiness too (hitWord)
            const delay = Math.min(pace.delay(), minFlight(pace.speedUp) * 0.4);
            setTimeout(() => { if (level() === L0 && el.isConnected && !hit(el)) el.click(); }, delay);
          }
        }
        await sleep(30);
      }
    } catch (e) {
      console.warn('[neumimeto] Střílečka:', e);
    } finally {
      if (release) release();
    }
    // win: level++ at once, board after the 0.5 s fade; loss: board after 0.5 s + fade
    await until(() => won() || lost(), 5000, 50);
  }

  const PACE = {
    fast: { speedUp: true, delay: () => rand(150, 400) },
    calm: { speedUp: false, delay: () => rand(400, 1500) },
    human: { speedUp: false, delay: () => (Math.random() < 0.15 ? rand(2500, 4500) : rand(700, 2500)) },
  };

  function plan() {
    if (allDone()) return null;
    const racing = running();
    if (!racing && !boardBtn()) return null;
    const pick = ctx => (ctx && ctx.fast ? PACE.fast : PACE.calm);
    let job = null;
    // Level already running: Počkat must not hold the shooting back, so the first step starts it
    // and the last one only waits for the end of the level.
    const steps = racing
      ? [{ run: ctx => { job = play(pick(ctx)); } }, { run: () => job }]
      : [{ run: ctx => play(pick(ctx)) }];
    const human = [{ wait: racing ? rand(0.2, 0.6) : rand(1.5, 4) }, { wait: 0, run: () => play(PACE.human) }];
    return { steps, human };
  }

  return {
    key: 'strilecka',
    get label() { return (kit.detectedKey === 'strilecka' && urlName()) || 'Střílečka'; },
    unit: 'level',
    waitHint: 'Po odpočtu spustí level a sestřelí všechna pravdivá slova, nepravdivá nechá letět.',
    humanHint: 'Spustí level a pravdivá slova sestřeluje s lidskými prodlevami, bez popohánění.',
    ownPace: true,
    defaultTime: [3, 8],
    detect: () => hasScript('/exercise/strilecka.js'),
    ready: () => running() || !!boardBtn() || allDone(),
    // Won level (win board or the final board). Start / lose boards count as "not done".
    finished: won,
    next: async () => {
      if (allDone()) return;
      const btn = await until(boardBtn, 4000, 50) && boardBtn();
      if (!btn) return;
      btn.click();
      await until(running, 8000, 40);
      // No updateItemUrl in this game: tell the runner a new round started (Auto goes on).
      store.listeners.forEach(f => { try { f('item', 'strilecka-level-' + level()); } catch (e) {} });
    },
    retry: false,
    plan,
  };
});
