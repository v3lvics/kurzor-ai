// Grafař (grafar.js + JSXGraph 0.99.7). The solution is in the page global
// questions[questionOffset].question.solution; the page decides in evaluate():
//   findFormula            – type the formula / "x,y" into #formula{i}, click #evaluate
//   findFunction, solveEquation – drag the snap-to-grid handle points (PointerEvents on #board),
//                            the page checks curve i with hasPoint at x = -5..4 / point i exactly
//   chooseFunction(Listing) – pointerdown on the right curve; its mousedown handler calls evaluate()
// Every answer is checked with the page's own test before the step that makes the page evaluate it,
// so a mismatch stops the solver instead of logging a wrong answer.
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { currentId, until, sleep, rand, hasScript, visible, userError, urlName } = kit;
  const $ = id => document.getElementById(id);
  const MANIP = ['findFunction', 'solveEquation'];
  const CHOOSE = ['chooseFunction', 'chooseFunctionListing'];
  const cur = () => (Array.isArray(window.questions) && window.questionOffset >= 0 ? window.questions[window.questionOffset] || null : null);
  const question = () => { const c = cur(); return c && c.question; };
  const ev = v => (typeof v === 'function' ? v() : v);
  const warn = (...a) => console.warn('[neumimeto] Grafař:', ...a);

  // The page listens to touchstart instead of click on tablets / phones (grafar.js l. 51-57).
  const touchDevice = () => window.deviceType === 'tablet' || window.deviceType === 'phone';
  const press = el => {
    if (!el) return;
    if (touchDevice()) el.dispatchEvent(new Event('touchstart', { bubbles: true, cancelable: true }));
    else el.click();
  };
  const evaluated = () => window.finished === 1;
  const pressEvaluate = () => until(() => { if (!evaluated()) press($('evaluate')); return evaluated(); }, 3000, 50);

  // ------------------------------------------------------------ JSXGraph helpers
  const B = () => window.board;
  const isVisible = o => !o.visPropCalc || o.visPropCalc.visible;
  // Board curves (question.board) carry boardStuffOffset and a mousedown handler that calls evaluate().
  const boardCurves = () => B().objectsList.filter(o => o.elementClass === JXG.OBJECT_CLASS_CURVE && o.getAttribute('boardStuffOffset') != null);
  const curveIndex = c => Number(c.getAttribute('boardStuffOffset'));

  const pev = (type, cx, cy) => new PointerEvent(type, {
    bubbles: true, cancelable: true, composed: true, pointerId: 1, pointerType: 'mouse', isPrimary: true,
    clientX: cx, clientY: cy, button: 0, buttons: type === 'pointerup' ? 0 : 1,
  });
  // graph -> client pixels (JSXGraph: screen = client − getCoordsTopLeftCorner(), both use its cache)
  const toClient = (x, y) => {
    const tl = B().getCoordsTopLeftCorner();
    const c = new JXG.Coords(JXG.COORDS_BY_USER, [x, y], B()).scrCoords;
    return [tl[0] + c[1], tl[1] + c[2]];
  };
  // The board-screen position JSXGraph itself will compute for this event.
  const screenOf = e => B().getMousePosition(e);
  const curvesHit = (sx, sy) => boardCurves().filter(c => { try { return isVisible(c) && c.hasPoint(sx, sy); } catch (e) { return true; } });

  const dragTime = o => (o.lastDragTime && o.lastDragTime.getTime ? o.lastDragTime.getTime() : 0);
  // What a pointerdown at (sx, sy) grabs – same rule as Board.initMoveObject(): the topmost draggable
  // object (layer, then the most recently dragged one).
  function grabbed(sx, sy) {
    let p = null;
    for (const o of B().objectsList) {
      let hit = false;
      try { hit = !!o.isDraggable && isVisible(o) && !ev(o.visProp.fixed) && !!o.hasPoint && o.hasPoint(sx, sy); } catch (e) {}
      if (!hit) continue;
      if (B().attr && B().attr.ignorelabels && p && p.label === o) continue;
      if (!p || o.visProp.layer > p.visProp.layer ||
          (o.visProp.layer === p.visProp.layer && dragTime(o) >= dragTime(p))) p = o;
    }
    return p;
  }

  const at = (h, to) => Math.abs(h.X() - to[0]) < 1e-6 && Math.abs(h.Y() - to[1]) < 1e-6;

  // A player's drag: pointerdown on the handle, a few pointermoves (the page snaps live), pointerup on
  // document. JSXGraph fires 'drag', so the page logs the new position (manipulateCurveData).
  async function drag(h, to, animate) {
    const box = $('board');
    const [ax, ay] = toClient(h.X(), h.Y());
    const down = pev('pointerdown', ax, ay);
    const [sx, sy] = screenOf(down);
    const top = grabbed(sx, sy);
    if (top !== h) return { status: 'covered', by: top };
    // A gray board curve under the pointer would call evaluate() on pointerdown.
    if (curvesHit(sx, sy).length) return { status: 'curve' };
    box.dispatchEvent(down);
    const n = animate ? Math.round(rand(8, 14)) : 2;
    for (let k = 1; k <= n; k++) {
      const [bx, by] = toClient(to[0], to[1]);
      box.dispatchEvent(pev('pointermove', ax + (bx - ax) * k / n, ay + (by - ay) * k / n));
      if (animate) await sleep(rand(16, 32));
    }
    const [bx, by] = toClient(to[0], to[1]);
    document.dispatchEvent(pev('pointerup', bx, by));
    await sleep(0);
    return { status: at(h, to) ? 'ok' : 'missed' };
  }

  // ------------------------------------------------------------ findFunction / solveEquation
  function handles(q, i) {
    const m = q.manipulate[i], c = window.manipulateCurve && window.manipulateCurve[i];
    if (!m) return [];
    if (m.type === 'point') return c ? [c] : [];
    if (m.type === 'line') return c && c.point1 && c.point2 ? [c.point1, c.point2] : [];
    // parabola / absolute / hyperbola / sin: two points created with attribute offset = i
    return B().objectsList.filter(o => o.elementClass === JXG.OBJECT_CLASS_POINT && o.visProp.offset === i);
  }

  // The probes evaluate() uses (l. 692-705): x = -5..4, skipping ±Infinity.
  function probes(formula) {
    const f = window.transformFormulaToJs(formula), out = [];
    for (let x = -5; x < 5; x++) {
      const y = window.formulaValue(f, x);
      if (y !== Infinity && y !== -Infinity) out.push([x, y]);
    }
    return out;
  }

  // Integer-grid handle positions (π/4 in x for sin) whose curve, built like the page builds it,
  // passes all probes; the one closest to the middle of the board.
  function fit(type, formula) {
    const R = []; for (let i = -7; i <= 7; i++) R.push(i);
    const RX = []; for (let i = -9; i <= 9; i++) if (Math.abs(i * Math.PI / 4) <= 7) RX.push(i * Math.PI / 4);
    const tg = probes(formula), tol = 0.03;
    if (!tg.length) return null;
    let best = null, bestCost = Infinity;
    const ok = fn => tg.every(([x, y]) => Math.abs(fn(x) - y) < tol);
    const take = (a, b, fn) => {
      const cost = Math.max(Math.abs(a[0]), Math.abs(a[1]), Math.abs(b[0]), Math.abs(b[1]));
      if (cost < bestCost && ok(fn)) { best = [a, b]; bestCost = cost; }
    };
    if (type === 'line') for (const x1 of R) for (const y1 of R) for (const x2 of R) { if (x2 <= x1) continue; for (const y2 of R) { const k = (y2 - y1) / (x2 - x1); take([x1, y1], [x2, y2], x => y1 + k * (x - x1)); } }
    if (type === 'parabola') for (const ax of R) for (const ay of R) for (const bx of R) { if (bx === ax) continue; for (const by of R) { const k = (by - ay) / ((bx - ax) * (bx - ax)); take([ax, ay], [bx, by], x => k * (x - ax) * (x - ax) + ay); } }
    if (type === 'absolute') for (const ax of R) for (const ay of R) for (const bx of R) { if (bx === ax) continue; for (const by of R) { const k = (by - ay) / (bx - ax); take([ax, ay], [bx, by], x => k * Math.abs(x - ax) + ay); } }
    if (type === 'hyperbola') for (const sx of R) for (const sy of R) for (const ax of R) { if (ax === sx) continue; for (const ay of R) { if (ay === sy) continue; const k = (ax - sx) * (ay - sy); take([sx, sy], [ax, ay], x => sy + k / (x - sx)); } }
    if (type === 'sin') for (const ax of RX) for (const ay of R) for (const bx of RX) { if (bx === ax) continue; for (const by of R) { const d = by - ay, k = Math.PI / 2 / (bx - ax); take([ax, ay], [bx, by], x => d * Math.sin(k * (x - ax)) + ay); } }
    return best;
  }

  // [{ h: handle point, to: [x, y] }] or null
  function jobsFor(q) {
    if (!Array.isArray(q.solution) || !Array.isArray(q.manipulate) || q.solution.length > q.manipulate.length) return null;
    const jobs = [];
    for (let i = 0; i < q.solution.length; i++) {
      const s = q.solution[i], m = q.manipulate[i], hs = handles(q, i);
      if (!m) return null;
      if (s[0] === 'point') {
        if (m.type !== 'point' || hs.length !== 1 || !Array.isArray(s[1])) return null;
        jobs.push({ h: hs[0], to: [Number(s[1][0]), Number(s[1][1])] });
      } else if (s[0] === 'functiongraph') {
        if (!['line', 'parabola', 'absolute', 'hyperbola', 'sin'].includes(m.type) || hs.length !== 2) return null;
        const to = fit(m.type, s[1]);
        if (!to) return null;
        jobs.push({ h: hs[0], to: to[0] }, { h: hs[1], to: to[1] });
      } else return null;
    }
    return jobs;
  }

  // The page's own test (evaluate(), l. 686-721), run before clicking "Vyhodnotit".
  function pageAccepts(q) {
    return q.solution.every((s, i) => {
      const m = window.manipulateCurve[i];
      if (!m) return false;
      if (s[0] === 'point') return m.X() == s[1][0] && m.Y() == s[1][1];
      if (s[0] !== 'functiongraph') return false;
      const f = window.transformFormulaToJs(s[1]);
      for (let x = -5; x < 5; x++) {
        const y = window.formulaValue(f, x);
        if (y === Infinity || y === -Infinity) continue;
        const c = new JXG.Coords(JXG.COORDS_BY_USER, [x, y], B());
        if (!m.hasPoint(c.scrCoords[1], c.scrCoords[2])) return false;
      }
      return true;
    });
  }

  // A free grid spot to park a handle that covers another one.
  function parkingSpot(jobs, sinBoard) {
    const xs = []; for (let i = -6; i <= 6; i++) xs.push(sinBoard ? i * Math.PI / 4 : i);
    const spots = [];
    for (const x of xs) for (let y = -6; y <= 6; y++) {
      if (jobs.some(j => Math.abs(j.to[0] - x) < 1e-6 && j.to[1] === y)) continue;
      const [cx, cy] = toClient(x, y);
      const [sx, sy] = screenOf({ clientX: cx, clientY: cy });
      if (grabbed(sx, sy) || curvesHit(sx, sy).length) continue;
      spots.push([x, y]);
    }
    spots.sort((a, b) => Math.hypot(a[0], a[1]) - Math.hypot(b[0], b[1]));
    return spots[0] || null;
  }

  // Bring one handle to its target; a handle lying on top of it is parked elsewhere first.
  async function place(job, jobs, animate, sinBoard) {
    for (let t = 0; t < 4 && !at(job.h, job.to); t++) {
      const r = await drag(job.h, job.to, animate);
      if (r.status === 'ok') return true;
      if (r.status === 'curve') return false;
      if (r.status === 'covered') {
        const other = r.by;
        if (!other || other.elementClass !== JXG.OBJECT_CLASS_POINT) return false;
        const spot = parkingSpot(jobs, sinBoard);
        if (!spot || (await drag(other, spot, animate)).status !== 'ok') return false;
      }
      if (animate) await sleep(rand(150, 400));
    }
    return at(job.h, job.to);
  }

  // All handles to their targets (several rounds: parking can move an already placed one).
  async function placeAll(jobs, animate, sinBoard) {
    for (let round = 0; round < 8; round++) {
      const pending = jobs.filter(j => !at(j.h, j.to));
      if (!pending.length) return true;
      // Prefer a handle whose target is not covered by another handle that still has to move.
      const next = pending.find(j => !pending.some(o => o !== j && at(o.h, j.to))) || pending[0];
      if (!(await place(next, jobs, animate, sinBoard))) return false;
    }
    return jobs.every(j => at(j.h, j.to));
  }

  // ------------------------------------------------------------ chooseFunction(Listing)
  // A point on a correct curve that hits only correct curves (the first hit curve's handler
  // evaluates), far (> 8 px; worst item in the data: 9.3 px) from every wrong curve and inside the visible board.
  function choosePoint(q) {
    const want = q.solution && q.solution[0] && q.solution[0][1];
    const good = new Set((q.board || []).map((b, i) => (b[0] === 'functiongraph' && b[1] === want ? i : -1)).filter(i => i >= 0));
    if (!good.size) return null;
    const curves = boardCurves();
    const right = curves.filter(c => good.has(curveIndex(c)));
    const wrong = curves.filter(c => !good.has(curveIndex(c)));
    const U = B().unitX || 35;
    let best = null;
    for (const c of right) {
      for (let x = -6.5; x <= 6.5; x += 0.1) {
        const y = c.Y(x);
        if (!isFinite(y) || Math.abs(y) > 6.5) continue;
        let md = Infinity;
        for (const w of wrong) for (let xx = x - 1; xx <= x + 1; xx += 0.02) {
          const yy = w.Y(xx);
          if (isFinite(yy)) md = Math.min(md, Math.hypot((xx - x) * U, (yy - y) * U));
        }
        if (md <= 8) continue; // hit tolerance is ~5 px; the exact hit test below decides
        const [cx, cy] = toClient(x, y);
        const [sx, sy] = screenOf({ clientX: cx, clientY: cy });
        const hits = curvesHit(sx, sy);
        if (!hits.length || hits.some(h => !good.has(curveIndex(h)))) continue;
        const score = Math.min(md, 40) - Math.abs(x) * 0.5 - Math.abs(y) * 0.3;
        if (!best || score > best.score) best = { x, y, score };
      }
    }
    return best;
  }

  async function clickCurve(q) {
    const p = choosePoint(q);
    if (!p) return warn('žádný bezpečný bod na správné křivce');
    const [cx, cy] = toClient(p.x, p.y);
    const down = pev('pointerdown', cx, cy);
    const [sx, sy] = screenOf(down);
    const hits = curvesHit(sx, sy);
    const want = q.solution[0][1];
    if (!hits.length || hits.some(h => q.board[curveIndex(h)][1] !== want)) return warn('kontrola kliknutí nesedí, neklikám');
    $('board').dispatchEvent(down);
    document.dispatchEvent(pev('pointerup', cx, cy));
    await until(evaluated, 1000, 25);
  }

  // ------------------------------------------------------------ findFormula
  const input = i => $('formula' + i);
  const answerText = s => (s[0] === 'point' ? s[1].join(',') : String(s[1]));
  function setValue(el, text) {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, text);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  async function typeInto(i, text, slow) {
    const el = input(i);
    if (!el) return;
    el.focus();
    if (!slow) return setValue(el, text);
    setValue(el, '');
    for (let k = 1; k <= text.length; k++) { setValue(el, text.slice(0, k)); await sleep(rand(90, 230)); }
  }
  // evaluate() for findFormula (l. 589-670) on what is in the inputs now.
  function formulasAccepted(q) {
    try {
      return q.solution.every((s, i) => {
        const el = input(i), v = el && el.value;
        if (!v) return false;
        if (s[0] === 'point') { const p = JSON.parse('[' + v + ']'); return p[0] == s[1][0] && p[1] == s[1][1]; }
        const a = window.transformFormulaToJs(v), b = window.transformFormulaToJs(s[1]);
        for (let x = -5; x < 5; x++) {
          const ya = window.formulaValue(a, x), yb = window.formulaValue(b, x);
          if (!(ya == yb || (isNaN(ya) && isNaN(yb)))) return false;
        }
        return true;
      });
    } catch (e) { return false; }
  }

  // ------------------------------------------------------------ adapter
  function ready() {
    const c = cur(), q = question();
    if (!c || !q || window.questionOffset >= window.questions.length) return false;
    if (window.finished !== 0 || window.gameFinished !== 0 || !B() || B() === -1) return false;
    // updateItemUrl() runs at the very end of the fade-in, when the board is complete.
    if (String(currentId()) !== String(c.id) || !visible($('questionParent'))) return false;
    if (q.type === 'findFormula') return q.solution.every((_, i) => !!input(i));
    if (MANIP.includes(q.type)) return Array.isArray(window.manipulateCurve) && window.manipulateCurve.length === q.manipulate.length;
    if (CHOOSE.includes(q.type)) return boardCurves().length === q.board.filter(b => b[0] === 'functiongraph').length;
    return true; // unknown type: plan() explains
  }

  function plan() {
    const c = cur(), q = question();
    if (!c || !q || evaluated()) return null;
    const med = Math.min(Number(c.medianResponseTime) || 10000, 90000) / 1000;
    const pace = rand(0.7, 1.1);

    if (q.type === 'findFormula') {
      const texts = q.solution.map(answerText);
      const send = { run: async () => {
        if (!formulasAccepted(q)) return warn('vepsaný předpis by stránka neuznala, nevyhodnocuji');
        await pressEvaluate();
      } };
      const fillAll = { run: async ctx => { for (let i = 0; i < texts.length; i++) await typeInto(i, texts[i], ctx && ctx.animate); } };
      const human = [{ wait: med * pace * 0.55 }];
      texts.forEach((t, i) => human.push({ wait: i ? rand(0.6, 1.6) : 0, run: ctx => typeInto(i, t, ctx && ctx.animate) }));
      human.push({ wait: rand(0.5, 1.2), ...send });
      return { steps: [fillAll, send], human };
    }

    if (MANIP.includes(q.type)) {
      const jobs = jobsFor(q);
      if (!jobs) throw userError('Tenhle graf neumím zakreslit (neznámý tvar nebo řešení mimo mřížku).');
      const sinBoard = q.manipulate.some(m => m.type === 'sin');
      const final = { run: async ctx => {
        if (!(await placeAll(jobs, ctx && ctx.animate, sinBoard))) return warn('body se nepodařilo přetáhnout');
        if (!pageAccepts(q)) return warn('zakreslení by stránka neuznala, nevyhodnocuji');
        await pressEvaluate();
      } };
      const steps = jobs.map(j => ({ run: ctx => place(j, jobs, ctx && ctx.animate, sinBoard) }));
      steps.pop();
      steps.push(final); // last handle + check + "Vyhodnotit"
      const human = [{ wait: med * pace * 0.3 }];
      const between = () => (med * pace * 0.45) / jobs.length * rand(0.6, 1.4);
      jobs.slice(0, -1).forEach(j => human.push({ wait: between(), run: ctx => place(j, jobs, ctx && ctx.animate, sinBoard) }));
      human.push({ wait: between(), ...final });
      return { steps, human };
    }

    if (CHOOSE.includes(q.type)) {
      if (!choosePoint(q)) throw userError('Na správné křivce není bezpečné místo pro kliknutí.');
      const click = { run: () => clickCurve(q) };
      return { steps: [click], human: [{ wait: med * pace }, { wait: 0, ...click }] };
    }

    throw userError('Tenhle typ úlohy Grafaře (' + q.type + ') neumím.');
  }

  return {
    key: 'grafar',
    get label() { return (kit.detectedKey === 'grafar' && urlName()) || 'Grafař'; },
    get unit() { const q = question(); return q && MANIP.includes(q.type) ? 'bod' : 'odpověď'; },
    waitHint: 'Připraví odpověď hned, poslední krok (vyhodnocení / kliknutí na graf) udělá po odpočtu.',
    humanHint: 'Odpovídá zhruba za dobu běžnou u ostatních žáků: píše po znacích a body táhne myší.',
    ownPace: true,
    defaultTime: [8, 25],
    detect: () => hasScript('/exercise/grafar.js'),
    ready,
    finished: () => evaluated() && !!cur() && !!$('board') && $('board').classList.contains('correct'),
    next: async () => {
      const btn = () => [...document.querySelectorAll('.next')].find(visible);
      if (await until(() => !!btn(), 3000, 50)) press(btn());
    },
    retry: false,
    plan,
  };
});
