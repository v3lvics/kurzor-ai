# games/ – one file per extra task type

Each file is a plain script (content script, `"world": "MAIN"`, run at `document_idle`, listed in
`manifest.json` **before** `content.js`). It registers a factory; `content.js` calls it with a `kit`
of helpers and adds the result to the type picker:

```js
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { store, currentId, findItem, urlName, lastShuffle, visible, pressEnter, until, sleep, rand,
          pickRandom, hasScript, userError } = kit;
  // ... private helpers ...
  return {
    key: 'klikacka',                       // unique, used in settings and the <select>
    get label() { return (kit.detectedKey === 'klikacka' && urlName()) || 'Označování'; },
    unit: 'oblast',                         // what one step is ("Zbývá poslední <unit>")
    waitHint: '...', humanHint: '...',      // one sentence each, Czech, shown in the panel
    defaultTime: [20, 60],                  // seconds for modes Počkat / Jako člověk
    ownPace: false,                         // true: human waits are real seconds, not weights
    detect: () => hasScript('/exercise/klikacka.js'),
    ready: () => ...,                       // the current item is on screen and the answer is known
    finished: () => ...,                    // the page accepted/evaluated the current item
    next: () => ...,                        // go to the next item (may be async)
    retry: false,                           // true only if plan() can be called again mid-item
    plan: () => null | { steps, human },
  };
});
```

`plan()` returns
- `steps`: the actions in order, `{ run(ctx) }`, `ctx = { animate, fast }`. Mode **Ihned** runs them all
  (`fast: true`), **Počkat** runs all but the last at once and the last after a countdown, so the last
  step must be the one that completes the item (e.g. last placement + "Vyhodnotit").
- `human`: `{ wait, run? }` for **Jako člověk** – `wait` is a relative weight scaled to the chosen time
  (or seconds when `ownPace`). `run(ctx)` may be async; `ctx.animate` is true there.

Return `null` from `plan()` if the answer is not known; throw `userError('…')` for a message the user
should act on.

## kit

| name | what |
|---|---|
| `store` | `window.__neumimetoData` from `hook.js`: `items` (downloaded items, merged by id), `currentId`, `shownItem` (binary choice), `inputAnswers` (`{id, answers}` from rendered `['input', …]`), `shuffles` (`[{id, arr}]` arrays the page passed to `shuffle()`, newest last) |
| `currentId()` | current item id (string) |
| `findItem(id)` | item from `store.items` |
| `urlName()` | exercise slug from the URL without `-N-uroven` |
| `lastShuffle(test)` | newest shuffled array of the current item whose elements all pass `test` |
| `visible(el)`, `pressEnter()`, `until(cond, ms, step)`, `sleep(ms)`, `rand(a, b)`, `pickRandom(arr)` | small helpers |
| `hasScript(part)`, `userError(msg)` | detection, user-facing error |

If a type needs another page function watched from the very start (like `shuffle`), say so: it has
to be added to `taps` in `hook.js` (that file runs at `document_start`).

## Rules
- Enter answers only through the page (clicks, keys, input events) so the page evaluates and logs
  them itself. Never call the site's API directly and never fake requests.
- Test with `node test/mirror.js --offline` (answers are not sent; the page's verdicts are at `/__log`).
- Look at `vpisovacka`, `presouvani`, `pexeso` in `content.js` for complete examples.
