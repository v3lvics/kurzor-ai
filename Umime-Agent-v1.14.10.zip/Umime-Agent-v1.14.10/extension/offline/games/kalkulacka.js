// Rozbitá kalkulačka (kalkulacka.js): a calculator with only some buttons working; every number in
// the list above it has to show up as a result (typed number, result of "=", an operator or a
// function). The page checks after each click (no "Vyhodnotit") and marks hit numbers with class
// "correct" on #answer<i>; when all are hit it logs the item and slides in "Další".
// Item data (store.items): { id, item: [allowed buttons], answers: [numbers as strings], medianResponseTime }.
// Its state is private, so the solver below re-implements the page's button handler exactly and
// searches a click sequence; the clicks are real clicks on the page's buttons.
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { currentId, findItem, urlName, visible, until, rand, hasScript } = kit;

  // ================================================================ solver
  // From test/research/kalkulacka-solver.js (+ a work cap per pass, eval replaced). Checked against
  // the page's own script run in node for all 105 items of the 11 sets (test/research/kalkulacka.md).
  const UNARY = ['1/x', 'x!', 'x^2', 'log', 'sqrt', 'sin', 'cos', 'tan', 'asin', 'acos', 'atan'];
  const BINARY = ['+', '-', '*', '/'];
  const rad = x => x * (Math.PI / 180), deg = x => x * (180 / Math.PI);
  // = _0x3d06f8(x, 7) of the page (the value that is actually returned)
  function rnd(x) {
    let r1 = Math.round(x * 1e7) / 1e7;
    const r3 = Math.round(x * 1e3) / 1e3;
    if (Math.abs(r1 - r3) < 1e-5) r1 = r3;
    return r1;
  }
  function fact(n) { if (n >= 0) { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; } return NaN; }
  const UF = {
    '1/x': v => 1 / v, 'x!': fact, log: v => Math.log(v) / Math.log(10), 'x^2': v => Math.pow(v, 2),
    sin: v => Math.sin(rad(v)), cos: v => Math.cos(rad(v)), tan: v => Math.tan(rad(v)),
    asin: v => deg(Math.asin(v)), acos: v => deg(Math.acos(v)), atan: v => deg(Math.atan(v)), sqrt: Math.sqrt,
  };
  const BF = { '+': (a, b) => a + b, '-': (a, b) => a - b, '*': (a, b) => a * b, '/': (a, b) => a / b };

  // ---- exact simulator of the page's button handler (readable/kalkulacka.js lines 85-245)
  // state: d = display, a = no1 (_0x4c35ab), b = no2 (_0x537d2), op, fresh (_0x9a5df8), aeq (_0x471d78), m = memory
  function initState(mem) { return { d: '0', a: NaN, b: NaN, op: false, fresh: false, aeq: false, m: mem === undefined ? NaN : mem }; }
  function simulate(s0, btn, answers) {
    const s = Object.assign({}, s0), hits = [];
    const check = () => answers.forEach((x, j) => { if (x == s.a) hits.push(j); });
    const binop = () => {
      if (!isNaN(s.a) && !isNaN(s.b)) {
        // the page evaluates eval(no1 + op + '(' + no2 + ')'): throws unless op is + - * /
      if (!BF[s.op]) throw new Error('no binary operator');
      const r = rnd(BF[s.op](Number(s.a), Number(s.b)));
        s.d = r; s.a = r; s.b = NaN; s.op = false; check(); return true;
      }
      return false;
    };
    try {
      if (/^\d$/.test(btn)) {
        if (s.fresh) { s.d = ''; s.fresh = false; }
        if (!s.aeq) {
          if (s.d == '0') s.d = '';
          s.d += btn;
          if (s.op === false) s.a = s.d; else s.b = s.d;
          check();
        } else { s.aeq = false; s.d = btn; s.a = s.d; }
      } else if (btn === '.') { if (!s.d.includes('.')) s.d += '.'; } // TypeError when d is a number
      else if (btn === 'Min') s.m = s.d;
      else if (btn === 'MR') { isNaN(s.m) ? s.d = '0' : s.d = s.m; isNaN(s.a) ? s.a = s.m : s.b = s.m; }
      else if (btn === 'AC') { s.d = '0'; s.a = NaN; s.b = NaN; s.op = false; s.aeq = false; }
      else if (BINARY.includes(btn)) { binop(); s.op = btn; s.fresh = true; s.aeq = false; }
      else if (UNARY.includes(btn)) {
        s.op = btn; s.a = s.d;
        if (!isNaN(s.a)) {
          if (!isNaN(s.b)) binop(); // always throws (eval of "3sin(3)")
          const r = rnd(UF[btn](s.a)); s.d = r; s.a = r; s.op = false; s.aeq = true; check();
        }
      } else if (btn === '=') { if (s.op !== false) { binop(); s.aeq = true; } check(); }
    } catch (e) { return null; } // the page would throw: never use such a sequence
    return { s, hits };
  }
  // does the click list solve every answer? (starting from the item's initial state, memory unknown = NaN)
  function verify(item, clicks) {
    let s = initState(NaN); const solved = item.answers.map(() => false);
    for (const b of clicks) {
      const r = simulate(s, b, item.answers); if (!r) return false;
      r.hits.forEach(j => { solved[j] = true; }); s = r.s;
    }
    return solved.every(Boolean);
  }

  // ---- fast search
  // Typeable literals. ctx 'root': display is "0" (item start / after AC); 'aeq'|'operand': first digit replaces the display.
  function literals(digits, dot, maxLen, ctx, dotLead) {
    const out = new Map();
    (function rec(s, clicks) {
      if (clicks.length >= maxLen) return;
      for (const c of digits) {
        if (s === '0' && c === '0' && clicks.length) continue; // "00" is just "0"
        const ns = s === '0' ? c : s + c, nc = clicks.concat(c);
        if (!out.has(ns) || out.get(ns).length > nc.length) out.set(ns, nc);
        rec(ns, nc);
      }
      // '.' needs a typed digit before it (otherwise it appends to the old display), except as the very first
      // key at the start/after AC where the display is "0" -> "0." (only when nothing was 'fresh').
      if (dot && s !== '' && !s.includes('.') && clicks.length + 2 <= maxLen && (clicks.length > 0 || dotLead)) rec(s + '.', clicks.concat('.'));
    })(ctx === 'root' ? '0' : '', []);
    return [...out].filter(([s]) => /\d$/.test(s)).map(([s, clicks]) => ({ s, v: Number(s), clicks }));
  }

  // Node kinds (all carry the memory value M, or null, and the page's "fresh" flag f):
  //  R  nothing entered (display 0)
  //  N  a number in no1, no operator pending; ok = a digit now starts a new number, mr = it came from MR
  //  C  an operator was just pressed, v in no1 (operand literal + closing click are one move)
  // Dijkstra over click count; nodes are deduplicated by (kind, op, flags, M, v).
  function abstractSearch(item, maxLen, budget, workCap = Infinity) {
    let work = 0;
    const buttons = item.item, answers = item.answers;
    const digits = buttons.filter(b => /^\d$/.test(b)), dot = buttons.includes('.');
    const un = buttons.filter(b => UNARY.includes(b)), bin = buttons.filter(b => BINARY.includes(b));
    const hasMin = buttons.includes('Min'), hasMR = buttons.includes('MR');
    const solved = answers.map(() => false);
    const litCache = {};
    const lits = (ctx, dotLead) => litCache[ctx + dotLead] || (litCache[ctx + dotLead] = literals(digits, dot, maxLen, ctx, dotLead));
    const operandLits = lits('operand', false);
    const hitsOf = val => { const h = []; answers.forEach((x, j) => { if (!solved[j] && x == val) h.push(j); }); return h; };
    const strHits = s => answers.map((x, j) => (!solved[j] && x == s) ? j : -1).filter(j => j >= 0);
    const OK = v => isFinite(v) && Math.abs(v) <= 1e7;
    let start = { k: 'R', v: NaN, op: '', M: null, f: false, ok: false, mr: false };
    const total = [];
    let visited = 0;
    while (solved.some(x => !x)) {
      const maps = new Map(); // tag -> Map(v -> best node)
      const tagOf = n => n.k + n.op + (n.f ? 1 : 0) + (n.ok ? 1 : 0) + (n.mr ? 1 : 0) + '|' + n.M;
      const buckets = [];
      let found = null;
      const mapFor = tag => { let m = maps.get(tag); if (!m) maps.set(tag, m = new Map()); return m; };
      // returns true when the move hits an unsolved target
      const emit = (n, cost, par, clicks, hit) => {
        n.cost = cost; n.par = par; n.clicks = clicks;
        if (hit && hit.length) { found = { n, hit }; return true; }
        const m = mapFor(n.tag || (n.tag = tagOf(n))), old = m.get(n.v);
        if (old !== undefined && old.cost <= cost) return false;
        work++; m.set(n.v, n); (buckets[cost] = buckets[cost] || []).push(n);
        return false;
      };
      emit(start, 0, null, [], null);
      for (let c = 0; c < buckets.length && !found; c++) {
        const bucket = buckets[c]; if (!bucket) continue;
        for (let bi = 0; bi < bucket.length && !found; bi++) {
          const n = bucket[bi];
          if (mapFor(n.tag).get(n.v) !== n) continue; // superseded by a cheaper path
          if (++visited > budget || work > workCap) return null;
          if (n.k === 'R') {
            for (const l of lits('root', !n.f)) // every typed digit runs check() on the typed string
              if (emit({ k: 'N', v: l.v, op: '', M: n.M, f: false, ok: false, mr: false }, c + l.clicks.length, n, l.clicks, strHits(l.s))) break;
            if (!found && hasMR && n.M !== null) emit({ k: 'N', v: Number(n.M), op: '', M: n.M, f: n.f, ok: false, mr: true }, c + 1, n, ['MR'], null);
          } else if (n.k === 'N') {
            for (const u of un) {
              if (u === 'x!' && !(n.v >= 0 && n.v <= 170)) continue; // the page loops up to n: never feed it big numbers
              const r = rnd(UF[u](n.v)); if (!OK(r)) continue;
              if (emit({ k: 'N', v: r, op: '', M: n.M, f: n.f, ok: true, mr: false }, c + 1, n, [u], hitsOf(r))) break;
            }
            if (found) break;
            for (const o of bin) emit({ k: 'C', v: n.v, op: o, M: n.M, f: true, ok: false, mr: false }, c + 1, n, [o], null);
            if (hasMin && n.M !== n.v) emit({ k: 'N', v: n.v, op: '', M: n.v, f: n.f, ok: n.ok, mr: n.mr }, c + 1, n, ['Min'], null);
            if (n.ok) { // a digit after a result starts a new number; the first such digit does not run check()
              for (const l of lits('aeq', false))
                if (emit({ k: 'N', v: l.v, op: '', M: n.M, f: false, ok: false, mr: false }, c + l.clicks.length, n, l.clicks, l.clicks.length < 2 ? null : strHits(l.s))) break;
              if (found) break;
            }
            emit({ k: 'R', v: NaN, op: '', M: n.M, f: n.f, ok: false, mr: false }, c + 1, n, ['AC'], null);
          } else { // C: operand (literal or MR), then the closing click ('=' or the next operator) computes and checks
            const f = BF[n.op];
            // hot loop: look the targets up before allocating a node
            const mapsC = bin.map(o2 => mapFor(tagOf({ k: 'C', op: o2, M: n.M, f: true, ok: false, mr: false })));
            const mapsN = [false, true].map(nf => mapFor(tagOf({ k: 'N', op: '', M: n.M, f: nf, ok: true, mr: false })));
            const run = (ov, clicks, nf) => {
              work++;
              const w = rnd(f(n.v, ov)); if (!OK(w)) return false;
              const h = hitsOf(w), cc = c + clicks.length + 1;
              if (h.length) {
                for (const o2 of bin) if (emit({ k: 'C', v: w, op: o2, M: n.M, f: true, ok: false, mr: false }, cc, n, clicks.concat(o2), h)) return true;
                return emit({ k: 'N', v: w, op: '', M: n.M, f: nf, ok: true, mr: false }, cc, n, clicks.concat('='), h);
              }
              for (let i = 0; i < bin.length; i++) {
                const old = mapsC[i].get(w);
                if (old === undefined || old.cost > cc) emit({ k: 'C', v: w, op: bin[i], M: n.M, f: true, ok: false, mr: false }, cc, n, clicks.concat(bin[i]), null);
              }
              const oldN = mapsN[nf ? 1 : 0].get(w);
              if (oldN === undefined || oldN.cost > cc) emit({ k: 'N', v: w, op: '', M: n.M, f: nf, ok: true, mr: false }, cc, n, clicks.concat('='), null);
              return false;
            };
            for (const l of operandLits) if (run(l.v, l.clicks, false)) break;
            if (!found && hasMR && n.M !== null) run(Number(n.M), ['MR'], true);
            if (found) break;
            if (hasMin && n.M !== n.v) emit({ k: 'C', v: n.v, op: n.op, M: n.v, f: true, ok: false, mr: false }, c + 1, n, ['Min'], null);
            emit({ k: 'R', v: NaN, op: '', M: n.M, f: true, ok: false, mr: false }, c + 1, n, ['AC'], null);
          }
        }
      }
      if (!found) return null;
      const chain = [];
      for (let p = found.n; p && p.par; p = p.par) chain.push(p.clicks);
      total.push(...chain.reverse().flat());
      found.hit.forEach(j => { solved[j] = true; });
      start = found.n; start.tag = undefined; start.par = null;
    }
    total.visited = visited; total.work = work;
    return total;
  }

  // Literals of up to 2 digits first (cheap, enough for most items), then 3 and 4. The work cap keeps
  // time and memory bounded (worst real item: ~5 s, ~300 MB in node); null = no solution found.
  const PASSES = [[2, 600000, 400000], [3, 600000, 2000000], [4, 1000000, 2500000]];
  function solve(item) {
    for (const [len, budget, cap] of PASSES) {
      const clicks = abstractSearch(item, len, budget, cap);
      if (clicks && verify(item, clicks)) return clicks.slice();
    }
    return null;
  }
  // Positions in the click list right after which a new number of the list is hit.
  function hitSteps(item, clicks) {
    let s = initState(NaN);
    const seen = new Set(), out = new Set();
    clicks.forEach((b, i) => {
      const r = simulate(s, b, item.answers);
      if (!r) return;
      r.hits.forEach(j => { if (!seen.has(j)) { seen.add(j); out.add(i); } });
      s = r.s;
    });
    return out;
  }

  // ================================================================ page
  const LAYOUT = new Set(['sin', 'sqrt', 'x^2', 'Min', 'MR', 'AC', 'cos', '1/x', '1', '2', '3', '+', 'tan', 'x!',
    '4', '5', '6', '-', 'acos', 'log', '7', '8', '9', '*', 'asin', 'atan', '0', '.', '=', '/']);
  const $ = id => document.getElementById(id);
  const answerEls = () => [...document.querySelectorAll('#answers .answer')];
  // Buttons are <div button="x^2" class="calculatorButton ...">; compare the attribute, not a selector.
  const buttonEl = b => [...document.querySelectorAll('#keyboard .calculatorButton')].find(e => e.getAttribute('button') === b) || null;
  const isDone = () => { const a = answerEls(); return a.length > 0 && a.every(e => e.classList.contains('correct')); };
  const cur = () => { const it = findItem(currentId()); return it && Array.isArray(it.item) && Array.isArray(it.answers) ? it : null; };

  // The DOM shows this item (the page rebuilds the list and the keys and calls updateItemUrl in one
  // go, 100 ms after "Další", so a stale screen never carries the new id).
  function onScreen(it) {
    const a = answerEls();
    if (a.length !== it.answers.length) return false;
    if (!a.every((e, i) => e.textContent.trim() === String(it.answers[i]).trim())) return false;
    return !!buttonEl('AC') && it.item.every(b => !LAYOUT.has(b) || !!buttonEl(b));
  }
  // Keys already pressed on this item (by the player or an earlier, interrupted run): the plan assumes
  // the fresh state of a new item. The display alone cannot tell (e.g. "0 +" still shows 0), so every
  // key click is noted (capture phase, before the page's handler).
  let touchedFor = null;
  if (typeof document.addEventListener === 'function') {
    document.addEventListener('click', e => {
      if (e.target && e.target.closest && e.target.closest('#keyboard .calculatorButton')) touchedFor = currentId();
    }, true);
  }
  const touched = () => touchedFor === currentId()
    || (($('display') || {}).textContent || '').trim() !== '0' || answerEls().some(e => e.classList.contains('correct'));

  let cache = null; // { id, clicks } – the search can take seconds, do it once per item
  let nextFor = null;

  function plan() {
    const it = cur();
    if (!it || !onScreen(it) || isDone()) return null;
    const id = currentId();
    if (!cache || cache.id !== id) cache = { id, clicks: solve(it) };
    if (!cache.clicks) return null;
    let clicks = cache.clicks;
    if (touched()) {
      // AC clears the numbers and the operator but not the "operator was just pressed" flag;
      // a digit clears that one, and a second AC gives exactly the state of a fresh item.
      const d = it.item.find(b => /^\d$/.test(b));
      clicks = (d ? ['AC', d, 'AC'] : ['AC']).concat(clicks);
    }

    let failed = false;
    // A real click on the key: the page's jQuery handler is delegated to document.
    const press = b => () => {
      if (failed || currentId() !== id || isDone()) return;
      const el = buttonEl(b);
      if (!el) { failed = true; return; }
      el.click();
    };
    const steps = clicks.map(b => ({ run: press(b) })); // the last click hits the last number

    // Human: thinks first, types numbers fluently, pauses after each hit number and before AC;
    // in total about as long as other students take (medianResponseTime, per item).
    const median = Math.min(240, (Number(it.medianResponseTime) || 40000) / 1000);
    const total = median * rand(0.6, 0.9);
    const hits = hitSteps(it, clicks);
    const isKey = b => /^[\d.]$/.test(b);
    const weights = clicks.map((b, i) => {
      if (i === 0) return 0;
      if (hits.has(i - 1) || b === 'AC') return 5;
      return isKey(b) && isKey(clicks[i - 1]) ? 0.6 : 1.5;
    });
    const unit = (total * 0.7) / (weights.reduce((s, w) => s + w, 0) || 1);
    const human = [{ wait: total * 0.3 }];
    clicks.forEach((b, i) => human.push({ wait: Math.min(12, Math.max(0.2, weights[i] * unit * rand(0.7, 1.3))), run: press(b) }));
    return { steps, human };
  }

  return {
    key: 'kalkulacka',
    get label() { return (kit.detectedKey === 'kalkulacka' && urlName()) || 'Rozbitá kalkulačka'; },
    unit: 'tlačítko',
    waitHint: 'Naťuká postup hned, poslední tlačítko stiskne až po odpočtu.',
    humanHint: 'Chvíli přemýšlí a ťuká tlačítka s pauzami po každém nalezeném čísle, zhruba za dobu běžnou u ostatních žáků.',
    ownPace: true,
    defaultTime: [15, 45],
    detect: () => hasScript('/exercise/kalkulacka.js'),
    ready: () => { const it = cur(); return !!it && onScreen(it) && !isDone(); },
    finished: isDone,
    next: async () => {
      // "Další" moves on unconditionally – even from an unsolved item – and the screen stays stale for
      // 100 ms, so click it only when solved and only once per item.
      const id = currentId();
      if (!isDone() || nextFor === id) return;
      nextFor = id;
      const btn = $('next');
      await until(() => visible(btn), 2500, 50); // slides down after the answers blink (~0.7 s)
      if (currentId() === id && btn) btn.click();
      await until(() => currentId() !== id || visible($('finalboard')), 3000, 50);
    },
    retry: false,
    plan,
    solve, // for tests in node
  };
});
