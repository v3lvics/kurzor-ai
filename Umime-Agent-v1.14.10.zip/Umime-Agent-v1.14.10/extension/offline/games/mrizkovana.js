// Mřížkovaná (mrizkovana.js + mrizkovana.{constants,utils,geometry,state,assignment,draggable,selectable}.js):
// geometry on a 6×6 grid (SVG). The player drags from node to node to draw segments, "clicks" a node
// (a drag that ends where it started) to mark a point, or – with config.uiOnlySelect – clicks given
// lines/points to select them. The page checks the board after every action (checkSolution: every
// path of one item.solutions[] entry must exist with an acceptable class, every point must be a user
// node); when it holds it logs the item, paints it .solvedline/.solvednode and shows "Další".
// Item data (store.items, from mrizkovanaLoadItems.php): { id, name, item: { text, problem, solutions,
// config }, explanation }. The solutions are in the data; what is not, is how to get there: a point or
// an end point that is not a grid node first has to appear as an intersection, so the solver below
// adds helper lines through it. Every candidate move is run through the page's own global state
// functions (composeNewStateForLine, checkSolution, isGeometryMaxed, …) before anything is entered.
// Moves are real mouse events on the page's touch surface (svg.draggable / the selectable click).
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { currentId, findItem, urlName, visible, until, sleep, rand, hasScript } = kit;
  const $ = id => document.getElementById(id);
  const warn = msg => console.warn('[neumimeto] Mřížkovaná: ' + msg);

  // ================================================================ the page's own geometry code
  // Classic scripts share one global scope, so the page's top-level functions and consts are visible
  // here by name (ReferenceError elsewhere -> null).
  function pageApi() {
    try {
      return {
        parseAssignment, generateGridNodes, generateGridLines, composeNewStateForNode, composeNewStateForLine,
        checkSolution, isGeometryMaxed, isEmptyObject, getNearestNode, getNearestLine, getConfigValue,
        findLine, isSameLine, extendLineCoordinates, Point,
        C: {
          RESOLUTION, GRID_WIDTH, GRID_HEIGHT, LEFT_EDGE, RIGHT_EDGE, TOP_EDGE, BOTTOM_EDGE,
          SNAP_THRESHOLD, TOUCH_SELECT_TOLERANCE, NODE_SELECT_RADIUS,
          NODE_STATE_COLLECTION, PATH_STATE_COLLECTION, NODE_GROUP, PATH_GROUP,
          NODE_CLASS, GRID_NODE_CLASS, GRID_LINE_CLASS, USER_NODE_CLASS, TASK_NODE_CLASS, SELECTED_NODE_CLASS,
          USER_LINE_CLASS, TASK_LINE_CLASS, SELECTED_LINE_CLASS,
        },
      };
    } catch (e) { return null; }
  }

  // ================================================================ solver
  // G: the page API above (in node: the same functions from a vm running the page's scripts).
  // Actions (canvas coordinates of the SVG): { type: 'drag', from, to } – segment from node to node;
  // { type: 'mark', at } – a drag that starts and ends on one node; { type: 'select', at, target }.
  function makeSolver(G) {
    const K = G.C, N = K.NODE_STATE_COLLECTION, P = K.PATH_STATE_COLLECTION;
    const STAMP = 1e9; // "updatedAt" – only used by the page to flash new geometry
    const cfg = (s, k) => G.getConfigValue(k, s);
    const pt = (x, y) => new G.Point(x, y);
    const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
    const MARGIN = 2; // px: the aimed node must be this much nearer than any other (pointer rounding)

    // The board right after the page shows the item (_0x5ce707: wipe, parseAssignment, set).
    function initialState(rawItem) {
      const s0 = {
        [N]: G.generateGridNodes(new Set([K.NODE_CLASS, K.GRID_NODE_CLASS]), N, K.NODE_GROUP),
        [P]: G.generateGridLines(new Set([K.GRID_LINE_CLASS]), P, K.PATH_GROUP),
      };
      return G.parseAssignment([rawItem], 0, s0, 1);
    }

    // _0x36f2e7: over the limit -> refused; otherwise accepted, and solved when checkSolution matches.
    function commit(prev, next) {
      if (!next) return { state: prev, refused: true };
      const max = G.isGeometryMaxed(next);
      if (max.diff > 0) return { state: prev, refused: true };
      return { state: next, done: !G.isEmptyObject(G.checkSolution(next)) };
    }
    // Touch surface drag (draggable.js): start = nearest node (no limit), end = nearest node within
    // SNAP_THRESHOLD, then _0x25c4e6.
    function applyDrag(s, from, to) {
      const a = G.getNearestNode(from, s[N]).point;
      const snap = G.getNearestNode(to, s[N]);
      if (!(snap.distance <= K.SNAP_THRESHOLD)) return { state: s, refused: true };
      const b = snap.point;
      let t = s;
      if (!a.equals(b)) {
        t = G.composeNewStateForNode(a, { add: [K.USER_NODE_CLASS] }, t, STAMP);
        t = t && G.composeNewStateForNode(b, { add: [K.USER_NODE_CLASS] }, t, STAMP);
        t = t && G.composeNewStateForLine(a, b, { add: [K.USER_LINE_CLASS] }, t, STAMP);
      } else {
        const add = cfg(s, 'uiOnlySelect') ? [K.USER_NODE_CLASS, K.SELECTED_NODE_CLASS] : [K.USER_NODE_CLASS];
        t = G.composeNewStateForNode(a, { add }, t, STAMP);
      }
      return commit(s, t);
    }
    // selectable.js click handler -> what it would toggle.
    function selectTarget(s, p) {
      const nodes = s[N].filter(n => n.classes.has(K.TASK_NODE_CLASS));
      const lines = s[P].filter(l => l.classes.has(K.TASK_LINE_CLASS));
      const ignN = cfg(s, 'uiOnlySelectIgnoreNodes'), ignL = cfg(s, 'uiOnlySelectIgnoreLines');
      const T = K.TOUCH_SELECT_TOLERANCE;
      const asNode = n => ({ node: n.point }), asLine = l => ({ line: l.geometry });
      if (ignN && !ignL) { const l = G.getNearestLine(p, lines); return l.distance <= T ? asLine(l) : null; }
      if (ignL && !ignN) { const n = G.getNearestNode(p, nodes); return n.distance <= T ? asNode(n) : null; }
      const n = G.getNearestNode(p, nodes), l = G.getNearestLine(p, lines);
      if (n.distance <= T && n.distance <= K.NODE_SELECT_RADIUS) return asNode(n);
      if (n.distance <= T && l.distance <= T) return n.distance <= l.distance ? asNode(n) : asLine(l);
      if (n.distance <= T) return asNode(n);
      if (l.distance <= T) return asLine(l);
      return null;
    }
    function applySelect(s, p) {
      const t = selectTarget(s, p);
      if (!t) return { state: s, refused: true };
      const st = Object.assign({}, s);
      const next = t.line
        ? G.composeNewStateForLine(t.line.p1, t.line.p2, { toggle: [K.SELECTED_LINE_CLASS] }, st, STAMP)
        : G.composeNewStateForNode(t.node, { toggle: [K.SELECTED_NODE_CLASS] }, st, STAMP);
      return commit(s, next);
    }
    function apply(s, a) {
      if (a.type === 'select') return applySelect(s, a.at);
      return applyDrag(s, a.type === 'mark' ? a.at : a.from, a.type === 'mark' ? a.at : a.to);
    }

    // ---- helpers on a state
    const nodeAt = (s, q, tol = 0.01) => { const n = G.getNearestNode(q, s[N]); return n.distance <= tol ? n.node : null; };
    // a node the pointer can hit for sure: every other node is clearly farther away
    function aimable(s, q) {
      let d1 = Infinity, d2 = Infinity;
      for (const n of s[N]) {
        const d = dist(q, n.geometry.p1);
        if (d < d1) { d2 = d1; d1 = d; } else if (d < d2) d2 = d;
      }
      return d1 <= 0.01 && d2 > MARGIN + 0.5;
    }
    // one solution element as a mini solution, judged by the page's checkSolution
    const holds = (s, part) => !G.isEmptyObject(G.checkSolution(Object.assign({}, s, { solutions: [part] })));
    const inside = q => q.x >= K.LEFT_EDGE - 0.01 && q.x <= K.RIGHT_EDGE + 0.01 && q.y >= K.TOP_EDGE - 0.01 && q.y <= K.BOTTOM_EDGE + 0.01;
    const collinear = (a, b, q) => {
      const len = dist(a, b);
      return len > 1 && Math.abs((b.x - a.x) * (q.y - a.y) - (b.y - a.y) * (q.x - a.x)) / len < 1e-6 * K.RESOLUTION;
    };
    const weight = n => (n.classes.has(K.TASK_NODE_CLASS) ? 2 : 0) + (n.classes.has(K.USER_NODE_CLASS) ? 1 : 0);
    // node pairs (both aimable) on one straight line through q, the given task/user points first
    function pairsThrough(s, q, avoid) {
      const ns = s[N].filter(n => aimable(s, n.geometry.p1) && dist(n.geometry.p1, q) > 0.5);
      const out = [];
      for (let i = 0; i < ns.length; i++) {
        for (let j = i + 1; j < ns.length; j++) {
          const a = ns[i].geometry.p1, b = ns[j].geometry.p1;
          if (!collinear(a, b, q)) continue;
          if (avoid && avoid.some(l => collinear(l.a, l.b, a) && collinear(l.a, l.b, b))) continue;
          out.push({ a, b, w: weight(ns[i]) + weight(ns[j]), len: dist(a, b) });
        }
      }
      // prefer given points, then short helpers (less clutter), deterministic
      return out.sort((x, y) => y.w - x.w || x.len - y.len);
    }
    // Make q a node: draw helper lines through it until the page adds an intersection node there.
    function ensureNode(s, q, acts) {
      if (nodeAt(s, q)) return s;
      if (!inside(q)) return null;
      const tryOne = (st, avoid) => {
        for (const c of pairsThrough(st, q, avoid).slice(0, 400)) {
          const r = applyDrag(st, c.a, c.b);
          if (r.refused || r.done) continue;
          if (nodeAt(r.state, q) && aimable(r.state, q)) return { r, c };
        }
        return null;
      };
      // q already lies on a drawn/grid line: one helper through it is enough
      const one = tryOne(s, null);
      if (one) { acts.push({ type: 'drag', from: one.c.a, to: one.c.b, helper: true }); return one.r.state; }
      // otherwise a first line through q, then a second one crossing it at q
      for (const c of pairsThrough(s, q, null).slice(0, 60)) {
        const r1 = applyDrag(s, c.a, c.b);
        if (r1.refused || r1.done) continue;
        const two = tryOne(r1.state, [c]);
        if (two) {
          acts.push({ type: 'drag', from: c.a, to: c.b, helper: true }, { type: 'drag', from: two.c.a, to: two.c.b, helper: true });
          return two.r.state;
        }
      }
      return null;
    }
    // points where a line meets the grid lines (to build a second node on it)
    function gridCrossings(p1, p2) {
      const out = [];
      for (let i = 0; i <= K.GRID_WIDTH; i++) {
        const x = K.LEFT_EDGE + i * K.RESOLUTION;
        if (Math.abs(p2.x - p1.x) > 1e-9) { const t = (x - p1.x) / (p2.x - p1.x); out.push(pt(x, p1.y + t * (p2.y - p1.y))); }
      }
      for (let i = 0; i <= K.GRID_HEIGHT; i++) {
        const y = K.TOP_EDGE + i * K.RESOLUTION;
        if (Math.abs(p2.y - p1.y) > 1e-9) { const t = (y - p1.y) / (p2.y - p1.y); out.push(pt(p1.x + t * (p2.x - p1.x), y)); }
      }
      return out.filter(inside);
    }
    // One path of the solution. With uiEvalSegmentsAsLines a whole line counts as soon as any segment
    // on it is drawn (its axis line); otherwise the drawn segment must have exactly these end points.
    function drawPath(s, path, acts) {
      if (holds(s, { [P]: [path] })) return s;
      const ext = G.extendLineCoordinates(path.p1, path.p2);
      const asLine = cfg(s, 'uiEvalSegmentsAsLines') && G.isSameLine(ext.p1, ext.p2, path.p1, path.p2);
      const tryDraw = (st, a, b) => {
        const r = applyDrag(st, a, b);
        return !r.refused && (r.done || holds(r.state, { [P]: [path] })) ? r : null;
      };
      if (asLine) {
        const on = st => st[N].filter(n => aimable(st, n.geometry.p1) && collinear(path.p1, path.p2, n.geometry.p1));
        for (let round = 0; round < 3; round++) {
          const ns = on(s).sort((x, y) => weight(y) - weight(x));
          for (let i = 0; i < ns.length; i++) {
            for (let j = i + 1; j < ns.length; j++) {
              const a = ns[i].geometry.p1, b = ns[j].geometry.p1;
              if (dist(a, b) < K.RESOLUTION * 0.4) continue; // too short to drag reliably
              const r = tryDraw(s, a, b);
              if (r) { acts.push({ type: 'drag', from: a, to: b }); return r.state; }
            }
          }
          // fewer than two nodes on it: make one where it crosses a grid line
          let next = null;
          for (const q of gridCrossings(path.p1, path.p2)) {
            if (nodeAt(s, q)) continue;
            const tmp = [];
            const st = ensureNode(s, q, tmp);
            if (st) { acts.push(...tmp); next = st; break; }
          }
          if (!next) return null;
          s = next;
        }
        return null;
      }
      for (const q of [path.p1, path.p2]) { s = ensureNode(s, q, acts); if (!s) return null; }
      const a = nodeAt(s, path.p1).geometry.p1, b = nodeAt(s, path.p2).geometry.p1;
      const r = tryDraw(s, a, b);
      if (!r) return null;
      acts.push({ type: 'drag', from: a, to: b });
      return r.state;
    }

    // ---- select mode: toggle exactly the solution's lines/points
    function selectPoint(s, want) {
      const same = t => t && (want.node ? t.node && dist(t.node, want.node) < 0.01
        : t.line && G.isSameLine(t.line.p1, t.line.p2, want.line.p1, want.line.p2));
      // robust to rounding of the pointer: the 4 neighbours within half a pixel must agree
      const ok = p => [[0, 0], [-0.5, -0.5], [0.5, -0.5], [-0.5, 0.5], [0.5, 0.5]].every(([dx, dy]) => same(selectTarget(s, pt(p.x + dx, p.y + dy))));
      if (want.node) return ok(want.node) ? want.node : null;
      const { p1, p2 } = want.line, len = dist(p1, p2);
      const nx = -(p2.y - p1.y) / len, ny = (p2.x - p1.x) / len;
      let best = null;
      for (let t = 0.1; t <= 0.9001; t += 0.04) {
        for (const off of [2.5, -2.5]) {
          const p = pt(p1.x + t * (p2.x - p1.x) + nx * off, p1.y + t * (p2.y - p1.y) + ny * off);
          if (!inside(p) || !ok(p)) continue;
          const score = -Math.abs(t - 0.5); // middle of the visible part
          if (!best || score > best.score) best = { p, score };
        }
      }
      return best && best.p;
    }
    function solveSelect(s, sol) {
      const wantNodes = (sol[N] || []).map(q => ({ node: q }));
      const wantLines = (sol[P] || []).map(l => ({ line: l }));
      const isWanted = el => el.node ? wantNodes.some(w => dist(w.node, el.node) < 0.01)
        : wantLines.some(w => G.isSameLine(w.line.p1, w.line.p2, el.line.p1, el.line.p2));
      const selectedNodes = s[N].filter(n => n.classes.has(K.SELECTED_NODE_CLASS)).map(n => ({ node: n.geometry.p1 }));
      const selectedLines = s[P].filter(l => l.classes.has(K.SELECTED_LINE_CLASS)).map(l => ({ line: l.geometry }));
      const isSelected = el => el.node ? selectedNodes.some(w => dist(w.node, el.node) < 0.01)
        : selectedLines.some(w => G.isSameLine(w.line.p1, w.line.p2, el.line.p1, el.line.p2));
      const toggles = [...selectedNodes, ...selectedLines].filter(el => !isWanted(el))
        .concat([...wantNodes, ...wantLines].filter(el => !isSelected(el)));
      const acts = [];
      for (const el of toggles) {
        const at = selectPoint(s, el);
        if (!at) return null;
        const r = applySelect(s, at);
        if (r.refused) return null;
        acts.push({ type: 'select', at, target: el.node ? 'bod' : 'přímka' });
        s = r.state;
      }
      return acts;
    }

    // -> list of actions whose last one completes the item (checked on the page's code), or null
    function solve(rawItem, base) {
      let s0 = base || initialState(rawItem);
      const sols = s0.solutions || [];
      let best = null;
      for (const sol of sols) {
        let acts = null;
        if (cfg(s0, 'uiOnlySelect')) acts = solveSelect(s0, sol);
        else {
          acts = [];
          let s = s0;
          for (const path of sol[P] || []) { s = drawPath(s, path, acts); if (!s) break; }
          if (s) {
            for (const q of sol[N] || []) {
              if (holds(s, { [N]: [q] })) continue;
              s = ensureNode(s, q, acts);
              if (!s) break;
              const at = nodeAt(s, q).geometry.p1;
              const r = applyDrag(s, at, at);
              if (r.refused) { s = null; break; }
              acts.push({ type: 'mark', at });
              s = r.state;
            }
          }
          if (!s) acts = null;
        }
        if (!acts) continue;
        // Replay on the page's code: must end solved; cut it where it gets solved
        let s = s0, okAt = -1;
        for (let i = 0; i < acts.length; i++) {
          const r = apply(s, acts[i]);
          if (r.refused) break;
          s = r.state;
          if (r.done) { okAt = i; break; }
        }
        if (okAt < 0) continue;
        acts = acts.slice(0, okAt + 1);
        if (!best || acts.length < best.length) best = acts;
      }
      return best;
    }

    return { solve, initialState, apply, selectTarget };
  }

  // ================================================================ page side
  // The page's StateProvider is private to its closure; its prototype is not. Every render calls
  // get(), so this notes the live provider (read only) – used to start from the real board.
  let live = null;
  try {
    if (typeof StateProvider === 'function' && !StateProvider.prototype.__neumimeto) {
      const get = StateProvider.prototype.get;
      StateProvider.prototype.get = function () { live = this; return get.apply(this, arguments); };
      StateProvider.prototype.__neumimeto = true;
    }
  } catch (e) {}

  const canvas = () => $('canvas');
  const surface = () => document.querySelector('#canvas rect.touchsurface');
  const cur = () => {
    const it = findItem(currentId());
    return it && it.item && it.item.problem && Array.isArray(it.item.solutions) ? it : null;
  };
  const isDone = () => !!document.querySelector('#canvas .solvedline, #canvas .solvednode') || visible($('next'));
  // Item drawn and faded in (fadeIn leaves opacity '' only when done), not evaluated yet.
  function idle(it) {
    const p = $('playground');
    return !!(p && it && surface()) && p.style.display !== 'none' && p.style.opacity === ''
      && ($('title') || {}).textContent === it.name && !isDone() && !visible($('finalboard'));
  }
  const liveState = id => {
    try { const s = live && live.get(); return s && String(s.id) === String(id) && s.solutions ? s : null; } catch (e) { return null; }
  };
  const liveLength = () => { try { return live ? live.length : -1; } catch (e) { return -1; } };

  // ---- pointer events
  // svg.draggable takes pageX/pageY through the inverse screen CTM of the touch surface, then the page
  // subtracts pageYOffset (draggable.js); selectable.js takes clientX/Y minus the surface's client rect.
  function clientForDrag(rect, c) {
    const m = rect.getScreenCTM();
    const q = new DOMPoint(c.x, c.y + window.pageYOffset).matrixTransform(m);
    return { x: q.x - window.pageXOffset, y: q.y - window.pageYOffset };
  }
  function clientForSelect(rect, c) {
    const r = rect.getBoundingClientRect();
    return { x: r.left + c.x, y: r.top + c.y };
  }
  // A MouseEvent truncates clientX/Y to whole pixels; a PointerEvent (still of type mousedown/…, so
  // the page's mouse listeners get it) keeps fractions, i.e. exactly the aimed point.
  const mouse = (type, target, p, buttons) => {
    const init = { bubbles: true, cancelable: true, view: window, clientX: p.x, clientY: p.y, button: 0, buttons, pointerType: 'mouse', isPrimary: true };
    return target.dispatchEvent(typeof PointerEvent === 'function' ? new PointerEvent(type, init) : new MouseEvent(type, init));
  };
  async function drag(from, to, animate) {
    const rect = surface();
    if (!rect) throw new Error('no touch surface');
    const a = clientForDrag(rect, from), b = clientForDrag(rect, to);
    mouse('mousedown', rect, a, 1);
    const n = animate ? Math.max(4, Math.round(Math.hypot(b.x - a.x, b.y - a.y) / 12)) : 2;
    const ms = animate ? rand(250, 650) : 0;
    for (let i = 1; i <= n; i++) {
      const t = i / n;
      mouse('mousemove', rect, { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t }, 1);
      if (ms) await sleep(ms / n);
    }
    mouse('mouseup', rect, b, 0);
  }
  function select(at) {
    const rect = surface();
    if (!rect) throw new Error('no touch surface');
    const p = clientForSelect(rect, at);
    mouse('mousedown', rect, p, 1);
    mouse('mouseup', rect, p, 0);
    mouse('click', rect, p, 0);
  }

  let solver = null;
  const getSolver = () => {
    if (solver) return solver;
    const G = pageApi();
    return G ? (solver = makeSolver(G)) : null;
  };
  let cache = null; // { id, acts }

  function plan() {
    const it = cur();
    if (!it || !idle(it)) return null;
    const S = getSolver();
    if (!S) { warn('nenašel jsem funkce stránky (parseAssignment, checkSolution, …).'); return null; }
    const id = currentId();
    // Start from the live board (it may already have lines on it). Without it, start from the item's
    // initial board – after "Od začátku" if something has been drawn already.
    const base = liveState(id);
    const dirty = !base && !!$('reset') && !$('reset').classList.contains('disabled');
    if (!cache || cache.id !== id || cache.len !== liveLength()) {
      cache = { id, len: liveLength(), acts: S.solve(it, base) };
    }
    const acts = cache.acts;
    if (!acts || !acts.length) {
      warn('řešení položky ' + id + ' (' + it.name + ') se nepodařilo sestrojit – nic nezadávám.');
      return null;
    }

    let failed = false;
    const open = () => !failed && currentId() === id && !isDone();
    const run = a => async ctx => {
      if (!open()) return;
      const before = liveLength();
      if (a.type === 'select') select(a.at);
      else await drag(a.type === 'mark' ? a.at : a.from, a.type === 'mark' ? a.at : a.to, ctx && ctx.animate);
      // the page re-renders synchronously; if it did not take the move, stop instead of guessing on
      if (before >= 0 && liveLength() === before && !isDone()) {
        failed = true;
        warn('stránka nepřijala tah ' + JSON.stringify(a) + ' – zastavuji.');
      }
    };
    const resetStep = { run: async () => { if (open()) { $('reset').click(); await sleep(30); } } };
    const steps = acts.map(a => ({ run: run(a) }));
    if (dirty) steps.unshift(resetStep);

    // Human: reads the task, then draws line by line (helper lines a bit faster), checks, finishes.
    const human = [{ wait: rand(3, 7) + Math.min(6, String(it.item.text || '').length / 40) }];
    if (dirty) human.push({ wait: rand(0.5, 1.2), ...resetStep });
    acts.forEach((a, i) => {
      const w = a.type === 'select' ? rand(1, 2.5) : a.type === 'mark' ? rand(1.5, 3) : a.helper ? rand(1.5, 3.5) : rand(2, 4.5);
      human.push({ wait: i === 0 ? rand(0.3, 1) : w, run: run(a) });
    });
    return { steps, human };
  }

  let nextFor = null;
  return {
    key: 'mrizkovana',
    get label() { return (kit.detectedKey === 'mrizkovana' && urlName()) || 'Mřížkovaná'; },
    unit: 'tah',
    waitHint: 'Narýsuje všechno hned kromě posledního tahu a ten udělá až po odpočtu.',
    humanHint: 'Chvíli čte zadání a pak rýsuje úsečku po úsečce (i pomocné čáry) svým tempem.',
    ownPace: true,
    defaultTime: [10, 40],
    detect: () => hasScript('/exercise/mrizkovana.js'),
    ready: () => { const it = cur(); return !!it && idle(it); },
    finished: isDone,
    next: async () => {
      // "Další" only works once the item is solved; click it once per item.
      const id = currentId();
      if (!isDone() || nextFor === id) return;
      nextFor = id;
      const btn = $('next');
      await until(() => visible(btn), 3000, 50);
      if (currentId() === id && btn) btn.click();
      await until(() => currentId() !== id || visible($('finalboard')), 3000, 50);
    },
    retry: false,
    plan,
    makeSolver, // for tests in node
  };
});
