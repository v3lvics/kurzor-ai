// Odvozování / Krok po kroku (chat.js): a chat whose `options` steps show two cards
// (#cards .card[data-index]); exactly one option has correct == "1". The page re-orders its own copy
// of the options (sorted by text, image-only steps shuffled), so the right card is found by content:
// each card is compared with the HTML getFormattedParts() (fcq.js, the page's renderer) builds for
// the options of hook.js's copy of the item (store.items). Nothing is clicked unless exactly one
// card matches the correct option and the cards on screen are exactly this step's options.
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { currentId, findItem, until, sleep, rand, hasScript, visible, urlName } = kit;
  const warn = (...a) => console.warn('[neumimeto] Odvozování:', ...a);

  const cards = () => [...document.querySelectorAll('#cards .card')];
  const nextBtn = () => [...document.querySelectorAll('.next')].find(visible) || null;
  const done = () => !!nextBtn(); // the page shows "Další" when the chat is over
  // Every answered options step leaves exactly one personB bubble without .wrong.
  const stepNo = () => document.querySelectorAll('#question .personB:not(.wrong)').length;
  const item = () => findItem(currentId());
  const optSteps = it => (it && Array.isArray(it.question) ? it.question.filter(s => s && s.type === 'options') : []);
  // New cards are on screen (the answered ones keep .clicked/.correct until the next step replaces them).
  const cardsReady = () => {
    const cs = cards();
    return cs.length > 0 && visible(document.getElementById('cards')) &&
      !cs.some(c => c.classList.contains('clicked') || c.classList.contains('correct') || c.classList.contains('wrong'));
  };

  // Normalised content: KaTeX nodes -> their data-expr, images -> path under /img/, rest -> text.
  function sig(el) {
    const c = el.cloneNode(true);
    c.querySelectorAll('[data-expr]').forEach(e => e.replaceWith('\u0001' + e.getAttribute('data-expr') + '\u0001'));
    c.querySelectorAll('img').forEach(e => e.replaceWith('\u0002' + String(e.getAttribute('src') || '').replace(/^.*?\/img\//, 'img/') + '\u0002'));
    return c.textContent.replace(/\s+/g, ' ').trim();
  }
  function optionSig(o) {
    const d = document.createElement('div');
    d.innerHTML = window.getFormattedParts(JSON.parse(JSON.stringify(o.option)));
    return sig(d);
  }
  const allImages = st => st.options.every(o => o.option.length === 1 && o.option[0][0] === 'img');

  // Index into cards() of the correct card, or -1 when it cannot be told safely.
  function correctCard() {
    const st = optSteps(item())[stepNo()];
    if (!st || !Array.isArray(st.options)) return -1;
    const good = st.options.filter(o => o.correct == 1); // the page compares loosely with 1
    if (good.length !== 1) return -1;
    const cs = cards();
    if (cs.length !== st.options.length) return -1;
    const cardSigs = cs.map(sig);
    const optSigs = st.options.map(optionSig);
    // The cards must be exactly this step's options (guards against a step-count mismatch).
    if ([...cardSigs].sort().join('\u0003') !== [...optSigs].sort().join('\u0003')) return -1;
    const want = optionSig(good[0]);
    const hits = cardSigs.map((s, i) => (s === want ? i : -1)).filter(i => i >= 0);
    if (hits.length === 1) return hits[0];
    // Identical texts (one known item): the page's order is a stable sort by the first part's text.
    if (hits.length > 1 && !allImages(st)) {
      const i = st.options.slice().sort((a, b) => String(a.option[0][1]).localeCompare(String(b.option[0][1]))).indexOf(good[0]);
      return hits.includes(i) ? i : -1;
    }
    return -1;
  }

  async function clickCard(el) {
    for (let t = 0; t < 40 && !el.classList.contains('clicked'); t++) {
      el.click(); // delegated jQuery click handler on .card
      if (!el.classList.contains('clicked')) await sleep(50);
    }
    return el.classList.contains('correct');
  }

  function plan() {
    const it = item();
    if (!it || done() || !cardsReady()) return null;
    const total = optSteps(it).length;
    const left = total - stepNo();
    if (left <= 0) return null;
    if (correctCard() < 0) return null; // first step must be readable right now
    let stopped = false;

    // One options step: answer it, then wait for the next cards or the end of the chat.
    const step = {
      run: async ctx => {
        if (stopped) return;
        if (!(await until(() => cardsReady() || done(), 8000, 30)) || done()) return;
        const k = stepNo();
        let i = correctCard();
        // Text is rendered by KaTeX right after the cards appear; give it a moment.
        if (i < 0) { await sleep(150); i = correctCard(); }
        if (i < 0) { stopped = true; return warn('správnou kartu nelze bezpečně určit, zastavuji', it.id, k); }
        if (ctx && ctx.fast) await sleep(rand(200, 450));
        const el = cards()[i];
        if (!(await clickCard(el))) { stopped = true; return warn('karta nebyla přijata jako správná', it.id, k); }
        await until(() => done() || (stepNo() > k && cardsReady()), 8000, 30);
      },
    };

    const steps = Array.from({ length: left }, () => step);
    // medianResponseTime is the per-step median here (3.7–16 s).
    const med = Math.min(Number(it.medianResponseTime) || 6000, 30000) / 1000;
    const human = steps.map((s, k) => ({ wait: med * (k ? rand(0.6, 1.1) : rand(0.8, 1.3)), ...s }));
    return { steps, human };
  }

  return {
    key: 'odvozovani',
    get label() { return (kit.detectedKey === 'odvozovani' && urlName()) || 'Odvozování'; },
    unit: 'krok',
    waitHint: 'Odpoví všechny kroky hned, poslední krok nechá na konec odpočtu.',
    humanHint: 'Každý krok si chvíli „přečte“ a odpoví zhruba za dobu běžnou u ostatních žáků.',
    ownPace: true,
    defaultTime: [10, 40],
    detect: () => hasScript('/exercise/chat.js'),
    ready: () => !!item() && (cardsReady() || done()),
    finished: done,
    next: async () => {
      // The medal screen that may follow is closed by content.js while Auto is on.
      if (await until(done, 3000, 50)) nextBtn().click();
    },
    retry: false,
    plan,
  };
});
