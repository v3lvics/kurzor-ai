// Porozumění (porozumeni.js): a text with 2-6 multiple-choice questions shown one by one.
// One solve = one text (the page calls updateItemUrl once per text, not per question).
// The answers come from the downloaded item (store.items): item.item.questions[k].correct is the
// index into q.options, and the options are drawn in that order (unless specs.sortOptions is random).
// Question k on screen = the "current" dot of #progress-counter, which the page moves in the same
// synchronous run in which it starts accepting answers. A wrong first click spoils the text's
// crystals, so the adapter only clicks when it is sure which question is shown.
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { currentId, findItem, urlName, lastShuffle, until, rand, hasScript } = kit;

  const $ = s => document.querySelector(s);
  const shown = el => !!el && getComputedStyle(el).display !== 'none';
  // fadeIn/fadeOut (animate.js) leave style.opacity '' only when the fade is over.
  const settled = el => shown(el) && el.style.display !== 'none' && el.style.opacity === '';
  const text = node => (node && node.textContent ? node.textContent : '').replace(/\s+/g, '');
  const sp = () => (typeof specs !== 'undefined' && specs) || {};

  const blocked = () => shown($('#block-board'));       // "Úlohu nelze opakovat stejný den" (logged-in users)
  const finalShown = () => shown($('#finalboard'));
  const isDone = () => shown($('#starboard')) || finalShown();
  const launchShown = () => settled($('#launch'));       // brainbox items: "Spustit otázky" first
  const options = () => [...document.querySelectorAll('#options .option')];
  const cardCorrect = () => !!$('#options .card.correct');
  const dots = () => [...document.querySelectorAll('#progress-counter .item-progress-dot')];
  const dotIndex = () => { const d = $('#progress-counter .item-progress-dot.current'); return d ? Number(d.dataset.index) : -1; };
  const itemBased = () => typeof evaluation === 'undefined' || evaluation !== 'medalBased';

  // The page accepts a click (state 'answering'): question faded in, not answered yet, and in
  // itemBased mode the current dot set (it is set together with state = 'answering').
  function answering() {
    if (isDone() || blocked()) return false;
    if (!settled($('#playground')) || !settled($('#question'))) return false;
    if (!options().length || cardCorrect()) return false;
    return itemBased() ? dotIndex() >= 0 : true;
  }

  const questions = () => { const it = findItem(currentId()); return (it && it.item && it.item.questions) || null; };
  const hasExplanation = q => !!(q && q.explanation && q.explanation.length); // then the page waits for "Další"

  // The question on screen -> { q, index } (index = DOM data-index of the right option), or null.
  function target() {
    const qs = questions();
    if (!qs) return null;
    let q = null;
    const k = dotIndex();
    if (k >= 0 && sp().sortQuestions !== 'random') q = qs[k];
    else {
      // No dots (medalBased) or shuffled questions: find it by the rendered stem, only if unique.
      const title = text($('#question-title'));
      const hits = title ? qs.filter(x => { try { return text(window.renderContentFormat(x.stem)) === title; } catch (e) { return false; } }) : [];
      q = hits.length === 1 ? hits[0] : null;
    }
    if (!q || !Array.isArray(q.options) || q.options.length !== options().length) return null;
    let index = Number(q.correct);
    if (sp().sortOptions === 'random') {
      // The page shuffles [{ option, correct, id }] in place right before drawing it (hook.js keeps it).
      const arr = lastShuffle(o => o && typeof o === 'object' && 'option' in o && 'correct' in o && 'id' in o);
      if (!arr || arr.length !== q.options.length) return null;
      index = arr.findIndex(o => o.correct);
    }
    return Number.isInteger(index) && index >= 0 && $('#options .option[data-index="' + index + '"]') ? { q, index } : null;
  }

  // Click the right option of the question on screen. The page ignores clicks until it is
  // 'answering' (no "clicked" mark then), so repeat until it marks the card; never click after
  // that – in state 'finished' a click on an option means "next question".
  async function answer() {
    if (launchShown()) $('#launch').click();
    if (!(await until(answering, 8000, 30))) return false;
    const t = target();
    if (!t) return false;
    const el = $('#options .option[data-index="' + t.index + '"]');
    return until(() => {
      if (!cardCorrect() && el.isConnected && !el.classList.contains('clicked')) el.click();
      return cardCorrect();
    }, 3000, 30);
  }

  // After a right answer: with an explanation the page shows "Další" and waits; without one it
  // moves on by itself after 500 ms. #next-question's handler only acts in state 'finished'
  // (so it can never skip a question or the starboard), hence it is safe to click it in both cases.
  async function advance(fast) {
    if (!cardCorrect()) return;
    const btn = $('#next-question');
    if (fast || shown(btn)) btn.click();
    if (!(await until(() => isDone() || !cardCorrect(), fast ? 1500 : 2500, 30)) && cardCorrect()) btn.click();
    if (isDone()) return;
    await until(() => isDone() || answering(), 3000, 30); // next question drawn (or the starboard)
  }

  // Consecutive "nelze opakovat" boards: "Další text" until a new text starts or the set ends.
  async function skipBlocked() {
    const id = currentId();
    for (let n = 0; n < 30; n++) {
      const titleEl = $('#block-board-title');
      const title = titleEl ? titleEl.textContent : '';
      const btn = $('#block-board [data-data=next-item]');
      if (!btn) return;
      btn.click();
      await until(() => currentId() !== id || finalShown() || ($('#block-board-title') || {}).textContent !== title, 2000, 50);
      // Another blocked text replaced the title (the board may even stay hidden – page quirk); go on.
      if (currentId() !== id || finalShown() || ($('#block-board-title') || {}).textContent === title) return;
    }
  }

  function plan() {
    if (blocked()) {
      const skip = { run: skipBlocked };
      return { steps: [skip], human: [{ wait: rand(1, 2.5), ...skip }] };
    }
    const qs = questions();
    if (!qs || !(launchShown() || target())) return null;
    // Questions left in this text, the current one included.
    const all = dots();
    let left;
    if (all.length) left = all.filter(d => d.classList.contains('unsolved')).length;
    else {
      const t = target();
      left = t ? qs.length - qs.indexOf(t.q) : qs.length;
    }
    if (left <= 0) return null;
    const rest = qs.slice(qs.length - left); // in page order (questions are not shuffled on any set seen)
    const it = findItem(currentId());
    const per = (Number(it && it.medianResponseTime) || 20000 * qs.length) / qs.length / 1000;

    let failed = false;
    const answerStep = async () => { if (!failed && !(await answer())) failed = true; };
    const steps = rest.map((_, i) => ({
      run: async () => {
        await answerStep();
        if (failed) return;
        await advance(true);
        if (i === rest.length - 1) await until(isDone, 3000, 30);
      },
    }));

    // Human: reads the text before the first question, then each question; reads an explanation
    // for a few seconds before "Další" (without one the page moves on by itself).
    const human = [];
    rest.forEach((q, i) => {
      const first = i === 0 && left === qs.length;
      human.push({ wait: per * (first ? rand(0.9, 1.3) : rand(0.5, 0.9)), run: answerStep });
      human.push({
        wait: hasExplanation(q) ? rand(2, 5) : 0,
        run: async () => {
          if (failed) return;
          await advance(false);
          if (i === rest.length - 1) await until(isDone, 3000, 30);
        },
      });
    });
    return { steps, human };
  }

  return {
    key: 'porozumeni',
    get label() { return (kit.detectedKey === 'porozumeni' && urlName()) || 'Porozumění'; },
    unit: 'otázka',
    waitHint: 'Odpoví hned na všechny otázky textu kromě poslední, tu zodpoví po odpočtu.',
    humanHint: 'Přečte text a odpovídá po otázkách zhruba tak dlouho jako ostatní žáci, u vysvětlení se zastaví.',
    ownPace: true,
    defaultTime: [20, 60],
    detect: () => hasScript('/exercise/porozumeni.js'),
    ready: () => blocked() || (!!questions() && (launchShown() || (answering() && !!target()))),
    finished: isDone,
    next: async () => {
      // Starboard -> "Další text" once (Enter there would also work, but twice would skip a text).
      if (!shown($('#starboard'))) return;
      const id = currentId();
      const titleEl = $('#block-board-title');
      const title = titleEl ? titleEl.textContent : '';
      const btn = $('#starboard [data-data=next-item]');
      if (btn) btn.click();
      await until(() => currentId() !== id || finalShown() || ($('#block-board-title') || {}).textContent !== title, 3000, 50);
      // The next text was already solved today: no updateItemUrl, so skip such texts here.
      if (currentId() === id && !finalShown() && ($('#block-board-title') || {}).textContent !== title) await skipBlocked();
    },
    retry: false,
    plan,
  };
});
