// Rozdělovačka (rozdelovacka.js): split a region of squares into equal (congruent) parts by painting
// every square with one of the colour buckets (one colour per part, `size` squares each).
// The item (store.items, by store.currentId) has only the squares: item.item = [[x, y], ...] and
// item.size; there is no stored solution, so the partition is searched for here. The page accepts
// the painting as soon as every square is painted and each colour group equals the red one up to
// rotation/reflection (it does not even check connectivity; the solver gives connected parts).
// Painting: click a bucket (.bucket[bucket=r|g|b|y|p]) to select it, then mousedown on a square
// (td#field<x>-<y>); the page redraws the whole grid after every square. See test/research/rozdelovacka.md.
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { currentId, findItem, urlName, visible, until, rand, hasScript } = kit;

  const COLORS = ['r', 'g', 'b', 'y', 'p']; // bucket order of the page (red first)
  const CLASS = { r: 'red', g: 'green', b: 'blue', y: 'yellow', p: 'purple' };
  const $ = id => document.getElementById(id);
  const cur = () => findItem(currentId());
  const field = (x, y) => $('field' + x + '-' + y);

  // ---------------------------------------------------------------- solver
  // Shape of a set of cells as the page compares it: shifted to (0, 0) and sorted.
  const norm = cells => {
    const mx = Math.min(...cells.map(c => c[0])), my = Math.min(...cells.map(c => c[1]));
    return cells.map(c => [c[0] - mx, c[1] - my]).sort((a, b) => a[1] - b[1] || a[0] - b[0]);
  };
  const keyOf = shape => shape.map(c => c[0] + ',' + c[1]).join(';');
  function orientations(shape) {
    const out = new Map();
    let s = shape;
    for (let f = 0; f < 2; f++) {
      for (let r = 0; r < 4; r++) { s = norm(s.map(([x, y]) => [y, -x])); out.set(keyOf(s), s); }
      s = norm(s.map(([x, y]) => [-x, y]));
    }
    return [...out.values()];
  }

  // cells: [[x, y]], size: squares per part -> [[[x, y], ...] per part] or null.
  function solve(cells, size, budget = 2e6) {
    const n = cells.length / size;
    if (!Number.isInteger(n) || n < 1 || n > COLORS.length) return null;
    const k = (x, y) => x + ',' + y;
    const inRegion = new Set(cells.map(c => k(c[0], c[1])));
    // Scan order: by row, then column (orientations are sorted the same way).
    const order = cells.slice().sort((a, b) => a[1] - b[1] || a[0] - b[0]);
    const rank = new Map(order.map((c, i) => [k(c[0], c[1]), i]));
    let work = 0;

    // Exact cover of the region with copies of one shape: always fill the first free square.
    function tile(shape) {
      const forms = orientations(shape);
      const used = new Set(), parts = [];
      function go(from) {
        if (++work > budget) return false;
        let i = from;
        while (i < order.length && used.has(k(order[i][0], order[i][1]))) i++;
        if (i === order.length) return true;
        const [cx, cy] = order[i];
        for (const f of forms) {
          // The form's first square (in scan order) must land on the first free square.
          const dx = cx - f[0][0], dy = cy - f[0][1];
          const placed = f.map(([x, y]) => [x + dx, y + dy]);
          if (!placed.every(([x, y]) => inRegion.has(k(x, y)) && !used.has(k(x, y)))) continue;
          placed.forEach(([x, y]) => used.add(k(x, y)));
          parts.push(placed);
          if (go(i + 1)) return true;
          parts.pop();
          placed.forEach(([x, y]) => used.delete(k(x, y)));
        }
        return false;
      }
      return go(0) ? parts : null;
    }

    // The part that holds the first square: every connected set of `size` squares that starts there
    // (no earlier square in scan order). Its shape is the shape of every part.
    const first = order[0];
    const tried = new Set();
    const seen = new Set();
    let found = null;
    (function grow(set) {
      if (found || work > budget) return;
      const id = set.map(c => rank.get(k(c[0], c[1]))).sort((a, b) => a - b).join(',');
      if (seen.has(id)) return;
      seen.add(id);
      if (set.length === size) {
        const shapeKey = orientations(norm(set)).map(keyOf).sort()[0];
        if (tried.has(shapeKey)) return;
        tried.add(shapeKey);
        found = tile(norm(set));
        return;
      }
      const inSet = new Set(set.map(c => k(c[0], c[1])));
      for (const [x, y] of set) {
        for (const [nx, ny] of [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]]) {
          const key = k(nx, ny);
          if (!inRegion.has(key) || inSet.has(key)) continue; // first = order[0], so no square is earlier
          grow(set.concat([[nx, ny]]));
          if (found) return;
        }
      }
    })([first]);
    return found;
  }

  // The page's own acceptance test (rozdelovacka.js _0x4cac0d/_0x51ed25/_0x4ff337/_0x3305ef),
  // reimplemented to double-check a solution before any square is painted.
  function pageAccepts(parts) {
    const pnorm = s => {
      let mx = 99, my = 99;
      s.forEach(c => { if (c[0] < mx) mx = c[0]; if (c[1] < my) my = c[1]; });
      return s.map(c => [c[0] - mx, c[1] - my]).sort();
    };
    const rot = s => (s.length ? s.map(c => [s[0][0] + (c[1] - s[0][1]), s[0][1] - (c[0] - s[0][0])]) : []);
    const flip = s => s.map(c => [-c[0], c[1]]);
    const original = JSON.stringify(pnorm(parts[0]));
    return parts.every(p => {
      let s = pnorm(p), ok = false;
      for (let f = 0; f < 2; f++) {
        for (let r = 0; r < 4; r++) { if (JSON.stringify(s) === original) ok = true; s = pnorm(rot(s)); }
        s = pnorm(flip(s));
      }
      return ok;
    });
  }

  // ---------------------------------------------------------------- page state
  const fields = () => [...document.querySelectorAll('#grid td.field')];
  const colorOf = el => { const c = COLORS.find(c => el.classList.contains(CLASS[c])); return c || (el.classList.contains('blank') ? '#' : null); };
  const restartShown = () => visible($('restart'));
  // The grid on screen is this item's: same squares, and the page still takes input (#restart is
  // hidden from the moment it accepts the painting until the next item is set up).
  function onScreen(it) {
    if (!it || !Array.isArray(it.item) || !restartShown() || visible($('finalboard'))) return false;
    const f = fields();
    return f.length === it.item.length && it.item.every(([x, y]) => { const el = field(x, y); return el && el.classList.contains('field'); });
  }
  const isDone = () => {
    const f = fields();
    return f.length > 0 && !restartShown() && f.every(el => !el.classList.contains('blank'));
  };

  const cache = new Map(); // item id -> parts (solving the same region again is pointless)
  function solution(it) {
    const id = String(it.id);
    if (!cache.has(id)) {
      const size = Number(it.size);
      let parts = solve(it.item.map(c => [Number(c[0]), Number(c[1])]), size);
      if (parts && !pageAccepts(parts)) parts = null;
      if (!parts) console.warn('[neumimeto] Rozdělovačka: no partition found for item', id);
      cache.set(id, parts);
    }
    return cache.get(id);
  }

  // Colours for the parts that keep as much of the current painting as possible (all parts are
  // equal, so any colour may go to any part).
  function assign(parts) {
    const now = parts.map(p => p.map(([x, y]) => colorOf(field(x, y))));
    const colors = COLORS.slice(0, parts.length);
    let best = null, bestScore = -1;
    (function perm(rest, chosen) {
      if (!rest.length) {
        const score = chosen.reduce((s, c, i) => s + now[i].filter(v => v === c).length, 0);
        if (score > bestScore) { bestScore = score; best = chosen; }
        return;
      }
      rest.forEach((c, i) => perm(rest.filter((_, j) => j !== i), chosen.concat(c)));
    })(colors, []);
    return best;
  }

  function mouse(el, type) {
    const r = el.getBoundingClientRect();
    el.dispatchEvent(new MouseEvent(type, {
      bubbles: true, cancelable: true, view: window, button: 0, buttons: type === 'mousedown' ? 1 : 0,
      clientX: r.left + r.width / 2, clientY: r.top + r.height / 2,
    }));
  }
  // mousedown paints (or, with the same colour selected, erases) a square and starts the page's
  // drag; the mouseup right after ends the drag so a real mouse passing over the grid paints nothing.
  function press(el) {
    mouse(el, 'mousedown');
    const grid = $('grid');
    if (grid) mouse(grid, 'mouseup');
  }
  const selected = () => { const b = document.querySelector('#buckets .bucket.selectedBucket'); return b ? b.getAttribute('bucket') : null; };
  // Clicking the selected bucket again deselects it, so click only when another one is selected.
  function selectBucket(c) {
    if (selected() === c) return true;
    const b = document.querySelector('#buckets .bucket[bucket="' + c + '"]');
    if (!b) return false;
    b.click();
    return selected() === c;
  }

  function plan() {
    const it = cur();
    if (!onScreen(it)) return null;
    const parts = solution(it);
    if (!parts) return null;
    const colors = assign(parts);
    const want = new Map();
    parts.forEach((p, i) => p.forEach(([x, y]) => want.set(x + ',' + y, colors[i])));
    const id = currentId();
    const open = () => currentId() === id && onScreen(it);

    // Erase squares painted with a wrong colour (select that colour, press the square).
    const wrong = it.item.map(([x, y]) => [Number(x), Number(y)])
      .filter(([x, y]) => { const c = colorOf(field(x, y)); return c && c !== '#' && c !== want.get(x + ',' + y); });
    const erase = () => {
      for (const [x, y] of wrong) {
        if (!open()) return;
        const el = field(x, y), c = colorOf(el);
        if (c && c !== '#' && c !== want.get(x + ',' + y) && selectBucket(c)) press(el);
      }
    };
    // Paint one square: select its colour and press it if it is still blank.
    const paint = ([x, y]) => () => {
      if (!open()) return;
      const el = field(x, y);
      if (el && colorOf(el) === '#' && selectBucket(want.get(x + ',' + y))) press(el);
    };
    // Squares still to paint, part by part (each part from its first square, like dragging it out).
    const todo = [];
    parts.forEach(p => p.forEach(c => { if (colorOf(field(c[0], c[1])) === '#' || wrong.some(w => w[0] === c[0] && w[1] === c[1])) todo.push(c); }));
    if (!todo.length) return null;
    const last = todo[todo.length - 1];
    const allButLast = { run: () => { erase(); todo.slice(0, -1).forEach(c => paint(c)()); } };
    const finish = { run: async () => { paint(last)(); await until(isDone, 1500, 30); } };

    // Human: looks at the region, then paints part by part with a short pause between colours.
    const median = (Number(it.medianResponseTime) || 45000) / 1000;
    const perSquare = Math.min(1.5, Math.max(0.15, (median * 0.35) / Math.max(1, todo.length)));
    const human = [{ wait: median * rand(0.35, 0.6), run: erase }];
    let prev = null;
    todo.forEach((c, i) => {
      const color = want.get(c[0] + ',' + c[1]);
      const pause = prev !== color ? rand(0.8, 2.5) : perSquare * rand(0.6, 1.4);
      prev = color;
      human.push(i === todo.length - 1 ? { wait: pause, ...finish } : { wait: pause, run: paint(c) });
    });
    return { steps: [allButLast, finish], human };
  }

  return {
    key: 'rozdelovacka',
    get label() { return (kit.detectedKey === 'rozdelovacka' && urlName()) || 'Rozdělovačka'; },
    unit: 'políčko',
    waitHint: 'Obarví hned všechna políčka kromě posledního, počká a pak obarví poslední.',
    humanHint: 'Chvíli si oblast prohlíží a pak barví jednu část po druhé zhruba za dobu běžnou u ostatních žáků.',
    ownPace: true,
    defaultTime: [15, 45],
    detect: () => hasScript('/exercise/rozdelovacka.js'),
    ready: () => { const it = cur(); return onScreen(it) && !!solution(it); },
    finished: isDone,
    next: async () => {
      // "Další" fades in after the blinking; its handler always moves on, so click it only once.
      const id = currentId();
      const btn = $('next');
      if (!(await until(() => visible(btn), 4000, 50))) return;
      if (isDone() && currentId() === id) btn.click();
    },
    retry: false,
    plan,
    _solve: solve,          // for test/research tests
    _pageAccepts: pageAccepts,
  };
});
