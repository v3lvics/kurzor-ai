// Doplňování textu / Diktáty (diktat.js, shared by umimematiku and umimecesky): a text with gaps,
// each gap offers two variants and the player picks one.
//   specs.type 'inline'   – every gap shows both variants in the text (.gap > .inlineVariant), any order;
//   specs.type 'dropdown' – (the default) one gap at a time (.gap-dropdown), its two variants pop up
//                           (.gap-dropdown-content .variant) and the next gap opens after a pick.
// The page writes the verdict into the DOM itself: each variant carries correct="1|0" (dropdown gaps
// carry variants="a|b|10" before they open) and it judges a click by exactly that attribute. The adapter
// reads it and cross-checks it with the downloaded text (store.items, universalLoadMedalPs.php), where
// the right variant is always the first one: "[right / wrong]" or "[right/wrong|explanation]".
// One solve = one text (updateItemUrl once per text). See test/research/diktat.md.
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { currentId, findItem, urlName, visible, until, sleep, rand, hasScript } = kit;
  let lastNext = 0; // time of the last "Další" (see next())

  const $ = s => document.querySelector(s);
  const sp = () => (typeof specs !== 'undefined' && specs) || {};
  const dropdown = () => sp().type !== 'inline'; // init() defaults a missing type to 'dropdown'
  const pageState = () => String(window.status); // the page's global `var status`
  const touch = () => typeof deviceType !== 'undefined' && (deviceType === 'tablet' || deviceType === 'phone');
  const gaps = () => [...document.querySelectorAll(dropdown() ? '#dictate .gap-dropdown' : '#dictate .gap')];
  const open = g => g.getAttribute('answered') === '0';
  const clean = s => String(s).replace(/[\s ​-‍]+/g, ' ').trim();
  // Text of a piece of the site's own markup, without running anything (template content is inert).
  const textOf = html => { const t = document.createElement('template'); t.innerHTML = String(html); return clean(t.content.textContent); };

  // The text being shown (its id is what updateItemUrl got).
  function shownDictate() {
    try {
      const d = typeof dictates !== 'undefined' && typeof dictateOffset !== 'undefined' ? dictates[dictateOffset] : null;
      return d && String(d.id) === currentId() ? d : null;
    } catch (e) { return null; }
  }

  // Right variants in gap order from the downloaded text: the gaps are the [a/b] (or [a/b|…]) outside
  // $…$ (KaTeX) parts, and the first variant is the right one (prepareDictate turns it into "|10").
  function expected() {
    const it = findItem(currentId()) || shownDictate();
    if (!it || typeof it.dictate !== 'string') return null;
    const out = [];
    it.dictate.split('$').forEach((part, i) => {
      if (i % 2) return;
      part.replace(/\[([^\/\]]+)\/([^|\]]*)(\|[^\]]*)?\]/g, (m, right) => { out.push(textOf(right.replace(/•/g, ' '))); return m; });
    });
    return out;
  }

  // -> [{ id, right: text, el(): element to click or null }] for every gap, or null if anything is unclear.
  function read() {
    const all = gaps();
    if (!all.length) return null;
    const list = [];
    for (const g of all) {
      let right = null;
      if (!dropdown()) {
        const v = [...g.querySelectorAll('.inlineVariant')];
        if (open(g)) {
          const ok = v.filter(x => x.getAttribute('correct') === '1');
          if (v.length !== 2 || ok.length !== 1) return null;
          right = clean(ok[0].textContent);
        }
      } else if (open(g)) {
        const parts = String(g.getAttribute('variants') || '').split('|');
        if (parts.length !== 3 || !/^(10|01)$/.test(parts[2])) return null;
        right = textOf(parts[2] === '10' ? parts[0] : parts[1]);
      }
      list.push({ id: g.id, right });
    }
    return list;
  }

  const warned = new Set();
  const warn = (id, msg) => { if (!warned.has(id + msg)) { warned.add(id + msg); console.warn('[neumimeto] Doplňování textu: ' + msg, id); } };

  // Gaps still to fill, checked against the data; null while not ready or when the two disagree.
  function target() {
    const id = currentId();
    const list = read();
    if (!list) return null;
    const exp = expected();
    if (exp && exp.length === list.length) {
      const bad = list.findIndex((g, i) => g.right !== null && g.right !== exp[i]);
      if (bad >= 0) { warn(id, 'gap ' + bad + ' "' + list[bad].right + '" ≠ data "' + exp[bad] + '"'); return null; }
    } else if (exp) warn(id, exp.length + ' gaps in the data, ' + list.length + ' on screen – using the page\'s marks only');
    return list.filter(g => g.right !== null);
  }

  const answering = () => pageState() === 'answering' && !!shownDictate() && visible($('#playground'));

  // Tablets/phones get touch handlers instead of clicks (touchstart arms, touchend picks).
  function press(el) {
    if (!touch()) return el.click();
    el.dispatchEvent(new Event('touchstart', { bubbles: true }));
    el.dispatchEvent(new Event('touchend', { bubbles: true }));
  }

  // Pick the right variant of one gap, if that gap is still open and its variant is the expected one.
  function pick(id, right) {
    const g = document.getElementById(id);
    if (!g || !open(g) || !answering()) return false;
    const v = dropdown()
      ? g.querySelector('.gap-dropdown-content .variant[correct="1"]')
      : g.querySelector('.inlineVariant[correct="1"]');
    if (!v || clean(v.textContent) !== right) { warn(currentId(), 'gap ' + id + ' not ready'); return false; }
    press(v);
    return !open(g);
  }

  const isDone = () => {
    const all = gaps();
    return pageState() === 'finished' && all.length > 0 && !all.some(open);
  };

  function plan() {
    if (!answering()) return null;
    const todo = target();
    if (!todo || !todo.length) return null;
    const docId = currentId();
    let failed = false;
    const step = g => async () => {
      if (failed || currentId() !== docId) return;
      // A dropdown gap opens only after the previous pick; give it a moment.
      if (dropdown()) await until(() => { const el = document.getElementById(g.id); return !el || !open(el) || !!el.querySelector('.gap-dropdown-content .variant'); }, 2000, 25);
      if (!pick(g.id, g.right)) failed = true;
    };
    const last = todo[todo.length - 1];
    const steps = [
      { run: async () => { for (const g of todo.slice(0, -1)) await step(g)(); } },
      { run: async () => { await step(last)(); await until(isDone, 2000, 30); } },
    ];

    // Human: reads the beginning, then picks gap by gap at about the pace of other pupils.
    const d = shownDictate();
    const total = gaps().length || todo.length;
    const median = (Number(d && d.medianResponseTime) || 8000 * total) / 1000;
    const per = median / total;
    const human = [{ wait: per * rand(0.4, 0.8) }];
    todo.forEach((g, i) => human.push({
      wait: per * rand(0.5, 1.1),
      run: i === todo.length - 1 ? steps[1].run : step(g),
    }));
    return { steps, human };
  }

  return {
    key: 'diktat',
    get label() { return (kit.detectedKey === 'diktat' && urlName()) || 'Doplňování textu'; },
    unit: 'mezera',
    waitHint: 'Doplní hned všechny mezery kromě poslední, počká a pak doplní i ji.',
    humanHint: 'Čte text a doplňuje mezery jednu po druhé zhruba tempem ostatních žáků.',
    ownPace: true,
    defaultTime: [10, 40],
    detect: () => hasScript('/exercise/diktat.js'),
    ready: () => answering() && !!target() && target().length > 0,
    finished: isDone,
    next: async () => {
      // "Další" (or Enter) runs nextDictate(), which acts only in state 'finished' – a second press is
      // ignored, so it can never skip a text. A medal screen may come first (content.js closes it in Auto).
      // The set never ends (medalBased: after the last text the page downloads it again), so Auto in
      // mode Ihned would otherwise go through hundreds of texts and downloads a minute: keep ≥ 1.5 s
      // between texts and a few seconds before each new download.
      if (!isDone()) return;
      const id = currentId();
      let wait = lastNext + rand(1500, 2500) - Date.now();
      try { if (dictateOffset >= dictates.length - 1) wait = Math.max(wait, rand(3000, 5000)); } catch (e) {}
      if (wait > 0) await sleep(wait);
      lastNext = Date.now();
      const btn = $('#playground .next');
      if (btn && isDone() && currentId() === id) press(btn);
    },
    retry: false,
    plan,
  };
});
