// Roboti (roboti.js): a race against 3 robots, 4 levels (7/9/11/13 correct answers to win).
// Every question is a two-option binary choice in #question-wrapper; the first click of a question
// moves the player +1 (right) or −1 (wrong). displayItem() shuffles image-only options in place and
// hook.js keeps the item it drew (store.shownItem), so shownItem.options[i] is DOM option i.
// One plan() = one level. The page never calls updateItemUrl, so next() emits the runner's 'item' event.
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { store, until, sleep, rand, hasScript, urlName } = kit;
  const $ = s => document.querySelector(s);
  const shown = el => !!el && getComputedStyle(el).display !== 'none';
  const norm = s => String(s || '').replace(/\s+/g, '');
  const spec = () => (typeof specs !== 'undefined' ? specs : null);
  const level = () => Number(window.level);
  const maxLevel = () => Number(spec() && spec().maxLevel) || 4;

  const wrapper = () => document.getElementById('question-wrapper');
  const opt = i => wrapper() && wrapper().querySelector('[data-data=option][data-index="' + i + '"]');
  const answered = () => [0, 1].some(i => opt(i) && opt(i).classList.contains('correct'));

  const allDone = () => shown($('#finalboard')) || level() > maxLevel();
  const boardBtn = () => ['#board-start', '#board-win', '#board-lose'].map(s => $(s)).filter(shown)
    .map(b => b.querySelector('[data-data=load-level]')).filter(Boolean)[0] || null;
  const won = () => shown($('#board-win')) || allDone();
  const lost = () => shown($('#board-lose'));
  // A race is on: track drawn for this level (the victory mark is cleared by the next redraw).
  const running = () => shown($('#question-frame')) && !!$('#race-track race-track-row') && !$('#race-track race-track-row[victory]');
  const raceOver = () => !!$('#race-track race-track-row[victory]') || won() || lost();
  // The question accepts clicks: faded in (fadeIn leaves opacity '') and not answered yet.
  const questionOpen = () => {
    const w = wrapper();
    return running() && !!w && w.style.display !== 'none' && w.style.opacity === '' && !answered() && !!store.shownItem;
  };

  // Same rendering as displayOption(): text and image sources must match what is on screen.
  function signature(node) {
    if (!node) return null;
    const imgs = node.nodeName === 'IMG' ? [node] : node.querySelectorAll ? [...node.querySelectorAll('img')] : [];
    return norm(node.textContent) + '|' + imgs.map(i => i.getAttribute('src')).join(',');
  }
  function correctIndex(item) {
    const opts = item && Array.isArray(item.options) ? item.options : null;
    if (!opts || opts.length !== 2) return -1;
    const right = [0, 1].filter(i => opts[i] && opts[i].correct); // the page checks truthiness
    if (right.length !== 1) return -1;
    // Cross-check both options against the screen before clicking (a wrong click costs a step).
    for (const i of [0, 1]) {
      if (signature(window.renderContentFormat(opts[i].option)) !== signature(opt(i))) return -1;
    }
    return right[0];
  }

  // Click until the page takes it: it ignores clicks while `answering` is false (fades).
  async function answer(i, item) {
    const el = opt(i);
    const end = Date.now() + 4000;
    while (el && Date.now() < end && store.shownItem === item && !raceOver()) {
      el.click();
      if (el.classList.contains('correct')) return 'ok';
      if (el.classList.contains('wrong')) return 'wrong';
      await sleep(25);
    }
    return el && el.classList.contains('correct') ? 'ok' : 'skip';
  }

  async function startIfNeeded() {
    if (running()) return true;
    const btn = boardBtn();
    if (!btn) return false;
    btn.click();
    return until(questionOpen, 8000, 30);
  }

  // pace.delay(): ms between the question appearing and the click. The page's throttle punishes
  // answers ≤ 350 ms after the question appeared (it then makes every next question wait longer),
  // so even the fastest pace stays above that.
  async function play(pace) {
    try {
      if (!(await startIfNeeded())) return console.warn('[neumimeto] Roboti: závod se nespustil.');
      const L0 = level();
      const end = Date.now() + 10 * 60 * 1000;
      while (Date.now() < end && level() === L0 && !raceOver()) {
        if (!questionOpen()) { await sleep(20); continue; }
        const item = store.shownItem;
        const i = correctIndex(item);
        if (i < 0) return console.warn('[neumimeto] Roboti: nelze bezpečně určit správnou odpověď, zastavuji.', item);
        await sleep(pace.delay());
        if (store.shownItem !== item || raceOver()) continue;
        const res = await answer(i, item);
        if (res === 'wrong') return console.warn('[neumimeto] Roboti: odpověď nebyla správná, zastavuji.', item);
        // The next question replaces this one (the page clears the 'correct' mark when it draws it).
        if (res === 'ok') await until(() => !answered() || raceOver() || level() !== L0, 6000, 20);
      }
    } catch (e) {
      console.warn('[neumimeto] Roboti:', e);
      return;
    }
    // victory(): 650 ms + 250 ms fade, then the win / lose board (or the final board)
    await until(() => won() || lost(), 6000, 50);
  }

  // Robots need ~78–214 s (fastest one, last level) and cannot reach 13 in under ~40 s; even the
  // human pace (~2.7 s per question incl. the page's pauses) wins in ~35 s.
  const PACE = {
    fast: { delay: () => rand(450, 750) },
    calm: { delay: () => rand(800, 1600) },
    human: { delay: () => (Math.random() < 0.1 ? rand(2800, 4000) : rand(1000, 2600)) },
  };

  function plan() {
    if (allDone()) return null;
    const racing = running();
    if (!racing && !boardBtn()) return null;
    const pick = ctx => (ctx && ctx.fast ? PACE.fast : PACE.calm);
    let job = null;
    // Race already on: Počkat must not stand still while the robots run, so the first step starts
    // answering and the last one only waits for the end of the race.
    const steps = racing
      ? [{ run: ctx => { job = play(pick(ctx)); } }, { run: () => job }]
      : [{ run: ctx => play(pick(ctx)) }];
    const human = [{ wait: racing ? rand(0.2, 0.5) : rand(1.5, 4) }, { wait: 0, run: () => play(PACE.human) }];
    return { steps, human };
  }

  return {
    key: 'roboti',
    get label() { return (kit.detectedKey === 'roboti' && urlName()) || 'Roboti'; },
    unit: 'level',
    waitHint: 'Po odpočtu spustí závod a odpovídá správně, dost rychle na to, aby roboty porazil.',
    humanHint: 'Odpovídá správně s lidskými prodlevami, ale pořád tak rychle, že roboty předběhne.',
    ownPace: true,
    defaultTime: [3, 8],
    detect: () => hasScript('/exercise/roboti.js'),
    ready: () => running() || !!boardBtn() || allDone(),
    // Won level (win board or the final board). Start / lose boards count as "not done".
    finished: won,
    next: async () => {
      if (allDone()) return;
      const btn = await until(boardBtn, 4000, 50) && boardBtn();
      if (!btn) return;
      btn.click();
      await until(questionOpen, 8000, 30);
      // No updateItemUrl in this game: tell the runner a new round started (Auto goes on).
      store.listeners.forEach(f => { try { f('item', 'roboti-level-' + level()); } catch (e) {} });
    },
    retry: false,
    plan,
  };
});
