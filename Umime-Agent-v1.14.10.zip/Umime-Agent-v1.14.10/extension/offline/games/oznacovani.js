// Označování (klikacka.js): click the right areas of a picture or a text, then "Vyhodnoť".
// The right areas are only in the downloaded item (store.items, by store.currentId):
//   image – item.correct = id postfixes, the clickable element is <g id="selectable-<areas><postfix>">;
//   text / code64 – the page marks them inside item.content; the indices are recomputed below with
//   the page's own regexes and checked against the number of areas on screen.
// The page's `finished` flag is private; #playground gets class "finished" once it has evaluated.
(window.__neumimetoGames = window.__neumimetoGames || []).push(kit => {
  const { currentId, findItem, urlName, visible, until, rand, hasScript } = kit;

  const $ = id => document.getElementById(id);
  const pg = () => $('playground');
  const box = () => $('question-content');
  const cur = () => findItem(currentId());
  const progressive = () => typeof specs !== 'undefined' && !!specs.progressiveEvaluation;
  const isDone = () => !!pg() && pg().classList.contains('finished');

  // Indices of the right areas for text items, a copy of the page's prepareTokens/… regexes
  // (counting only). A token list ending with a space has an extra empty area – the page counts it too.
  function textPlan(item) {
    const correct = [];
    let index = 0;
    const content = String(item.content || '');
    if (item.areas === 'tokens') {
      content.replace(/\s+/g, ' ')
        .replace(/ ?((<[^>]*> ??)+) ?/g, (m, html) => html.replace(/> </g, '><'))
        .split(/((?:<[^>]*>)+)/g).forEach(chunk => {
          if (chunk.startsWith('<') && chunk.endsWith('>')) return;
          chunk.split(' ').forEach(tok => { if (tok.match(/\[.*]/)) correct.push(index); index++; });
        });
    } else if (item.areas === 'explicit') {
      content.replace(/\[\[\[(.*?)]]](?!])|\(\(\((.*?)\)\)\)(?!\))/g, m => { if (m.startsWith('[[[')) correct.push(index); index++; return m; });
    } else if (item.areas === 'sentences') {
      content.replace(/(.*?(?:[.?!]|[.,?!]“)]*)(\s+|$)/g, (m, s) => { if (s.match(/\[.*]/)) correct.push(index); index++; return m; });
    } else if (item.areas === 'commas') {
      content.replace(/\s+/g, ' ').replace(/ ?((<[^>]*> ?)+) /g, (m, h) => ` ${h.replace(/> </g, '><')}`)
        .split(/((?:<[^>]*>)+)/g).forEach(chunk => {
          if (chunk.startsWith('<') && chunk.endsWith('>')) return;
          chunk.replace(/,? /g, m => { if (m.startsWith(',')) correct.push(index); index++; return m; });
        });
    } else return null;
    return { total: index, correct };
  }

  // Code items (not seen on the math site): one area per line, right lines carry a marker comment.
  function codePlan(item) {
    const regex = { python: /^([^#]*)###(.*)$/, html: /^(.*)<!--(.*)-->\s*$/, css: /^(.*)\/\*\*\*(.*)\*\/\s*$/ }[item.language];
    if (!regex || typeof window.b64DecodeUnicode !== 'function') return null;
    const lines = window.b64DecodeUnicode(item.content).split('\n');
    return { total: lines.length, correct: lines.map((l, i) => (regex.test(l) ? i : -1)).filter(i => i >= 0) };
  }

  // -> { areas: [right elements], all: [every area] } or null while the DOM does not match the item.
  function target(it) {
    if (!box()) return null;
    const all = [...box().querySelectorAll('.selectable-area')];
    if (it.type === 'image') {
      // Many items share one SVG, so the ids alone could be the previous item's; idle() rules that out.
      const byPostfix = p => document.getElementById('selectable-' + it.areas + p);
      const correct = [].concat(it.correct || []);
      if (it.distractors && it.distractors.some(p => !byPostfix(p))) return null;
      const areas = correct.map(byPostfix);
      return areas.every(Boolean) && all.length ? { areas, all } : null;
    }
    const p = it.type === 'text' ? textPlan(it) : it.type === 'code64' ? codePlan(it) : null;
    if (!p || all.length !== p.total) return null; // not rendered yet, or our count differs from the page's
    const areas = p.correct.map(i => box().querySelector('.selectable-area[data-index="' + i + '"]'));
    return areas.every(Boolean) ? { areas, all } : null;
  }

  // New item fully set up: #playground has faded in (fadeIn leaves style.opacity '' only when done;
  // while fading out, or before the new item is drawn, display is 'none'), it is not evaluated yet
  // and it shows this item's content type. The page accepts clicks only after the fade-in.
  function idle() {
    const p = pg(), it = cur();
    return !!(p && it) && p.style.display !== 'none' && p.style.opacity === ''
      && !p.classList.contains('finished') && p.classList.contains('content-' + it.type)
      && !visible($('finalboard'));
  }

  const marked = el => /\b(selected|correct|wrong-selected|wrong-missed)\b/.test(el.getAttribute('class') || '');
  // SVG <g> has no .click(); a bubbling click reaches the page's listener on #question-frame,
  // which takes event.target.closest('.selectable-area').
  function fire(el) {
    const r = el.getBoundingClientRect();
    el.dispatchEvent(new MouseEvent('click', {
      bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2,
    }));
  }

  function plan() {
    const it = cur();
    if (!it || !idle()) return null;
    const t = target(it);
    if (!t) return null;
    const id = currentId();
    // Any click in #question-frame on an evaluated item means "next item" – and a second one would
    // skip an item. So every click first checks that this item is still open.
    const open = () => currentId() === id && idle();
    const select = el => () => { if (open() && !marked(el)) fire(el); };
    const toggle = el => () => { if (open()) fire(el); }; // misclick and its fix (non-progressive only)
    const median = (Number(it.medianResponseTime) || 10000) / 1000;
    const n = t.areas.length;
    const perArea = Math.min(4, Math.max(0.5, (median * 0.5) / Math.max(1, n)));

    if (progressive()) {
      // Every click is judged at once; the last right one finishes the item (no "Vyhodnoť").
      if (!n) {
        // Nothing to mark: "Nevím" is the only way to end it, and it counts as right.
        const giveUp = { run: () => { if (open()) $('giveup').click(); } };
        return { steps: [giveUp], human: [{ wait: median * rand(0.6, 1.0) }, { wait: 0, ...giveUp }] };
      }
      const steps = t.areas.map(el => ({ run: select(el) }));
      const human = [{ wait: median * rand(0.4, 0.6) }];
      t.areas.forEach(el => human.push({ wait: perArea * rand(0.6, 1.4), run: select(el) }));
      return { steps, human };
    }

    const evaluate = { run: () => until(() => { if (open()) $('evaluate').click(); return isDone(); }, 2000, 50) };
    const selectAll = { run: () => t.areas.forEach(el => select(el)()) };
    const human = [{ wait: median * rand(0.35, 0.55) }];
    const wrong = t.all.filter(el => !t.areas.includes(el));
    const slip = wrong.length && n && Math.random() < 0.1 ? Math.floor(Math.random() * n) : -1;
    t.areas.forEach((el, i) => {
      human.push({ wait: perArea * rand(0.6, 1.4), run: select(el) });
      if (i === slip) {
        // Occasionally marks a wrong area and takes it back a moment later.
        const w = wrong[Math.floor(Math.random() * wrong.length)];
        human.push({ wait: rand(0.6, 1.5), run: toggle(w) });
        human.push({ wait: rand(0.8, 2), run: () => { if (w.classList.contains('selected')) toggle(w)(); } });
      }
    });
    human.push({ wait: rand(0.8, 2), ...evaluate });
    // With nothing to mark the plan is just "Vyhodnoť" (the page then says nothing should be marked).
    return { steps: n ? [selectAll, evaluate] : [evaluate], human };
  }

  return {
    key: 'oznacovani',
    get label() { return (kit.detectedKey === 'oznacovani' && urlName()) || 'Označování'; },
    unit: 'oblast',
    waitHint: 'Označí správné oblasti hned, počká a pak klikne na Vyhodnoť.',
    humanHint: 'Chvíli čte zadání, označuje oblasti jednu po druhé a vyhodnotí zhruba za dobu běžnou u ostatních žáků.',
    ownPace: true,
    defaultTime: [5, 20],
    detect: () => hasScript('/exercise/klikacka.js'),
    ready: () => { const it = cur(); return !!it && idle() && !!target(it); },
    finished: isDone,
    next: async () => {
      // "Další" fades in after the explanation; click it once (a second click would skip an item).
      const id = currentId();
      const btn = $('next');
      if (!(await until(() => visible(btn), 4000, 50))) return;
      if (isDone() && currentId() === id) btn.click();
      // A medal screen may block the next item until it is closed (content.js also closes it in Auto).
      await until(() => visible($('finalboard')) || currentId() !== id, 3000, 50);
      const close = visible($('finalboard')) && document.querySelector('#finalboard [data-data=close-finalboard]:not(.d-none)');
      if (close) close.click();
    },
    retry: false,
    plan,
  };
});
