// Runs in the page (MAIN world), so it can use the exercise script's globals
// (currentPlan, finished, nextItem, prepareGame, clickFence / cars, updatePlan, ...).
(function () {
  if (window.__umimeSolver) return;
  window.__umimeSolver = true;

  // Keep in sync with manifest.json and CHANGELOG.md.
  // New task type: +0.1, UI change or bugfix: +0.01.
  const VERSION = '1.78';
  window.__neumimetoVersion = VERSION;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rand = (a, b) => a + Math.random() * (b - a);
  const pickRandom = arr => arr[Math.floor(Math.random() * arr.length)];
  const hasScript = part => [...document.scripts].some(s => s.src.includes(part));
  const userError = msg => Object.assign(new Error(msg), { user: true });
  // Filled by hook.js (document_start): downloaded items, current item id, and what the page
  // rendered or shuffled for it.
  const store = (window.__neumimetoData = window.__neumimetoData || {});
  const currentId = () => String(store.currentId || location.pathname.split('/').filter(Boolean).pop());
  const findItem = id => (store.items || []).find(it => String(it.id) === String(id)) || null;
  // Exercise name from the URL, without the level: /pocitani-xyz-2-uroven/123 -> pocitani-xyz
  const urlName = () => (location.pathname.split('/').filter(Boolean)[0] || '').replace(/-\d+-uroven$/, '');
  // Newest array the page shuffled for the current item that looks like `test(element)`.
  const lastShuffle = test => {
    const list = (store.shuffles || []).filter(s => String(s.id) === currentId() && s.arr.length && s.arr.every(test));
    return list.length ? list[list.length - 1].arr : null;
  };
  const visible = el => !!el && getComputedStyle(el).display !== 'none';
  // code/key for the newer exercises, keyCode/which for the ones that read the legacy fields (chat.js).
  const pressEnter = () => document.dispatchEvent(new KeyboardEvent('keydown', { code: 'Enter', key: 'Enter', keyCode: 13, which: 13, bubbles: true }));

  // ---------------------------------------------------------------- Ploty
  const ploty = (function () {
    function readGrid() {
      const grid = [];
      for (let y = 1; y < planHeight; y += 2) {
        const row = [];
        for (let x = 1; x < planWidth; x += 2) {
          const ch = currentPlan[y][x];
          row.push(/^[0-9]$/.test(ch) ? Number(ch) : -1);
        }
        grid.push(row);
      }
      return grid;
    }

    // Wanted fence state per page coordinate "x-y" -> true/false.
    function targetFromSolver() {
      const sol = window.solveSlitherlink(readGrid());
      if (!sol) return null;
      const want = {};
      sol.h.forEach((row, r) => row.forEach((on, c) => { want[(2 * c + 1) + '-' + (2 * r)] = !!on; }));
      sol.v.forEach((row, r) => row.forEach((on, c) => { want[(2 * c) + '-' + (2 * r + 1)] = !!on; }));
      return want;
    }

    // Same serialization as evaluate() in ploty.js, so this is exactly what the page accepts.
    function serialize(want) {
      let s1 = '', s2 = '';
      for (let y = 0; y < planHeight; y++) for (let x = 0; x < planWidth; x++) {
        if ((x + y) % 2 !== 1) continue;
        const ch = want[x + '-' + y] ? 'y' : 'n';
        if (y % 2 === 0) s1 += ch; else s2 += ch;
      }
      return [s1, s2];
    }

    function targetFromStored() {
      const sol = items[offset] && items[offset].solution;
      if (!sol) return null;
      const want = {};
      let i1 = 0, i2 = 0;
      for (let y = 0; y < planHeight; y++) for (let x = 0; x < planWidth; x++) {
        if ((x + y) % 2 !== 1) continue;
        want[x + '-' + y] = (y % 2 === 0 ? sol[0][i1++] : sol[1][i2++]) === 'y';
      }
      return want;
    }

    function getTarget() {
      let want = targetFromSolver();
      // Puzzle with several valid loops: the page only accepts its stored one.
      const stored = items[offset] && items[offset].solution;
      if (stored && (!want || serialize(want).join() !== stored.join())) want = targetFromStored();
      return want;
    }

    const isOn = key => { const [x, y] = key.split('-').map(Number); return currentPlan[y][x] === '+'; };

    // Real mouse events, same path as a user's click.
    function press(key) {
      const el = document.getElementById('fence' + key);
      if (!el) return;
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, button: 0, buttons: 1 }));
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 0 }));
    }

    function setDirect(key) {
      const [x, y] = key.split('-').map(Number);
      const el = document.getElementById('fence' + key);
      const on = currentPlan[y][x] !== '+';
      currentPlan[y][x] = on ? '+' : '*';
      if (el) { el.classList.remove('deleted'); el.classList.toggle('selected', on); }
    }

    function fenceEnds(key) {
      const [x, y] = key.split('-').map(Number);
      return y % 2 === 0 ? [(x - 1) + '-' + y, (x + 1) + '-' + y] : [x + '-' + (y - 1), x + '-' + (y + 1)];
    }
    function vertexFences(v) {
      const [x, y] = v.split('-').map(Number);
      return [(x - 1) + '-' + y, (x + 1) + '-' + y, x + '-' + (y - 1), x + '-' + (y + 1)]
        .filter(k => document.getElementById('fence' + k));
    }

    // Fences of the loop in drawing order, starting at a random point.
    function loopOrder(want) {
      const on = Object.keys(want).filter(k => want[k]);
      if (!on.length) return [];
      const byVertex = {};
      for (const k of on) for (const v of fenceEnds(k)) (byVertex[v] = byVertex[v] || []).push(k);
      const order = [], used = new Set();
      let cur = pickRandom(on);
      let v = fenceEnds(cur)[Math.random() < 0.5 ? 0 : 1];
      while (cur && !used.has(cur)) {
        used.add(cur);
        order.push(cur);
        const [a, b] = fenceEnds(cur);
        v = a === v ? b : a;
        cur = (byVertex[v] || []).find(k => !used.has(k));
      }
      for (const k of on) if (!used.has(k)) order.push(k);
      return order;
    }

    function plan() {
      const want = getTarget();
      if (!want) return null;
      const loop = loopOrder(want);
      const offKeys = Object.keys(want).filter(k => !want[k] && isOn(k));
      const step = key => ({ run: () => press(key) });

      // In Ihned mode every fence but the last is set like clickFence() does, minus its
      // full-board evaluate(); the last one is a real click, so the page checks the result once.
      const toChange = [...offKeys, ...loop.filter(k => !isOn(k))];
      const steps = toChange.map((key, i) => ({
        run: ctx => (ctx && ctx.fast && i < toChange.length - 1 ? setDirect(key) : press(key)),
      }));

      // Human version: solve in pieces (runs of 3-12 fences in random order),
      // with pauses to think and an occasional misclick that gets fixed.
      const human = [{ wait: rand(4, 9) }];
      offKeys.forEach(k => human.push({ wait: rand(0.4, 1.2), ...step(k) }));
      const chunks = [];
      for (let i = 0; i < loop.length;) {
        const len = Math.round(rand(3, 12));
        chunks.push(loop.slice(i, i + len));
        i += len;
      }
      for (let i = chunks.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [chunks[i], chunks[j]] = [chunks[j], chunks[i]];
      }
      for (const chunk of chunks) {
        human.push({ wait: rand(2, 10) });
        chunk.forEach((key, i) => {
          if (isOn(key)) return;
          if (Math.random() < 0.05) {
            const wrong = vertexFences(fenceEnds(key)[0]).filter(k => !want[k] && !isOn(k));
            if (wrong.length) {
              const w = pickRandom(wrong);
              human.push({ wait: rand(0.3, 0.8), ...step(w) });
              human.push({ wait: rand(0.8, 2.5), ...step(w) });
            }
          }
          human.push({ wait: i === 0 ? rand(0.5, 1.5) : rand(0.15, 0.6), ...step(key) });
        });
      }
      return { steps, human };
    }

    return {
      label: 'Ploty',
      unit: 'plot',
      humanHint: 'Kreslí plot po kouscích, s pauzami a občasným překliknutím.',
      detect: () => hasScript('/exercise/ploty.js'),
      ready: () => typeof window.clickFence === 'function' && Array.isArray(window.currentPlan) && currentPlan.length > 0,
      finished: () => window.finished === 1,
      next: () => nextItem(),
      retry: true,
      plan,
    };
  })();

  // ---------------------------------------------------------------- Autíčka
  const rushhour = (function () {
    function moveCar(m, animate) {
      const car = cars.find(c => c.type === m.type);
      if (!car) return;
      const dx = m.x - car.x, dy = m.y - car.y;
      const el = window.jQuery(".car[type='" + m.type + "']");
      if (!animate || !el.length) { updatePlan(m.type, m.x, m.y); return; }
      // Slide the car like a drag, then let the page snap and re-evaluate.
      return new Promise(resolve => {
        el.animate(
          { left: '+=' + dx * gridSize + 'px', top: '+=' + dy * gridSize + 'px' },
          rand(220, 380) + 70 * Math.abs(dx + dy),
          'swing',
          () => { updatePlan(m.type, m.x, m.y); resolve(); }
        );
      });
    }

    function plan() {
      const moves = window.solveRushHour(currentPlan, cars, exitPositionX, exitPositionY);
      if (!moves) return null;
      const steps = moves.map(m => ({ run: ctx => moveCar(m, ctx && ctx.animate) }));
      const human = [{ wait: rand(3, 7) }];
      steps.forEach(s => human.push({ wait: Math.random() < 0.2 ? rand(4, 9) : rand(0.8, 3.5), ...s }));
      return { steps, human };
    }

    return {
      label: 'Autíčka',
      unit: 'tah',
      humanHint: 'Posouvá auta postupně, mezi tahy přemýšlí.',
      defaultTime: [40, 100],
      detect: () => hasScript('/exercise/rushhour.js'),
      ready: () => typeof window.updatePlan === 'function' && Array.isArray(window.cars) && cars.length > 0,
      finished: () => window.finished === 1,
      next: () => nextItem(),
      retry: true,
      plan,
    };
  })();

  // ---------------------------------------------------------------- Šipkovaná
  // Its state is private, so the puzzle comes from hook.js (copy of the downloaded data)
  // and the solution is entered by clicking, like a player.
  const sipkovana = (function () {
    const isArrow = t => ['arrow', 'arrow1', 'arrowR-', 'arrowR+'].includes(t);
    const isFinished = () => !!document.querySelector('#plan.correct');

    const currentItem = () => findItem(currentId());

    function selectCommand(i) {
      const el = document.getElementById('command' + i);
      if (el && !el.classList.contains('selected')) el.click();
    }
    function clickCell(p) {
      const el = document.getElementById('square-' + p.x + '-' + p.y);
      if (el) el.click();
    }
    // An arrow is placed facing the command's default direction; each extra click turns it.
    const turns = (p, commands) => (isArrow(commands[p.cmd].type) ? p.value - (Number(commands[p.cmd].value) || 0) : 0);

    function setFastSpeed() {
      const slider = document.getElementById('speed-slider');
      if (!slider) return;
      // speed = 250 × (5 − value) ms per step, 0 means the fastest 50 ms; let the slider reach 5.
      if (Number(slider.max) < 5) slider.max = 5;
      slider.value = 5;
      slider.dispatchEvent(new Event('change'));
    }

    async function start(ctx) {
      if (ctx && ctx.fast) {
        // At top speed (< 200 ms) each step is evaluated at once, so step the bots with the page's
        // own "one step" button instead of waiting 50 ms per step for the timer.
        setFastSpeed();
        const step = document.getElementById('next-step');
        for (let i = 0; step && i < 300 && !isFinished(); i++) step.click();
        if (isFinished()) return;
      }
      const btn = document.getElementById('start');
      if (btn) btn.click();
      const end = Date.now() + 90000;
      while (!isFinished() && Date.now() < end) await sleep(50);
    }

    function plan() {
      const puzzle = currentItem().item.item;
      const startBtn = document.getElementById('start');
      if (startBtn && getComputedStyle(startBtn).display === 'none') throw userError('Nejdřív zastav roboty (Stop).');
      const touched = puzzle.commands.some((c, i) => {
        const el = document.querySelector('#command' + i + ' div');
        return el && parseInt(el.textContent, 10) !== Number(c.count);
      });
      if (touched) throw userError('Nejdřív odeber příkazy, které už jsou na ploše.');

      const placements = window.solveSipkovana(puzzle);
      if (!placements) return null;
      const cmds = puzzle.commands;
      const placeNow = p => {
        selectCommand(p.cmd);
        clickCell(p);
        for (let t = turns(p, cmds); t > 0; t--) clickCell(p);
      };

      // Last step = last placement + start, so "Počkat" holds both back.
      const steps = placements.map(p => ({ run: () => placeNow(p) }));
      const last = steps.pop();
      steps.push({ run: async ctx => { if (last) last.run(ctx); await start(ctx); } });

      const human = [{ wait: rand(5, 12) }];
      placements.forEach(p => {
        human.push({ wait: rand(2, 7), run: () => selectCommand(p.cmd) });
        human.push({ wait: rand(0.6, 1.5), run: () => clickCell(p) });
        for (let t = turns(p, cmds); t > 0; t--) human.push({ wait: rand(0.25, 0.6), run: () => clickCell(p) });
      });
      human.push({ wait: rand(2, 5), run: ctx => start(ctx) });
      return { steps, human };
    }

    return {
      label: 'Šipkovaná',
      unit: 'krok',
      humanHint: 'Pokládá šipky postupně, s pauzami, a pak pustí roboty.',
      detect: () => hasScript('/exercise/sipkovana.js'),
      ready: () => !!currentItem() && !!document.querySelector('#plan td'),
      finished: isFinished,
      next: () => document.getElementById('next').click(),
      retry: false,
      plan,
    };
  })();

  // ---------------------------------------------------------------- Rozhodovačka
  // Two-option questions (binary-choice.js). Each option in the data has a `correct` flag.
  const rozhodovacka = (function () {
    // displayItem() shuffles item.options in place and draws options[0] / options[1];
    // hook.js keeps the item it was called with (store.shownItem), so we know which button is right.
    const wrapper = () => document.getElementById('question-wrapper');
    const optionEl = i => wrapper() && wrapper().querySelector('[data-data=option][data-index="' + i + '"]');
    const answered = () => [0, 1].some(i => optionEl(i) && optionEl(i).classList.contains('correct'));
    const isCorrect = o => Number(o.correct) === 1;

    function currentItem() {
      const shown = store.shownItem;
      if (shown && String(shown.id) === currentId()) return { item: shown, onScreen: true };
      const item = findItem(currentId());
      return item ? { item, onScreen: false } : null;
    }

    function correctIndex() {
      const cur = currentItem();
      if (!cur) return -1;
      if (cur.onScreen) {
        const index = cur.item.options.findIndex(isCorrect);
        // If text can be checked, reject a stale shuffled order instead of guessing.
        const right = cur.item.options[index];
        if (!right || !optionEl(index)) return -1;
        if (typeof window.renderContentFormat === 'function') {
          const rendered = window.renderContentFormat(right.option);
          const expected = rendered?.textContent?.replace(/\s+/g, '');
          if (expected && optionEl(index).textContent.replace(/\s+/g, '') !== expected) {
            const matches = [0, 1].filter(i => optionEl(i)?.textContent.replace(/\s+/g, '') === expected);
            return matches.length === 1 ? matches[0] : -1;
          }
        }
        return index;
      }
      // Only the downloaded copy (order may differ on screen): match the rendered text.
      const text = node => (node ? node.textContent.replace(/\s+/g, '') : '');
      const right = cur.item.options.find(isCorrect);
      const want = right && text(window.renderContentFormat(right.option));
      const matches = [0, 1].filter(i => want && text(optionEl(i)) === want);
      return matches.length === 1 ? matches[0] : -1;
    }

    async function answer() {
      const i = correctIndex();
      const el = optionEl(i);
      if (!el || answered()) return;
      // One checked click: never repeat an old index after the page auto-advances.
      el.click();
    }

    function plan() {
      if (correctIndex() < 0) return null;
      const median = Number(currentItem().item.medianResponseTime) || 6000;
      const step = { target: () => optionEl(correctIndex()), run: answer };
      // Human: about as long as a typical student needs for this question
      // (the page counts > 1.3 × median as slow, which scores worse).
      return { steps: [step], human: [{ wait: (median / 1000) * rand(0.7, 1.2) }, { wait: 0, ...step }] };
    }

    return {
      get label() { return (detectedKey === 'rozhodovacka' && urlName()) || 'Rozhodovačka'; },
      unit: 'odpověď',
      waitHint: 'Počká náhodnou dobu z rozsahu a pak klikne na správnou odpověď.',
      humanHint: 'Odpoví zhruba tak rychle, jako to v průměru trvá ostatním žákům.',
      ownPace: true,
      defaultTime: [4, 10],
      // Střílečka and Roboti load binary-choice.js too, but play differently.
      detect: () => hasScript('/exercise/novaDoplnovacka.js') && typeof window.displayItem === 'function',
      ready: () => !!optionEl(0) && !!currentItem(),
      finished: answered,
      next: () => {
        // After a slow or wrong answer the page shows an explanation and waits for "Další".
        const btn = document.getElementById('next');
        if (btn && getComputedStyle(btn).display !== 'none') return btn.click();
        // Otherwise Enter moves on at once instead of the page's 0.5–1 s pause (its own shortcut).
        document.dispatchEvent(new KeyboardEvent('keydown', { code: 'Enter', key: 'Enter', bubbles: true }));
      },
      retry: false,
      plan,
    };
  })();

  // Wait until cond() is true (or the time is up); returns cond().
  async function until(cond, ms = 4000, step = 25) {
    const end = Date.now() + ms;
    while (!cond() && Date.now() < end) await sleep(step);
    return cond();
  }

  // ---------------------------------------------------------------- Psaná odpověď
  // novaVpisovacka.js (Psaná odpověď, Slovní úlohy): answer boxes #answer{i} with an <input>;
  // the question carries ['input', { answer: [accepted, ...] }] for every box.
  const vpisovacka = (function () {
    const box = i => document.getElementById('answer' + i);
    const input = i => document.querySelector('#answer' + i + ' input');
    const boxCount = () => { let n = 0; while (box(n)) n++; return n; };
    const evaluated = i => box(i) && (box(i).classList.contains('correct') || box(i).classList.contains('wrong'));
    const progressive = () => typeof specs !== 'undefined' && !!specs.progressiveEvaluation;

    function answers() {
      const cap = store.inputAnswers;
      let list = cap && String(cap.id) === currentId() ? cap.answers : null;
      if (!list || !list.length) {
        // Rendered before we could listen: take the boxes from the downloaded question.
        const item = findItem(currentId());
        list = [];
        (function walk(x) {
          if (!Array.isArray(x)) return;
          if (x[0] === 'input' && x[1] && 'answer' in x[1]) list.push([].concat(x[1].answer));
          else x.forEach(walk);
        })(item && item.question);
      }
      return list.length && list.length === boxCount() && list.every(a => a.length) ? list : null;
    }

    async function type(i, text, slow) {
      const el = input(i);
      await until(() => input(i) && !input(i).disabled, 3000);
      el.focus();
      const steps = slow ? [...String(text)].map((_, k) => String(text).slice(0, k + 1)) : [String(text)];
      for (const value of steps) {
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true })); // lets the page's input mask follow
        if (slow) await sleep(rand(90, 240));
      }
    }

    // Enter = the page's "Vyhodnotit"; ignored until the question has faded in, so repeat briefly.
    const submit = done => until(() => { if (!done()) pressEnter(); return done(); }, 6000, 40);

    function plan() {
      const list = answers();
      if (!list) return null;
      const item = findItem(currentId());
      const median = Number(item && item.medianResponseTime) || 8000;
      const n = list.length;
      const value = i => list[i][0];

      if (progressive()) {
        // One box at a time: each is checked before the next one unlocks.
        const step = i => ({ run: async ctx => { await type(i, value(i), ctx && ctx.animate); await submit(() => evaluated(i)); } });
        const steps = list.map((_, i) => step(i));
        const human = [{ wait: (median / 1000) * rand(0.3, 0.5) }];
        list.forEach((_, i) => human.push({ wait: (median / 1000 / n) * rand(0.3, 0.6), ...step(i) }));
        return { steps, human };
      }
      const fillAll = async ctx => { for (let i = 0; i < n; i++) await type(i, value(i), ctx && ctx.animate); };
      const send = { run: () => submit(() => evaluated(0)) };
      const human = [{ wait: (median / 1000) * rand(0.45, 0.75) }];
      list.forEach((_, i) => human.push({ wait: i ? rand(0.5, 1.5) : 0, run: ctx => type(i, value(i), ctx && ctx.animate) }));
      human.push({ wait: rand(0.4, 1.0), ...send });
      return { steps: [{ run: fillAll }, send], human };
    }

    return {
      get label() { return (detectedKey === 'vpisovacka' && urlName()) || 'Psaná odpověď'; },
      unit: 'odpověď',
      waitHint: 'Vyplní odpověď hned, počká a pak ji odešle.',
      humanHint: 'Chvíli počítá, odpověď píše po znacích a odešle ji, zhruba za dobu běžnou u ostatních žáků.',
      ownPace: true,
      defaultTime: [5, 15],
      detect: () => hasScript('/exercise/novaVpisovacka.js'),
      ready: () => !!input(0) && !!answers(),
      finished: () => boxCount() > 0 && [...Array(boxCount()).keys()].every(i => box(i).classList.contains('correct')),
      next: () => {
        const btn = document.getElementById('next');
        if (visible(btn)) btn.click(); else pressEnter();
      },
      retry: false,
      plan,
    };
  })();

  // ---------------------------------------------------------------- Přesouvání
  // presouvani.js: cards cut out of a picture go into their places. The page shuffles the
  // options ({ id, type: 'answer' | 'distractor' }); card data-index = position after the shuffle,
  // target data-index = option id. hook.js keeps the shuffled array.
  const presouvani = (function () {
    const isOption = o => o && typeof o === 'object' && 'id' in o && (o.type === 'answer' || o.type === 'distractor');
    const card = k => document.querySelector('#plan .card[data-index="' + k + '"]');
    const target = a => document.querySelector('#plan .target[data-index="' + a + '"]');
    const done = () => document.getElementById('plan').classList.contains('finished');

    function moves() {
      const shuffled = lastShuffle(isOption);
      const targets = [...document.querySelectorAll('#plan .target')];
      if (!shuffled || !targets.length) return null;
      const order = shuffled.map(o => o.id);
      const list = targets.map(t => ({ target: Number(t.dataset.index), card: order.indexOf(Number(t.dataset.index)) }));
      return list.every(m => m.card >= 0 && card(m.card)) ? list : null;
    }

    // The page's own click-to-move: select a card, then click its place. The page clears
    // "selected" only when the move animation ends; a card still marked then would be swapped
    // with the next one we click, so clear the mark ourselves.
    const unselectOthers = keep => document.querySelectorAll('#plan .card.selected').forEach(x => x !== keep && x.classList.remove('selected'));
    const select = m => {
      const c = card(m.card);
      unselectOthers(c);
      if (c && !c.classList.contains('selected')) c.click();
    };
    const drop = m => {
      const c = card(m.card), t = target(m.target);
      if (c && t && !t.contains(c)) t.click();
      if (c) c.classList.remove('selected');
    };
    const evaluate = () => until(() => { if (!done()) document.getElementById('evaluate').click(); return done(); }, 4000, 50);

    function plan() {
      const list = moves();
      if (!list) return null;
      const steps = list.map(m => ({ run: () => { select(m); drop(m); } }));
      const last = steps.pop();
      steps.push({ run: async () => { last.run(); await evaluate(); } });
      const human = [{ wait: rand(3, 7) }];
      list.forEach(m => {
        human.push({ wait: rand(1, 3.5), run: () => select(m) });
        human.push({ wait: rand(0.4, 1.1), run: () => drop(m) });
      });
      human.push({ wait: rand(1, 3), run: evaluate });
      return { steps, human };
    }

    return {
      get label() { return (detectedKey === 'presouvani' && urlName()) || 'Přesouvání'; },
      unit: 'kartička',
      waitHint: 'Rozmístí kartičky hned, poslední nechá na konec odpočtu a pak vyhodnotí.',
      humanHint: 'Kartičky přesouvá jednu po druhé s pauzami a nakonec vyhodnotí.',
      defaultTime: [20, 60],
      detect: () => hasScript('/exercise/presouvani.js'),
      ready: () => !!moves(),
      finished: done,
      next: async () => { const btn = document.getElementById('next'); if (await until(() => visible(btn), 3000)) btn.click(); },
      retry: false,
      plan,
    };
  })();

  // ---------------------------------------------------------------- Pexeso
  // pexeso.js: the even and the odd half of the options ({ content, pair, parity }) are shuffled
  // separately and dealt alternately (even[0], odd[0], even[1], ...). hook.js keeps both arrays.
  const pexeso = (function () {
    const isCard = o => o && typeof o === 'object' && 'pair' in o && (o.parity === 'even' || o.parity === 'odd');
    const cards = () => [...document.querySelectorAll('#pexeso .card')];
    const done = () => document.getElementById('pexeso').classList.contains('finished');

    function pairs() {
      // Newest odd shuffle and the even one made just before it (an item may have id 0 and no URL update).
      const list = (store.shuffles || []).map(s => s.arr).filter(a => a.length && a.every(isCard));
      const oi = list.map(a => a[0].parity).lastIndexOf('odd');
      const even = oi > 0 && list[oi - 1][0].parity === 'even' ? list[oi - 1] : null;
      const odd = oi >= 0 ? list[oi] : null;
      if (!even || !odd) return null;
      const n = Math.min(even.length, odd.length);
      const shown = cards();
      if (shown.length !== 2 * n) return null;
      const byPair = {};
      for (let i = 0; i < 2 * n; i++) {
        const o = i % 2 ? odd[(i - 1) / 2] : even[i / 2];
        if (!shown[i].classList.contains(o.parity)) return null; // not this deal
        (byPair[o.pair] = byPair[o.pair] || []).push(i);
      }
      return Object.values(byPair).filter(p => p.length === 2);
    }

    const card = i => document.querySelector('#pexeso .card[data-index="' + i + '"]');
    const open = i => { const c = card(i); if (c && !c.classList.contains('correct') && !c.classList.contains('selected')) c.click(); };
    // The page checks for the win when a card's animation ends; nudge it if that never comes.
    const settle = async () => {
      if (!(await until(done, 600))) {
        const c = cards()[0];
        if (c) c.dispatchEvent(new AnimationEvent('animationend', { bubbles: true }));
      }
    };

    function plan() {
      const list = pairs();
      if (!list) return null;
      const steps = list.map(([a, b]) => ({ run: () => { open(a); open(b); } }));
      const last = steps.pop();
      steps.push({ run: async () => { last.run(); await settle(); } });
      const human = [{ wait: rand(3, 6) }];
      list.forEach(([a, b], k) => {
        human.push({ wait: rand(1, 3), run: () => open(a) });
        human.push({ wait: rand(0.5, 1.3), run: k === list.length - 1 ? async () => { open(b); await settle(); } : () => open(b) });
      });
      return { steps, human };
    }

    return {
      get label() { return (detectedKey === 'pexeso' && urlName()) || 'Pexeso'; },
      unit: 'dvojice',
      waitHint: 'Otočí všechny dvojice hned, poslední nechá na konec odpočtu.',
      humanHint: 'Otáčí dvojice jednu po druhé s pauzami.',
      defaultTime: [30, 90],
      detect: () => hasScript('/exercise/pexeso.js'),
      ready: () => !!pairs(),
      finished: done,
      next: async () => { const btn = document.querySelector('.next'); if (await until(() => visible(btn), 3000)) btn.click(); },
      retry: false,
      plan,
    };
  })();

  // More task types live in extension/games/*.js (listed in manifest.json before this file).
  // Each pushes a factory onto window.__neumimetoGames: kit => ({ key, label, detect, ready,
  // finished, next, plan, ... }) – the same shape as the adapters above.
  const kit = {
    store, currentId, findItem, urlName, lastShuffle, visible, pressEnter, until, sleep, rand,
    pickRandom, hasScript, userError,
    get detectedKey() { return detectedKey; },
  };
  const external = {};
  (window.__neumimetoGames || []).forEach(factory => {
    try {
      const game = factory(kit);
      if (game && game.key) external[game.key] = game;
    } catch (e) { console.error('[neumimeto] game file failed', e); }
  });

  const GAMES = { ploty, rushhour, sipkovana, rozhodovacka, vpisovacka, presouvani, pexeso, ...external };
  const detectedKey = Object.keys(GAMES).find(k => GAMES[k].detect());
  window.__neumimetoGame = detectedKey || null; // queue.js reads it
  if (!detectedKey) return; // not a supported exercise page

  window.UmimeOfflineEngine = {game:GAMES[detectedKey], key:detectedKey, currentId};
})();
