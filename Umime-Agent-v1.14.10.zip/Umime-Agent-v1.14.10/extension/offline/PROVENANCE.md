# Local engine provenance

Source: user-uploaded `neumimeto (1).zip`, manifest version 1.78.

- `hook.js`, `games/*.js` and `solvers/*.js` are retained from that archive.
- `engine.js` retains the adapter definitions/registry prefix from its `content.js`, ending before the original Settings/dock/runner code. It exports the detected adapter.
- `../offline-runner.js` and `../offline-bridge.js` are the new integration layer.
- The original UI, logo, queue and shortcuts are not installed.

The page hook observes exercise data and wraps page helper functions. It is local page-data solving, not AI generation. It does not receive extension API credentials. The original adapter comments identify assumptions and format limitations.

The supplied archive did not establish a distribution license in the files inspected. This integration preserves supplied source comments and provenance; it does not establish ownership or permission to redistribute commercially.
